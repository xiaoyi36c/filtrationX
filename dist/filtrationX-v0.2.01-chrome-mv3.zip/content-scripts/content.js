var content=(function(){var e=Object.create,t=Object.defineProperty,n=Object.getOwnPropertyDescriptor,r=Object.getOwnPropertyNames,i=Object.getPrototypeOf,a=Object.prototype.hasOwnProperty,o=(e,t)=>()=>(e&&(t=e(e=0)),t),s=(e,t)=>()=>(t||(e((t={exports:{}}).exports,t),e=null),t.exports),c=(e,n)=>{let r={};for(var i in e)t(r,i,{get:e[i],enumerable:!0});return n||t(r,Symbol.toStringTag,{value:`Module`}),r},l=(e,i,o,s)=>{if(i&&typeof i==`object`||typeof i==`function`)for(var c=r(i),l=0,u=c.length,d;l<u;l++)d=c[l],!a.call(e,d)&&d!==o&&t(e,d,{get:(e=>i[e]).bind(null,d),enumerable:!(s=n(i,d))||s.enumerable});return e},u=(n,r,a)=>(a=n==null?{}:e(i(n)),l(r||!n||!n.__esModule?t(a,`default`,{value:n,enumerable:!0}):a,n));function d(e){return e}var f={debug:(...e)=>([...e],void 0),log:(...e)=>([...e],void 0),warn:(...e)=>([...e],void 0),error:(...e)=>([...e],void 0)},p=Symbol(`null`),m=0,h=class extends Map{constructor(...e){super(),this._objectHashes=new WeakMap,this._symbolHashes=new Map,this._publicKeys=new Map;let[t]=e;if(t!=null){if(typeof t[Symbol.iterator]!=`function`)throw TypeError(typeof t+` is not iterable (cannot read property Symbol(Symbol.iterator))`);for(let[e,n]of t)this.set(e,n)}}_getPublicKeys(e,t=!1){if(!Array.isArray(e))throw TypeError(`The keys parameter must be an array`);let n=this._getPrivateKey(e,t),r;return n&&this._publicKeys.has(n)?r=this._publicKeys.get(n):t&&(r=[...e],this._publicKeys.set(n,r)),{privateKey:n,publicKey:r}}_getPrivateKey(e,t=!1){let n=[];for(let r of e){let e=r===null?p:r,i;if(i=typeof e==`object`||typeof e==`function`?`_objectHashes`:typeof e==`symbol`?`_symbolHashes`:!1,!i)n.push(e);else if(this[i].has(e))n.push(this[i].get(e));else if(t){let t=`@@mkm-ref-${m++}@@`;this[i].set(e,t),n.push(t)}else return!1}return JSON.stringify(n)}set(e,t){let{publicKey:n}=this._getPublicKeys(e,!0);return super.set(n,t)}get(e){let{publicKey:t}=this._getPublicKeys(e);return super.get(t)}has(e){let{publicKey:t}=this._getPublicKeys(e);return super.has(t)}delete(e){let{publicKey:t,privateKey:n}=this._getPublicKeys(e);return!!(t&&super.delete(t)&&this._publicKeys.delete(n))}clear(){super.clear(),this._symbolHashes.clear(),this._publicKeys.clear()}get[Symbol.toStringTag](){return`ManyKeysMap`}get size(){return super.size}};function g(e){if(typeof e!=`object`||!e)return!1;let t=Object.getPrototypeOf(e);return t!==null&&t!==Object.prototype&&Object.getPrototypeOf(t)!==null||Symbol.iterator in e?!1:Symbol.toStringTag in e?Object.prototype.toString.call(e)===`[object Module]`:!0}function _(e,t,n=`.`,r){if(!g(t))return _(e,{},n,r);let i={...t};for(let t of Object.keys(e)){if(t===`__proto__`||t===`constructor`)continue;let a=e[t];a!=null&&(r&&r(i,t,a,n)||(Array.isArray(a)&&Array.isArray(i[t])?i[t]=[...a,...i[t]]:g(a)&&g(i[t])?i[t]=_(a,i[t],(n?`${n}.`:``)+t.toString(),r):i[t]=a))}return i}function v(e){return(...t)=>t.reduce((t,n)=>_(t,n,``,e),{})}var y=v(),b=e=>e===null?{isDetected:!1}:{isDetected:!0,result:e},x=e=>e===null?{isDetected:!0,result:null}:{isDetected:!1},S=()=>({target:globalThis.document,unifyProcess:!0,detector:b,observeConfigs:{childList:!0,subtree:!0,attributes:!0},signal:void 0,customMatcher:void 0}),C=(e,t)=>y(e,t),w=new h;function T(e){let{defaultOptions:t}=e;return(e,n)=>{let{target:r,unifyProcess:i,observeConfigs:a,detector:o,signal:s,customMatcher:c}=C(n,t),l=[e,r,i,a,o,s,c],u=w.get(l);if(i&&u)return u;let d=new Promise(async(t,n)=>{if(s?.aborted)return n(s.reason);let i=new MutationObserver(async n=>{for(let a of n){if(s?.aborted){i.disconnect();break}let n=await E({selector:e,target:r,detector:o,customMatcher:c});if(n.isDetected){i.disconnect(),t(n.result);break}}});s?.addEventListener(`abort`,()=>(i.disconnect(),n(s.reason)),{once:!0});let l=await E({selector:e,target:r,detector:o,customMatcher:c});if(l.isDetected)return t(l.result);i.observe(r,a)}).finally(()=>{w.delete(l)});return w.set(l,d),d}}async function E({target:e,selector:t,detector:n,customMatcher:r}){return await n(r?r(t):e.querySelector(t))}var D=T({defaultOptions:S()});function ee(e,t,n){n.position!==`inline`&&(n.zIndex!=null&&(e.style.zIndex=String(n.zIndex)),e.style.overflow=`visible`,e.style.position=`relative`,e.style.width=`0`,e.style.height=`0`,e.style.display=`block`,t&&(n.position===`overlay`?(t.style.position=`absolute`,n.alignment?.startsWith(`bottom-`)?t.style.bottom=`0`:t.style.top=`0`,n.alignment?.endsWith(`-right`)?t.style.right=`0`:t.style.left=`0`):(t.style.position=`fixed`,t.style.top=`0`,t.style.bottom=`0`,t.style.left=`0`,t.style.right=`0`)))}function O(e){if(e.anchor==null)return document.body;let t=typeof e.anchor==`function`?e.anchor():e.anchor;return typeof t==`string`?t.startsWith(`/`)?document.evaluate(t,document,null,XPathResult.FIRST_ORDERED_NODE_TYPE,null).singleNodeValue??void 0:document.querySelector(t)??void 0:t??void 0}function te(e,t){let n=O(t);if(n==null)throw Error(`Failed to mount content script UI: could not find anchor element`);switch(t.append){case void 0:case`last`:n.append(e);break;case`first`:n.prepend(e);break;case`replace`:n.replaceWith(e);break;case`after`:n.parentElement?.insertBefore(e,n.nextElementSibling);break;case`before`:n.parentElement?.insertBefore(e,n);break;default:t.append(n,e)}}function k(e,t){let n,r=()=>{n?.stopAutoMount(),n=void 0},i=()=>{e.mount()},a=e.remove;return{mount:i,remove:()=>{r(),e.remove()},autoMount:e=>{n&&f.warn(`autoMount is already set.`),n=A({mount:i,unmount:a,stopAutoMount:r},{...t,...e})}}}function A(e,t){let n=new AbortController,r=`explicit_stop_auto_mount`,i=()=>{n.abort(r),t.onStop?.()},a=typeof t.anchor==`function`?t.anchor():t.anchor;if(a instanceof Element)throw Error("autoMount and Element anchor option cannot be combined. Avoid passing `Element` directly or `() => Element` to the anchor.");async function o(i){let a=!!O(t);for(a&&e.mount();!n.signal.aborted;)try{a=!!await D(i??`body`,{customMatcher:()=>O(t)??null,detector:a?x:b,signal:n.signal}),a?e.mount():(e.unmount(),t.once&&e.stopAutoMount())}catch(e){if(n.signal.aborted&&n.signal.reason===r)break;throw e}}return o(a),{stopAutoMount:i}}var j=/(\s*@(property|font-face)[\s\S]*?{[\s\S]*?})/gm;function ne(e){return{documentCss:Array.from(e.matchAll(j),e=>e[0]).join(``).trim(),shadowCss:e.replace(j,``).trim()}}var re=globalThis.browser?.runtime?.id?globalThis.browser:globalThis.chrome,M=u(s(((e,t)=>{var n=/^[a-z](?:[\.0-9_a-z\xB7\xC0-\xD6\xD8-\xF6\xF8-\u037D\u037F-\u1FFF\u200C\u200D\u203F\u2040\u2070-\u218F\u2C00-\u2FEF\u3001-\uD7FF\uF900-\uFDCF\uFDF0-\uFFFD]|[\uD800-\uDB7F][\uDC00-\uDFFF])*-(?:[\x2D\.0-9_a-z\xB7\xC0-\xD6\xD8-\xF6\xF8-\u037D\u037F-\u1FFF\u200C\u200D\u203F\u2040\u2070-\u218F\u2C00-\u2FEF\u3001-\uD7FF\uF900-\uFDCF\uFDF0-\uFFFD]|[\uD800-\uDB7F][\uDC00-\uDFFF])*$/;t.exports=function(e){return n.test(e)}}))(),1),ie=(e,t,n)=>new Promise((r,i)=>{var a=e=>{try{s(n.next(e))}catch(e){i(e)}},o=e=>{try{s(n.throw(e))}catch(e){i(e)}},s=e=>e.done?r(e.value):Promise.resolve(e.value).then(a,o);s((n=n.apply(e,t)).next())}),ae=[`article`,`aside`,`blockquote`,`body`,`div`,`footer`,`h1`,`h2`,`h3`,`h4`,`h5`,`h6`,`header`,`main`,`nav`,`p`,`section`,`span`];function oe(e){return ie(this,null,function*(){let{name:t,mode:n=`closed`,css:r,isolateEvents:i=!1}=e;if(!ae.includes(t)&&!(0,M.default)(t))throw Error(`"${t}" cannot have a shadow root attached to it. It must be two words and kebab-case, with a few exceptions. See https://developer.mozilla.org/en-US/docs/Web/API/Element/attachShadow#elements_you_can_attach_a_shadow_to`);let a=document.createElement(t),o=a.attachShadow({mode:n}),s=document.createElement(`html`),c=document.createElement(`body`),l=document.createElement(`head`);if(r){let e=document.createElement(`style`);`url`in r?e.textContent=yield fetch(r.url).then(e=>e.text()):e.textContent=r.textContent,l.appendChild(e)}return s.appendChild(l),s.appendChild(c),o.appendChild(s),i&&(Array.isArray(i)?i:[`keydown`,`keyup`,`keypress`]).forEach(e=>{c.addEventListener(e,e=>e.stopPropagation())}),{parentElement:a,shadow:o,isolatedElement:c}})}async function se(e,t){let n=Math.random().toString(36).substring(2,15),r=[];if(t.inheritStyles||r.push(`/* WXT Shadow Root Reset */ :host{all:initial !important;}`),t.css&&r.push(t.css),e.options?.cssInjectionMode===`ui`){let e=await N();r.push(e.replaceAll(`:root`,`:host`))}let{shadowCss:i,documentCss:a}=ne(r.join(`
`).trim()),{isolatedElement:o,parentElement:s,shadow:c}=await oe({name:t.name,css:{textContent:i},mode:t.mode??`open`,isolateEvents:t.isolateEvents}),l,u=()=>{if(te(s,t),ee(s,c.querySelector(`html`),t),a&&!document.querySelector(`style[wxt-shadow-root-document-styles="${n}"]`)){let e=document.createElement(`style`);e.textContent=a,e.setAttribute(`wxt-shadow-root-document-styles`,n),(document.head??document.body).append(e)}l=t.onMount(o,c,s)},d=()=>{for(t.onRemove?.(l),s.remove(),document.querySelector(`style[wxt-shadow-root-document-styles="${n}"]`)?.remove();o.lastChild;)o.removeChild(o.lastChild);l=void 0},f=k({mount:u,remove:d},t);return e.onInvalidated(d),{shadow:c,shadowHost:s,uiContainer:o,...f,get mounted(){return l}}}async function N(){let e=re.runtime.getURL(`/content-scripts/content.css`);try{return await(await fetch(e)).text()}catch(t){return f.warn(`Failed to load styles @ ${e}. Did you forget to import the stylesheet in your entrypoint?`,t),``}}function P(e){let t=e?.closest(`[data-testid="UserName"]`);if(!t)return null;let n=t.closest(`[data-testid="primaryColumn"]`);for(let e=t.parentElement;e&&e!==n;e=e.parentElement)if(e.querySelector(`a[href$="/header_photo"]`))return e;return null}var F=`data-xss-hidden-key`,I=`data-xss-previous-display`;function ce(e,t){let n=e?.closest(`[data-testid="cellInnerDiv"]`)??e?.closest(`article`)??P(e);return n?(t&&!n.hasAttribute(F)&&(n.setAttribute(F,t),n.setAttribute(I,n.style.display)),n.style.display=`none`,!0):!1}function le(e,t=document){let n=0;for(let r of t.querySelectorAll(`[${F}]`)){let t=r.getAttribute(F);!t||e.has(t)||(r.style.display=r.getAttribute(I)??``,r.removeAttribute(F),r.removeAttribute(I),n++)}return n}function ue(e){return e.source===`list`?e.tier!==`confirmed`&&e.autoTierMode===`badge`?!1:e.autoScope===`all`||e.inReply:e.source===`rule`?e.autoTierMode===`badge`?!1:e.inReply:!1}function de(e,t){return t.source===`list`&&t.tier===`confirmed`?e:t.source===`rule`?t.ruleHitsAutoAct&&t.autoTierMode===`full`?e:e===`badge`?`badge`:`hide`:t.autoTierMode===`full`?e:e===`badge`?`badge`:`hide`}var fe=`xss:blocked`,L=null;try{chrome.storage.onChanged.addListener((e,t)=>{t===`local`&&e[`xss:blocked`]&&(L=new Set(e[`xss:blocked`]?.newValue??[]))})}catch{}async function R(){if(L)return L;try{let e=await chrome.storage.local.get(fe);L=new Set(e[`xss:blocked`]??[])}catch{L=new Set}return L}function z(e){return L?L.has(e):!1}async function pe(){await R()}async function B(e){let t=await R();if(!t.has(e)){t.add(e);try{await chrome.storage.local.set({[fe]:[...t]})}catch{}}}async function V(e){let t=await R();if(t.delete(e))try{await chrome.storage.local.set({[fe]:[...t]})}catch{}}var H={name:`Make X Great Again 二开版`,acronym:`filtrationX`,tagline:`AI 帮你拦 X 上的垃圾`,repo:`https://github.com/Bycorer/filtrationX`,release:`https://github.com/Bycorer/filtrationX/releases/latest`,upstreamRepo:`https://github.com/foru17/make-x-great-again`,chromeWebStore:`https://chromewebstore.google.com/detail/make-x-great-again/aeoldnecphbkkckeedfgfcdcekkljdea`,firefoxAddons:`https://addons.mozilla.org/firefox/addon/make-x-great-again/`,testFlight:`https://testflight.apple.com/join/SeH4raps`,edgeBase:`https://x.zuoluo.tv`,governance:`https://github.com/foru17/make-x-great-again/blob/main/GOVERNANCE.md`,privacy:`https://github.com/foru17/make-x-great-again/blob/main/docs/PRIVACY.md`,appealNewIssue:`https://github.com/foru17/make-x-great-again/issues/new?template=appeal.yml`,issues:`https://github.com/foru17/make-x-great-again/issues`,owner:`Bycorer`,license:`AGPL-3.0`},me=`xss:v1:`,U=864e5;function he(e){return e===`spam`||e===`porn_bot`||e===`likely_spam`?7*U:e===`legit`?14*U:3*U}function ge(e){return typeof e!=`number`||!Number.isFinite(e)||e<0?null:e<2?e:Math.round(Math.log2(e)*2)}function _e(e){let t=JSON.stringify([e.handle,e.displayName,e.bio,e.recentTweets,e.triggeringComment??``,e.hasDefaultAvatar,e.avatarSource??null,e.isVerified??!1,e.location??``,ge(e.accountAgeDays===void 0?void 0:Math.floor(e.accountAgeDays/30)),ge(e.followersCount),ge(e.followingCount),ge(e.statusesCount),ge(e.mediaCount),ge(e.favouritesCount)]),n=5381;for(let e=0;e<t.length;e++)n=(n*33^t.charCodeAt(e))>>>0;return n.toString(36)}var W=e=>me+e;async function ve(e){try{let t=W(e),n=(await chrome.storage.local.get(t))[t];return n?Date.now()-n.ts>he(n.verdict.label)?(chrome.storage.local.remove(t),null):n:null}catch{return null}}async function ye(e,t){try{await chrome.storage.local.set({[W(e)]:t})}catch{}}var be=`data-mxga-u`;function xe(e){return e?.trim().replace(/^@+/,``).toLowerCase()??``}function Se(e,t){if(!e)return{};let n=xe(t);if(!n||xe(e.getAttribute(`data-mxga-uh`)??void 0)!==n)return{};let r=e.getAttribute(be);if(!r)return{};try{let e=JSON.parse(r);return!e||typeof e!=`object`||Array.isArray(e)?{}:e}catch{return{}}}var Ce=new Set([`home`,`explore`,`notifications`,`messages`,`i`,`search`,`settings`,`compose`,`hashtag`,`bookmarks`,`lists`,`communities`,`jobs`,`tos`,`privacy`,`login`,`signup`]),we=1288834974657n,Te=2*864e5;function Ee(e){if(!e)return;let t=Date.now(),n,r=e.match(/(\d{4})年(\d{1,2})月/);if(r&&(n=new Date(Number(r[1]),Number(r[2])-1,1)),!n){let t=e.match(/Joined\s+([A-Za-z]+)\s+(\d{4})/i);t&&(n=new Date(`${t[1]} 1, ${t[2]}`))}if(!(!n||Number.isNaN(n.getTime())))return Math.max(0,Math.round((t-n.getTime())/864e5))}function De(e){if(!e)return;let t=e.replace(/[, ]/g,``).match(/([\d.]+)\s*([万KkMm千]?)/);if(!(!t||t[1]===void 0))return Math.round(Number.parseFloat(t[1])*({万:1e4,千:1e3,K:1e3,k:1e3,M:1e6,m:1e6}[t[2]??``]??1))}function Oe(e){let t=e.querySelector(`img[src*="profile_images/"]`);return{hasDefaultAvatar:!t,avatarUrl:t?.src}}function G(e){return e?.trim().replace(/^@+/,``).toLowerCase()||void 0}function ke(e){return typeof e==`string`&&/^\d+$/.test(e)?e:void 0}function Ae(e){return typeof e==`number`&&Number.isSafeInteger(e)?String(e):ke(e)}function K(e){return e===!0?!0:void 0}function je(e){let t=e.querySelector(`[src*="profile_banners/"], [style*="profile_banners/"]`);return ke((t instanceof HTMLImageElement?t.src:t?.getAttribute(`style`)??``).match(/profile_banners\/(\d+)\//)?.[1])}function Me(e){if(!(e.length<16))try{return Number((BigInt(e)>>22n)+we)}catch{return}}function Ne(e){for(let t of document.querySelectorAll(`script[type="application/ld+json"]`))try{let n=JSON.parse(t.textContent??``),r=Array.isArray(n)?n:[n];for(let t of r){if(!t||typeof t!=`object`)continue;let n=t;if(n[`@type`]!==`ProfilePage`)continue;let r=n.mainEntity;if(!r||typeof r!=`object`)continue;let i=r;if(i[`@type`]!==`Person`)continue;let a=G(typeof i.additionalName==`string`?i.additionalName:void 0)??G(typeof i.url==`string`?i.url.match(/\/([^/?#]+)(?:[?#].*)?$/)?.[1]:void 0);if(e&&a!==e)continue;let o=Ae(i.identifier);if(o)return o}}catch{}}function Pe(){let e=document.querySelector(`[data-testid="AppTabBar_Profile_Link"]`)?.getAttribute(`href`),t=G(e?.match(/^\/([^/?#]+)/)?.[1]);return t&&!Ce.has(t)?t:G((document.querySelector(`[data-testid="SideNav_AccountSwitcher_Button"]`)?.innerText??``).match(/@([A-Za-z0-9_]{1,15})/)?.[1])}function Fe(e){let t=Pe(),n=G(e);return t&&n&&t===n?!0:void 0}function Ie(e){return e.replace(/[.*+?^${}()|[\]\\]/g,`\\$&`)}function Le(e,t){let n=G(t),r=n?RegExp(`@${Ie(n)}\\b`,`i`):void 0;for(let t of e.querySelectorAll(`[data-testid$="-follow"], [data-testid$="-unfollow"], [data-testid$="-subscribe"]`)){let e=(t.getAttribute(`data-testid`)??``).match(/^(\d+)-(follow|unfollow|subscribe)$/);if(!e)continue;let n=`${t.getAttribute(`aria-label`)??``}\n${t.innerText??``}`;if(!(r&&!r.test(n)))return{userId:e[1],...e[2]===`unfollow`?{viewerFollowing:!0}:{}}}if(r)for(let t of e.querySelectorAll(`button, [role="button"]`)){let e=`${t.getAttribute(`aria-label`)??``}\n${t.innerText??``}`;if(r.test(e)&&/(取消关注|正在关注|Following|Unfollow)/i.test(e))return{viewerFollowing:!0}}return{}}var Re=new WeakMap;function ze(e,t){let n=G(t)??``,r=Re.get(e)?.get(n);if(r)return r;let i=Be(e,n||void 0);if(Object.keys(i).length){let t=Re.get(e)??new Map;t.set(n,i),Re.set(e,t)}return i}function Be(e,t){try{let n=Object.keys(e).find(e=>e.startsWith(`__reactFiber$`));if(!n)return{};let r=e[n],i=new Set,a={n:4e3};for(let e=0;r&&e<24;e++){for(let e of[r.memoizedProps,r.memoizedState]){let n=He(e,i,0,a,t);if(n){let e=n.legacy??n,t=n.core??{},r=n.relationship_perspectives??{},i=e.created_at??t.created_at,a=i?Date.parse(i):NaN,o=Ve(n,e),s=Number.isNaN(a)?void 0:Math.max(0,Math.round((Date.now()-a)/864e5)),c=Number.isNaN(a)?void 0:new Date(a).toISOString(),l=e=>typeof e==`number`&&Number.isFinite(e)?e:void 0,u=l(e.statuses_count),d=l(e.media_count),f=l(e.favourites_count),p=K(n.is_blue_verified)||K(e.verified)||K(e.is_blue_verified)||K(n.verification?.verified)?!0:void 0,m=typeof e.location==`string`?e.location:n.location?.location,h=typeof m==`string`&&m.trim()?m.trim().slice(0,100):void 0,g=typeof e.profile_image_url_https==`string`?e.profile_image_url_https:typeof n.avatar?.image_url==`string`?n.avatar.image_url:void 0,_=typeof e.default_profile_image==`boolean`?e.default_profile_image:g?/default_profile/.test(g):void 0,v=K(e.following)||K(r.following),y=K(e.blocking)||K(r.blocking),b=K(e.muting)||K(r.muting),x=K(e.follow_request_sent)||K(r.follow_request_sent);return{bio:typeof e.description==`string`?e.description:``,...o?{userId:o}:{},followersCount:e.followers_count,followingCount:e.friends_count,...c?{accountCreatedAt:c}:{},...s===void 0?{}:{accountAgeDays:s},...p?{isVerified:p}:{},...u===void 0?{}:{statusesCount:u},...d===void 0?{}:{mediaCount:d},...f===void 0?{}:{favouritesCount:f},...h?{location:h}:{},..._===void 0?{}:{profileDefaultImage:_},...v?{viewerFollowing:!0}:{},...y?{viewerBlocking:!0}:{},...b?{viewerMuting:!0}:{},...x?{viewerFollowRequestSent:!0}:{}}}}r=r.return}}catch{}return{}}function Ve(e,t){let n=ke(t?.id_str),r=ke(e?.rest_id);if(n&&r&&n!==r){console.warn(`[MXGA] conflicting X user ids in fiber; dropping uid`,{legacyId:n,restId:r,screenName:t?.screen_name??e?.core?.screen_name});return}let i=n??r,a=ke(String(t?.profile_image_url_https??``).match(/profile_images\/(\d+)\//)?.[1]),o=i?Me(i):void 0,s=typeof t?.created_at==`string`?Date.parse(t.created_at):NaN;if(i&&a===i&&o!==void 0&&!Number.isNaN(s)&&Math.abs(o-s)>Te){console.warn(`[MXGA] fiber uid looks like avatar media id; dropping uid`,{candidate:i,screenName:t?.screen_name,createdAt:t.created_at,avatarUrl:t.profile_image_url_https});return}return i}function He(e,t,n,r,i){if(!e||typeof e!=`object`||n>5||t.has(e)||--r.n<=0||e instanceof Node||e instanceof Window)return null;t.add(e);try{let a=e.legacy??e,o=e.core??{},s=a?.screen_name??o.screen_name;if(a&&typeof a==`object`&&typeof s==`string`&&(typeof a.followers_count==`number`||typeof a.id_str==`string`||typeof e.rest_id==`string`||e.__typename===`User`)){let t=G(s);if(!i||t===i)return e}for(let a of Object.keys(e)){let o=He(e[a],t,n+1,r,i);if(o)return o}}catch{}return null}function Ue(){let e=location.pathname.split(`/`).filter(Boolean);if(e.length!==1)return;let t=e[0]??``;return Ce.has(t)||!/^[A-Za-z0-9_]{1,15}$/.test(t)?void 0:t}function We(e){let t=e.querySelector(`[data-testid="User-Name"]`);if(t)for(let e of t.querySelectorAll(`a[href^="/"]`)){let t=(e.getAttribute(`href`)??``).split(`/`).filter(Boolean);if(t.length===1&&/^[A-Za-z0-9_]{1,15}$/.test(t[0]??``))return t[0]}}function Ge(){let e=location.pathname.split(`/`).filter(Boolean);if(e.length!==1||Ce.has(e[0]??``))return null;let t=document.querySelector(`[data-testid="UserName"]`);if(!t)return null;let n=t.innerText.split(`
`).map(e=>e.trim()).filter(Boolean),r=(n.find(e=>e.startsWith(`@`))??`@${e[0]}`).slice(1),i=n[0]&&!n[0].startsWith(`@`)?n[0]:``,a=document.querySelector(`[data-testid="UserDescription"]`),o=document.querySelector(`[data-testid="UserJoinDate"]`),s,c;for(let e of document.querySelectorAll(`a[href*="/follow"], a[href$="/verified_followers"]`)){let t=e.getAttribute(`href`)??``,n=De(e.innerText);/\/following$/.test(t)?c=n:/(verified_)?followers$/.test(t)&&(s=n)}let l=document.querySelector(`[data-testid="primaryColumn"]`)??document,{hasDefaultAvatar:u,avatarUrl:d}=Oe(l),f=l instanceof Element?l:t,p=Le(f,r),m={...ze(f,r),...Se(f,r),...p.userId?{userId:p.userId}:{},...p.viewerFollowing?{viewerFollowing:!0}:{},...Fe(r)||f.querySelector(`[data-testid="editProfileButton"]`)?{viewerIsSelf:!0}:{}},h=Ne(r);h&&m.userId&&h!==m.userId&&console.warn(`[MXGA] profile JSON-LD user id differs from observed user id; using JSON-LD`,{handle:r,jsonLdUserId:h,observedUserId:m.userId});let g=h??m.userId??je(l);return{isProfile:!0,surface:`profile`,handle:r,displayName:i,bio:a?a.innerText.trim():``,...Je(u,m),recentTweets:qe(f,r),...d?{avatarUrl:d}:{},...g?{userId:g}:{},...Ye(m),...m.viewerFollowing?{viewerFollowing:!0}:{},...m.viewerBlocking?{viewerBlocking:!0}:{},...m.viewerMuting?{viewerMuting:!0}:{},...m.viewerFollowRequestSent?{viewerFollowRequestSent:!0}:{},...m.viewerIsSelf?{viewerIsSelf:!0}:{},...m.accountCreatedAt?{accountCreatedAt:m.accountCreatedAt}:{},...Ee(o?.innerText)===void 0?{}:{accountAgeDays:Ee(o?.innerText)},...s===void 0?{}:{followersCount:s},...c===void 0?{}:{followingCount:c}}}var Ke=10;function qe(e,t){let n=t.toLowerCase(),r=[],i=new Set;for(let t of e.querySelectorAll(`article[data-testid="tweet"]`)){if(r.length>=Ke)break;if(We(t)?.toLowerCase()!==n||Ze(t))continue;let e=t.querySelector(`[data-testid="tweetText"]`)?.innerText.trim();if(!e)continue;let a=e.slice(0,500);i.has(a)||(i.add(a),r.push(a))}return r}function Je(e,t){return t.profileDefaultImage===void 0?{hasDefaultAvatar:e,avatarSource:`dom`}:{hasDefaultAvatar:t.profileDefaultImage,avatarSource:`profile`}}function Ye(e){return{...e.isVerified?{isVerified:!0}:{},...e.statusesCount===void 0?{}:{statusesCount:e.statusesCount},...e.mediaCount===void 0?{}:{mediaCount:e.mediaCount},...e.favouritesCount===void 0?{}:{favouritesCount:e.favouritesCount},...e.location?{location:e.location}:{}}}var Xe=/^(广告|推广|Promoted|Ad|プロモーション|광고)$/;function Ze(e){if(e.querySelector(`[data-testid="placementTracking"]`))return!0;let t=e.querySelector(`[data-testid="tweetText"]`);for(let n of e.querySelectorAll(`span,div`))if(!t?.contains(n)&&Xe.test(n.textContent?.trim()??``))return!0;return!1}var Qe=/translated from|show original|翻译自|显示原文|翻譯自|顯示原文|由\s*\S{1,12}\s*(?:翻译|翻譯)|原文を表示|から翻訳|번역함|원본 보기/i;function $e(e,t){return t?Qe.test(e.textContent??``):!1}function et(){let e=location.pathname;return e===`/home`||e===`/`||e.startsWith(`/i/lists/`)||e===`/explore`?`home`:/^\/[^/]+\/status\/\d+/.test(e)?`thread`:e.startsWith(`/search`)?`search`:e.startsWith(`/notifications`)?`notifications`:/^\/[A-Za-z0-9_]{1,15}(\/(with_replies|media|likes|highlights|articles))?\/?$/.test(e)?`profile`:`other`}var tt=/^(replying to|回复|回覆|返信先|답글|antwort an|en réponse à|respondiendo a|em resposta a|in risposta a|antwoord aan)\b/i;function nt(e,t){for(let n of e.querySelectorAll(`div, span`)){if(t?.contains(n))continue;let e=(n.textContent??``).trim();if(!(!e||e.length>200||!tt.test(e)))for(let e of n.querySelectorAll(`a[href^="/"]`)){let t=(e.getAttribute(`href`)??``).split(`/`).filter(Boolean);if(t.length===1&&/^[A-Za-z0-9_]{1,15}$/.test(t[0]??``))return t[0]}}}function rt(e){if(Ze(e))return null;let{hasDefaultAvatar:t,avatarUrl:n}=Oe(e),r=e.querySelector(`[data-testid="User-Name"]`);if(!r)return null;let i,a=``;for(let e of r.querySelectorAll(`a[href^="/"]`)){let t=(e.getAttribute(`href`)??``).split(`/`).filter(Boolean);t.length===1&&/^[A-Za-z0-9_]{1,15}$/.test(t[0]??``)&&(i=t[0])}let o=r.innerText.split(`
`).map(e=>e.trim()).filter(Boolean);if(o.length&&(a=o[0]??``),!i){let e=o.find(e=>e.startsWith(`@`));e&&(i=e.slice(1))}if(!i)return null;let s=e.querySelector(`[data-testid="tweetText"]`),c=s?s.innerText.trim():``,l=$e(e,s),u=nt(e,s),d=Se(e,i),f=ze(e,i),p=Le(e,i),m={...f,...d},h={...f,...d,...!m.userId&&p.userId?{userId:p.userId}:{},...p.viewerFollowing?{viewerFollowing:!0}:{},...Fe(i)?{viewerIsSelf:!0}:{}};return{isProfile:!1,handle:i,displayName:a,bio:h.bio??``,...Je(t,h),...Ye(h),recentTweets:[],...n?{avatarUrl:n}:{},...h.userId?{userId:h.userId}:{},...c?{triggeringComment:c}:{},...l?{tweetsTranslated:!0}:{},surface:et(),...u?{isReply:!0,replyToHandle:u}:{},...h.accountCreatedAt?{accountCreatedAt:h.accountCreatedAt}:{},...h.accountAgeDays===void 0?{}:{accountAgeDays:h.accountAgeDays},...h.followersCount===void 0?{}:{followersCount:h.followersCount},...h.followingCount===void 0?{}:{followingCount:h.followingCount},...h.viewerFollowing?{viewerFollowing:!0}:{},...h.viewerBlocking?{viewerBlocking:!0}:{},...h.viewerMuting?{viewerMuting:!0}:{},...h.viewerFollowRequestSent?{viewerFollowRequestSent:!0}:{},...h.viewerIsSelf?{viewerIsSelf:!0}:{}}}function it(){if(!/^\/[^/]+\/status\/\d+/.test(location.pathname))return;let e=document.querySelector(`article[data-testid="tweet"] [data-testid="tweetText"]`)?.innerText.trim();return e?e.slice(0,400):void 0}var at=[`porn`,`crypto`,`gambling`,`resource`,`marketing`,`other`],ot={p:`porn`,c:`crypto`,g:`gambling`,r:`resource`,m:`marketing`,o:`other`};function st(e){return e&&ot[e]||`other`}var ct={porn:`色情招揽`,crypto:`币圈投放`,gambling:`博彩推广`,resource:`网盘资源`,marketing:`营销引流`,other:`其它`},lt=`
:host { all: initial; }
* { box-sizing: border-box; font-family: system-ui,-apple-system,"Segoe UI",sans-serif; }
/* :host is REQUIRED here: badges/popovers each live in their own shadow
 * root, where :root/.xss match nothing — without :host every var() below
 * fails and the badge degrades to unstyled black text (the v0.5 regression). */
:host, :root, .xss {
  /* dark default (X dark mode) */
  --surface: rgba(13,17,23,.92); --border: rgba(255,255,255,.10);
  --shadow: 0 8px 28px rgba(0,0,0,.45); --text: #E6EDF3; --muted: #8B949E;
  --brand: #0EA5E9; --danger: #EF4444; --warn: #F59E0B; --neutral: #8B949E;
  --safe: #16A34A; --hover: rgba(255,255,255,.06);
}
@media (prefers-color-scheme: light) {
  :host, :root, .xss {
    --surface: rgba(255,255,255,.96); --border: rgba(15,23,42,.12);
    --shadow: 0 8px 28px rgba(15,23,42,.18); --text: #0F172A; --muted: #475569;
    --brand: #0369A1; --danger: #DC2626; --warn: #B45309; --neutral: #475569;
    --safe: #15803D; --hover: rgba(15,23,42,.06);
  }
}
/* X's OWN theme wins over the OS scheme (2026-09-06). X has three themes
 * (Default / Dim / Lights out) chosen in-app, independent of the OS: a user
 * on a light OS with X in Lights out got the light palette above — grey
 * ghost badges and slate popover text on a black page. detectXTheme() reads
 * the page's real background and stamps data-xss-theme on every shadow host
 * and the popover/bubble roots; these blocks come AFTER the media query so
 * they win either way. */
:host([data-xss-theme="dark"]), .xss[data-xss-theme="dark"] {
  --surface: rgba(13,17,23,.92); --border: rgba(255,255,255,.10);
  --shadow: 0 8px 28px rgba(0,0,0,.45); --text: #E6EDF3; --muted: #8B949E;
  --brand: #0EA5E9; --danger: #EF4444; --warn: #F59E0B; --neutral: #8B949E;
  --safe: #16A34A; --hover: rgba(255,255,255,.06);
}
:host([data-xss-theme="light"]), .xss[data-xss-theme="light"] {
  --surface: rgba(255,255,255,.96); --border: rgba(15,23,42,.12);
  --shadow: 0 8px 28px rgba(15,23,42,.18); --text: #0F172A; --muted: #475569;
  --brand: #0369A1; --danger: #DC2626; --warn: #B45309; --neutral: #475569;
  --safe: #15803D; --hover: rgba(15,23,42,.06);
}
.xss-bubble {
  position: fixed;
  right: max(12px, env(safe-area-inset-right));
  top: max(12px, env(safe-area-inset-top));
  z-index: 2147483000;
  color: var(--text); -webkit-font-smoothing: antialiased;
}
/* X pins its search box to the top of the right sidebar; whether a pill at
 * 12px collides with it depends on the viewport width. content.ts measures
 * the real overlap (see avoidSearchBox) and sets --xss-bubble-top only when
 * needed, so the default stays the tidy 12px. */
.xss-bubble:not(.br) { top: var(--xss-bubble-top, max(12px, env(safe-area-inset-top))); }
.xss-bubble.br {
  top: auto;
  bottom: max(12px, env(safe-area-inset-bottom));
}
.pill, .card {
  background: var(--surface); border: 1px solid var(--border);
  box-shadow: var(--shadow); backdrop-filter: blur(12px);
  -webkit-backdrop-filter: blur(12px); border-radius: 14px;
}
.pill {
  display: inline-flex; align-items: center; gap: 8px; padding: 6px 10px;
  border-radius: 999px; cursor: pointer; transition: opacity .14s ease, transform .14s ease;
  min-width: 0; min-height: 36px;
}
.pill:hover { opacity: .94; transform: translateY(-1px); }
.scan-pill {
  display: grid; grid-template-columns: 22px auto auto;
  align-items: center; gap: 7px; width: auto;
}
.scan-radar {
  --accent: var(--brand); --angle: 360deg;
  width: 22px; height: 22px; position: relative; display: grid; place-items: center;
  border-radius: 999px; flex: none;
  background: conic-gradient(var(--accent) var(--angle), color-mix(in srgb, var(--accent) 12%, transparent) 0deg);
  box-shadow: inset 0 0 0 1px color-mix(in srgb, var(--accent) 18%, transparent);
}
.scan-radar.danger { --accent: var(--danger); }
.scan-core {
  position: absolute; inset: 4px; display: grid; place-items: center;
  border-radius: inherit; background: var(--surface);
}
.scan-sweep {
  position: absolute; inset: 2px; border-radius: inherit; opacity: 0;
  background: conic-gradient(from -30deg, transparent 0 64%, color-mix(in srgb, var(--accent) 58%, transparent) 76%, transparent 92%);
}
.scan-radar.busy .scan-sweep {
  opacity: .95; animation: xradar 1.15s linear infinite;
}
.scan-radar.busy {
  animation: xbreath 1.6s ease-in-out infinite;
}
.scan-title {
  overflow: hidden; text-overflow: ellipsis; white-space: nowrap;
  max-width: 46px; font-size: 12.5px; font-weight: 750; color: var(--text);
}
.scan-meta {
  flex: none; font-size: 11px; font-weight: 650; color: var(--muted);
  font-variant-numeric: tabular-nums;
}
.card {
  width: min(312px, calc(100vw - 24px));
  padding: 14px; display: none; margin-top: 10px;
}
/* Expand = the card GROWS out of the pill with a springy overshoot
 * (origin sits up near the pill), instead of teleporting into place. */
.card { transform-origin: calc(100% - 34px) -8px; }
.card.open { display: block; animation: cardin .38s cubic-bezier(.3, 1.28, .44, 1); }
@keyframes cardin {
  0% { opacity: 0; transform: translateY(-7px) scale(.9); }
  55% { opacity: 1; }
  100% { opacity: 1; transform: translateY(0) scale(1); }
}
/* Fold-back mirrors the expand: shrink toward the pill, then display:none
 * (class removed on animationend in collapse()). */
.card.closing { display: block; animation: cardout .2s ease-in forwards; }
@keyframes cardout {
  to { opacity: 0; transform: translateY(-6px) scale(.92); }
}
.hd { display: flex; align-items: center; gap: 8px; font-size: 13px; font-weight: 600; }
.hd .x { margin-left: auto; cursor: pointer; color: var(--muted); display: flex; }
.hd .x:hover { color: var(--text); }
.sub {
  display: grid; grid-template-columns: repeat(4, minmax(0, 1fr));
  gap: 6px; margin: 10px 0 12px;
  font-size: 11px; color: var(--muted);
}
.metric {
  min-width: 0; height: 30px; display: flex; align-items: center; justify-content: center;
  gap: 4px; padding: 0 5px; border-radius: 8px;
  background: color-mix(in srgb, var(--muted) 7%, transparent);
  font-variant-numeric: tabular-nums;
  white-space: nowrap; overflow: hidden;
  position: relative;
}
/* 已处理 counter pop — plays when an absorbed row lands in the chip. */
.metric.tick { animation: mtick .5s cubic-bezier(.3, 1.5, .5, 1); overflow: visible; }
@keyframes mtick {
  0% { transform: scale(1); }
  35% { transform: scale(1.16); }
  100% { transform: scale(1); }
}
.m-plus {
  position: absolute; top: -13px; right: 4px; pointer-events: none;
  font-size: 10px; font-weight: 800; color: var(--danger);
  animation: mplus .8s ease-out forwards;
}
@keyframes mplus {
  0% { opacity: 0; transform: translateY(7px); }
  25% { opacity: 1; }
  100% { opacity: 0; transform: translateY(-9px); }
}
/* Flying ghost of a settled row on its way into the 已处理 chip. */
.q-fly {
  position: fixed; z-index: 2147483002; pointer-events: none;
  display: flex; align-items: flex-start; gap: 8px; padding: 7px 6px;
  border-radius: 10px; color: var(--text);
  background: var(--surface); border: 1px solid var(--border);
  box-shadow: var(--shadow);
}
.metric b { color: var(--text); font-size: 12px; font-weight: 760; line-height: 1; }
.metric em { font-style: normal; overflow: hidden; text-overflow: ellipsis; }
.metric i { width: 6px; height: 6px; border-radius: 50%; display: inline-block; flex: none; }
/* The 已处理 chip doubles as a tab: it lists the whole-session record
 * (done rows from THIS page stay in the live queue too — v0.4 checklist). */
.metric.tab { cursor: pointer; user-select: none; transition: background .14s ease, box-shadow .14s ease; }
.metric.tab:hover { background: color-mix(in srgb, var(--muted) 16%, transparent); }
.metric.tab.on {
  background: color-mix(in srgb, var(--danger) 12%, transparent);
  box-shadow: inset 0 0 0 1px color-mix(in srgb, var(--danger) 38%, transparent);
}
.queue-empty {
  display: flex; align-items: center; justify-content: center; gap: 6px;
  padding: 16px 10px; border-radius: 10px;
  font-size: 11.5px; color: var(--muted);
  background: color-mix(in srgb, var(--safe) 6%, transparent);
}
.btn {
  width: 100%; border: 0; border-radius: 10px; padding: 9px 12px;
  font-size: 13px; font-weight: 600; cursor: pointer; color: #fff;
  background: var(--danger); transition: filter .14s ease;
}
.btn:hover { filter: brightness(1.08); }
.btn:disabled { opacity: .55; cursor: default; }

/* Per-row action button — same color language as bulk btn, smaller scale. */
.xss-act {
  flex: none; border: 0; border-radius: 8px; padding: 5px 10px;
  font-size: 11.5px; font-weight: 600; cursor: pointer; color: #fff;
  background: var(--danger); transition: filter .14s ease, background .14s;
  white-space: nowrap;
}
.xss-act:hover { filter: brightness(1.08); }
.xss-act:disabled { cursor: default; }
/* Done chip stays in the danger family (v0.4 处理垃圾 = 红色语言) — tinted,
 * not solid, so it can't be mistaken for the still-clickable solid button. */
.xss-act.done {
  background: color-mix(in srgb, var(--danger) 14%, transparent);
  color: var(--danger); opacity: .95;
}
.xss-act.queue {
  background: transparent; color: var(--brand);
  border: 1px solid var(--brand);
}
.xss-act.queue.busy { animation: xpulse 1.2s ease-in-out infinite; }
.xss-act.retry {
  background: transparent; color: var(--warn);
  border: 1px solid var(--warn);
}

/* Per-row select checkbox — themed, replaces native browser styling. */
.xss-row-cb {
  width: 15px; height: 15px; flex: none; cursor: pointer;
  appearance: none; -webkit-appearance: none;
  border: 1.5px solid var(--border); border-radius: 4px;
  background: transparent; transition: border-color .12s, background .12s;
  position: relative; margin-top: 6px;
}
.xss-row-cb:hover { border-color: var(--danger); }
.xss-row-cb:checked {
  background: var(--danger); border-color: var(--danger);
}
.xss-row-cb:checked::after {
  content: ""; position: absolute; left: 3px; top: 0;
  width: 5px; height: 9px; border: solid #fff;
  border-width: 0 1.5px 1.5px 0; transform: rotate(45deg);
}
.xss-row-cb:disabled { opacity: .35; cursor: default; }

/* 自动处理 master switch (card header area) — themed mini toggle. */
.auto-row {
  display: flex; align-items: center; gap: 7px; margin-top: 9px;
  font-size: 11.5px; font-weight: 600; color: var(--text);
}
.auto-row .auto-hint {
  margin-left: auto; font-size: 10.5px; font-weight: 500;
  color: var(--muted); white-space: nowrap; overflow: hidden;
  text-overflow: ellipsis;
}
.xss-sw {
  position: relative; width: 30px; height: 18px; flex: none; padding: 0;
  border-radius: 999px; cursor: pointer;
  border: 1px solid var(--border);
  background: color-mix(in srgb, var(--muted) 28%, transparent);
  transition: background .16s ease, border-color .16s ease;
}
.xss-sw::after {
  content: ""; position: absolute; top: 2px; left: 2px;
  width: 12px; height: 12px; border-radius: 50%; background: #fff;
  box-shadow: 0 1px 3px rgba(0,0,0,.35);
  transition: transform .16s ease;
}
.xss-sw[aria-checked="true"] { background: var(--brand); border-color: var(--brand); }
.xss-sw[aria-checked="true"]::after { transform: translateX(12px); }
@media (prefers-reduced-motion: reduce) {
  .xss-sw, .xss-sw::after { transition: none; }
}
.row { display: flex; gap: 14px; margin-top: 10px; font-size: 12px; }
.lnk { color: var(--muted); cursor: pointer; }
.lnk:hover { color: var(--text); }
.block-progress {
  margin: -2px 0 13px;
}
.progress-head {
  display: flex; align-items: center; justify-content: space-between;
  margin-bottom: 6px; font-size: 11px; color: var(--muted);
  font-variant-numeric: tabular-nums;
}
.progress-head b {
  color: var(--text); font-size: 11px; font-weight: 750;
}
.progress-track {
  height: 9px; display: flex; overflow: hidden; border-radius: 999px;
  background: color-mix(in srgb, var(--muted) 12%, transparent);
  box-shadow: inset 0 0 0 1px color-mix(in srgb, var(--text) 8%, transparent);
}
.progress-seg {
  height: 100%; min-width: 0; transition: width .22s ease;
}
.progress-seg + .progress-seg {
  box-shadow: inset 1px 0 0 color-mix(in srgb, var(--surface) 70%, transparent);
}
.progress-seg.done { background: linear-gradient(90deg, color-mix(in srgb, var(--danger) 78%, #fff), var(--danger)); }
.progress-seg.active {
  background:
    repeating-linear-gradient(115deg, rgba(255,255,255,.22) 0 6px, transparent 6px 12px),
    linear-gradient(90deg, color-mix(in srgb, var(--danger) 72%, #fff), var(--danger));
  animation: pbarshift .9s linear infinite;
}
.progress-seg.queued { background: linear-gradient(90deg, color-mix(in srgb, var(--brand) 76%, #fff), var(--brand)); }
.progress-seg.failed { background: linear-gradient(90deg, color-mix(in srgb, var(--warn) 76%, #fff), var(--warn)); }
.progress-seg.idle { background: color-mix(in srgb, var(--muted) 24%, transparent); }
.queue-table {
  max-height: 226px; overflow: auto; margin: 0 -4px 10px; padding: 0 4px;
  scrollbar-width: thin;
  /* Rows carry state tints now — breathing room between them, or adjacent
   * tinted rows fuse into one solid slab. */
  display: flex; flex-direction: column; gap: 5px;
}
.qrow {
  display: flex; align-items: flex-start; gap: 8px; padding: 7px 6px;
  border-radius: 10px; transform-origin: top center; flex: none;
  transition: background .14s ease, opacity .14s ease;
}
/* First render of a row slides in; on card expand every row is "new", and
 * the per-slot delays turn that into a soft cascade down the list. */
.qrow.new { animation: qrowin .26s cubic-bezier(.2,.7,.2,1) backwards; }
.qrow.new:nth-child(2) { animation-delay: .045s; }
.qrow.new:nth-child(3) { animation-delay: .09s; }
.qrow.new:nth-child(4) { animation-delay: .135s; }
.qrow.new:nth-child(n+5) { animation-delay: .18s; }
.qrow.active { background: color-mix(in srgb, var(--danger) 8%, transparent); }
.qrow.queued { background: color-mix(in srgb, var(--brand) 7%, transparent); }
.qrow.failed { background: color-mix(in srgb, var(--warn) 8%, transparent); }
/* Done rows go QUIET (neutral, not red): strikethrough + dimmed avatar
 * already say "handled", and full red tint here drowned the hierarchy —
 * red is reserved for the in-flight row and the small status accents. */
.qrow.done { background: color-mix(in srgb, var(--muted) 7%, transparent); }
.qavatar {
  width: 26px; height: 26px; border-radius: 50%; flex: none; object-fit: cover;
  transition: filter .18s ease, opacity .18s ease;
}
.qavatar.blank { background: var(--border); }
.qbody { min-width: 0; flex: 1; }
.qname {
  font-weight: 650; font-size: 12px; overflow: hidden;
  text-overflow: ellipsis; white-space: nowrap;
}
.qmeta { font-size: 11px; }
/* Per-row 误判 link — quiet until hovered, so it never competes with the
 * account meta but stays reachable for a wrongly-listed account. */
.qappeal {
  margin-left: 6px; color: var(--muted); cursor: pointer;
  text-decoration: none; font-weight: 600; opacity: .7;
  /* Two-character link must never split across lines ("误" / "判"). */
  display: inline-block; white-space: nowrap;
}
.qappeal:hover { color: var(--warn); opacity: 1; text-decoration: underline; }
.qsnip {
  font-size: 11px; color: var(--muted); overflow: hidden;
  text-overflow: ellipsis; white-space: nowrap;
}
/* 命中原因 chips — tiny tags, visually separate from the content snippet. */
.qtags { display: flex; flex-wrap: wrap; gap: 4px; margin: 2px 0 1px; }
.qtag {
  font-size: 9.5px; font-weight: 650; line-height: 1; padding: 2.5px 6px;
  border-radius: 999px; white-space: nowrap; max-width: 160px;
  overflow: hidden; text-overflow: ellipsis;
  color: var(--muted); border: 1px solid color-mix(in srgb, var(--muted) 32%, transparent);
  background: color-mix(in srgb, var(--muted) 8%, transparent);
}
.qtag.warn {
  color: var(--warn); border-color: color-mix(in srgb, var(--warn) 45%, transparent);
  background: color-mix(in srgb, var(--warn) 9%, transparent);
}
.qnote { font-size: 11px; }
.qrow.done .qavatar {
  filter: grayscale(1); opacity: .38;
}
.qrow.done .qname,
.qrow.done .qsnip {
  text-decoration: line-through; opacity: .52;
}
/* One-shot red flash the moment a row flips to done — the checklist
 * "tick" that makes batch progress feel tangible (danger family, v0.4). */
.qrow.done.flip { animation: qdoneflash .45s ease-out; }
@keyframes qdoneflash {
  0% { background: color-mix(in srgb, var(--danger) 26%, transparent); transform: scale(1.015); }
}
svg { display: block; }
.xss-badge {
  --badge-color: var(--muted);
  display: inline-flex; align-items: center; gap: 4px; margin-left: 6px;
  padding: 3px 9px; border-radius: 999px; font-size: 11px; font-weight: 750;
  line-height: 1; white-space: nowrap;
  vertical-align: middle; cursor: default;
  /* Solid pill, white text — the "精致明显" badge users recognize. A subtle
   * inner highlight ring + darker edge give it the polished look; tinted
   * outline variants read as washed-out in the timeline. */
  color: #fff; background: var(--badge-color);
  border: 1px solid color-mix(in srgb, var(--badge-color) 78%, #000);
  box-shadow: inset 0 0 0 1px rgba(255,255,255,.16), 0 1px 4px rgba(15,23,42,.16);
}
.xss-badge svg { flex: none; }
.xss-badge.ghost {
  color: var(--muted); cursor: pointer;
  border-color: var(--border); background: transparent; box-shadow: none;
}
.xss-badge.ghost:hover { color: var(--text); }
/* Local-whitelist member: green = "safe by your own choice" (the only place
 * green is allowed besides legit/empty states). */
.xss-badge.ghost.wl {
  color: var(--safe);
  border-color: color-mix(in srgb, var(--safe) 42%, var(--border));
  background: color-mix(in srgb, var(--safe) 8%, transparent);
}
.xss-badge.ghost.wl:hover { color: var(--safe); filter: brightness(1.1); }
.acts button[data-wl] {
  color: var(--safe);
  border-color: color-mix(in srgb, var(--safe) 45%, var(--border));
}
/* 举报 category chips — replace the 举报 button in place on first click. */
.rep-cats { display: flex; flex-wrap: wrap; align-items: center; gap: 5px; width: 100%; }
.rep-cats-label { flex: 0 0 100%; font-size: 11px; color: var(--muted); margin: 2px 0 1px; }
.rep-cats button {
  border: 1px solid color-mix(in srgb, var(--warn) 48%, var(--border));
  background: color-mix(in srgb, var(--warn) 9%, transparent); color: var(--warn);
  border-radius: 999px; padding: 4px 9px; font-size: 11px; font-weight: 650; cursor: pointer;
}
.rep-cats button:hover { filter: brightness(1.08); transform: translateY(-1px); }
/* v0.4 popover: soft 12px radius, deep layered shadow, pop-in scale. */
.pop {
  position: fixed; z-index: 2147482001; width: 280px; padding: 12px;
  margin: 0; /* .card's margin-top would shift the measured placement */
  max-width: calc(100vw - 16px);
  font-size: 12px; color: var(--text); border-radius: 12px;
  box-shadow: 0 18px 48px rgba(15,23,42,.22), 0 2px 8px rgba(15,23,42,.10);
  transform-origin: 12px 12px; animation: xpop .14s ease-out;
  pointer-events: auto;
}
.pop h4 { margin: 0 0 6px; font-size: 12.5px; font-weight: 750; }
.pop ul { margin: 6px 0; padding-left: 16px; color: var(--muted); }
.pop li { margin: 3px 0; }
/* v0.4 action buttons: pill shape with a per-action visual hierarchy —
 * data-b solid danger (primary), data-h muted outline, data-r warm outline,
 * data-a plain text link. */
.acts { display: flex; flex-wrap: wrap; align-items: center; gap: 7px; margin-top: 10px; }
.acts button {
  border: 1px solid var(--border); background: transparent; color: var(--text);
  border-radius: 999px; padding: 5px 10px; font-size: 11px; font-weight: 650;
  cursor: pointer; transition: transform .12s ease, background .12s ease, border-color .12s ease, color .12s ease, filter .12s ease;
}
.acts button:hover { transform: translateY(-1px); background: var(--hover); }
.acts button[data-b] {
  color: #fff; border-color: transparent;
  background: linear-gradient(180deg, color-mix(in srgb, var(--danger) 92%, #fff), var(--danger));
}
.acts button[data-b]:hover { filter: brightness(1.05); }
.acts button[data-h] {
  color: var(--muted);
  border-color: color-mix(in srgb, var(--muted) 32%, var(--border));
}
.acts button[data-r] {
  color: var(--warn);
  border-color: color-mix(in srgb, var(--warn) 48%, var(--border));
  background: color-mix(in srgb, var(--warn) 9%, transparent);
}
.acts button[data-a] { color: var(--muted); border-color: transparent; }
.acts button[data-report] {
  color: var(--warn);
  border-color: color-mix(in srgb, var(--warn) 46%, var(--border));
  background: color-mix(in srgb, var(--warn) 9%, transparent);
}
.acts button:disabled { cursor: default; transform: none; filter: none; opacity: .7; }
/* 举报 inline result line — text only, colored by outcome. */
.pop-status { margin-top: 8px; font-size: 11px; line-height: 1.5; }
.pop-status[data-kind="info"] { color: var(--muted); }
.pop-status[data-kind="ok"] { color: var(--danger); }
.pop-status[data-kind="err"] { color: var(--warn); }
@media (pointer: coarse) {
  .pill { min-height: 44px; }
  .acts button { min-height: 40px; padding-inline: 14px; }
  .xss-badge { min-height: 28px; }
}

/* ---- animated badge states (transform/opacity only) ---- */
.xss-badge.fresh { animation: xrise .22s ease-out; }
.xss-badge.known { animation: xpop .18s ease-out; }
.xss-badge .ntag {
  margin-left: 4px; padding: 0 5px; border-radius: 999px; font-size: 9px;
  font-weight: 700; color: var(--warn); border: 1px solid var(--warn);
  letter-spacing: .3px;
}
.xss-badge.analyzing {
  color: var(--brand); position: relative; overflow: hidden;
  background: color-mix(in srgb, var(--brand) 8%, transparent);
  border-color: color-mix(in srgb, var(--brand) 30%, transparent);
  box-shadow: none;
}
.xss-badge.analyzing::after {
  content: ""; position: absolute; inset: 0;
  background: linear-gradient(90deg, transparent, color-mix(in srgb, var(--brand) 14%, transparent), transparent);
  transform: translateX(-100%); animation: xshim 1.1s ease-in-out infinite;
}
.xss-checked { display: none !important; }
.xss-spin { animation: xspin .8s linear infinite; transform-origin: 50% 50%; }
/* Pending-undo badge (⏳ 5秒后处理 + 撤销) — warn-outlined, not a solid pill. */
.xss-badge.pending {
  color: var(--warn); cursor: default;
  background: color-mix(in srgb, var(--warn) 10%, transparent);
  border-color: var(--warn); box-shadow: none;
  animation: xpulse 1.6s ease-in-out infinite;
}
/* v0.4 "拉黑中" in-place badge: solid danger pill breathing on the tweet
 * while the auto queue works it, with a spinner ring around the icon —
 * THIS is the visible "the extension is doing something" moment. */
.xss-badge.acting {
  --badge-color: var(--danger);
  color: #fff; cursor: default; overflow: visible;
  background: linear-gradient(180deg, color-mix(in srgb, var(--danger) 92%, #fff), var(--danger));
  border-color: color-mix(in srgb, var(--danger) 90%, transparent);
  box-shadow: 0 0 0 2px color-mix(in srgb, var(--danger) 18%, transparent), 0 2px 9px color-mix(in srgb, var(--danger) 24%, transparent);
  animation: xactpulse 1.25s ease-in-out infinite;
}
.xss-badge.acting .xss-ico {
  position: relative; display: inline-flex; flex: none;
}
.xss-badge.acting .xss-ico::after {
  content: ""; position: absolute; inset: -4px; border-radius: 999px;
  border: 1.5px solid color-mix(in srgb, #fff 30%, transparent);
  border-top-color: #fff; animation: xspin .72s linear infinite;
}
@keyframes xactpulse {
  0%,100% { transform: translateY(0); filter: brightness(1); }
  50% { transform: translateY(-1px); filter: brightness(1.1); }
}
/* Queued-for-auto badge — quiet outline, the row is waiting its turn. */
.xss-badge.actqueued {
  color: var(--danger); cursor: default;
  background: color-mix(in srgb, var(--danger) 9%, transparent);
  border-color: color-mix(in srgb, var(--danger) 45%, transparent);
  box-shadow: none; animation: xpulse 1.8s ease-in-out infinite;
}
@keyframes xrise { from { opacity: 0; transform: translateY(4px); } }
@keyframes xpop  { from { opacity: 0; transform: scale(.9); } }
@keyframes xspin { to { transform: rotate(360deg); } }
@keyframes xshim { to { transform: translateX(100%); } }
@keyframes xpulse { 0%,100% { opacity: .55; } 50% { opacity: .95; } }
@keyframes xradar { to { transform: rotate(360deg); } }
@keyframes xbreath { 0%,100% { filter: saturate(1); } 50% { filter: saturate(1.35); } }
@keyframes qrowin {
  from { opacity: 0; transform: translateY(-7px) scale(.985); }
}
@keyframes pbarshift {
  to { background-position: 22px 0, 0 0; }
}

/* New-hit motion: one compact radar lap, slow at first then faster. */
.pill.hit-pulse .scan-radar {
  animation: xhitspin .82s cubic-bezier(.62, 0, 1, .62) 1, xhitglow .9s ease-out 1;
}
@keyframes xhitspin {
  0% { transform: rotate(0deg) scale(1); }
  42% { transform: rotate(72deg) scale(1.08); }
  100% { transform: rotate(360deg) scale(1); }
}
@keyframes xhitglow {
  0% { box-shadow: inset 0 0 0 1px color-mix(in srgb, var(--accent) 18%, transparent), 0 0 0 0 color-mix(in srgb, var(--accent) 0%, transparent); }
  32% { box-shadow: inset 0 0 0 1px color-mix(in srgb, var(--accent) 24%, transparent), 0 0 0 5px color-mix(in srgb, var(--accent) 18%, transparent); }
  100% { box-shadow: inset 0 0 0 1px color-mix(in srgb, var(--accent) 18%, transparent), 0 0 0 0 color-mix(in srgb, var(--accent) 0%, transparent); }
}

@media (prefers-reduced-motion: reduce) {
  .card.open { animation: fade .18s ease-out; }
  .card.closing { display: none; animation: none; }
  @keyframes fade { from { opacity: 0; } }
  .xss-badge.fresh, .xss-badge.known { animation: fade .18s ease-out; }
  .xss-badge.analyzing::after, .xss-spin { animation: none; }
  .xss-badge.pending { animation: none; opacity: .7; }
  .xss-badge.acting, .xss-badge.acting .xss-ico::after,
  .xss-badge.actqueued { animation: none; }
  .metric.tick, .m-plus { animation: none; }
  .m-plus { display: none; }
  .scan-radar.busy,
  .scan-radar.busy .scan-sweep,
  .qrow.new,
  .qrow.done.flip,
  .xss-act.queue.busy,
  .progress-seg.active { animation: none; }
  .pill.hit-pulse .scan-radar { animation: none; }
}
`,q=e=>e.replace(/[<>&"]/g,e=>({"<":`&lt;`,">":`&gt;`,"&":`&amp;`,'"':`&quot;`})[e]??e),ut=e=>e&&/^https:\/\/pbs\.twimg\.com\//.test(e)?e:void 0;function J(){try{for(let e of[document.body,document.documentElement]){if(!e)continue;let t=getComputedStyle(e).backgroundColor.match(/rgba?\((\d+)\s*,\s*(\d+)\s*,\s*(\d+)(?:\s*,\s*([\d.]+))?\)/);if(t&&(t[4]===void 0||Number(t[4])>.5))return .2126*Number(t[1])+.7152*Number(t[2])+.0722*Number(t[3])<128?`dark`:`light`}let e=getComputedStyle(document.documentElement).colorScheme;if(/dark/.test(e))return`dark`;if(/light/.test(e))return`light`}catch{}try{return matchMedia(`(prefers-color-scheme: dark)`).matches?`dark`:`light`}catch{return`dark`}}function dt(e=J()){for(let t of document.querySelectorAll(`.xss-mount, [data-xss-overlay], .xss-bubble, .xss.pop`))t.setAttribute(`data-xss-theme`,e);return e}function ft(e,t,n){e&&(e.textContent=t,e.dataset.kind=n,e.hidden=!1)}var pt={shield:`M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z`,"shield-alert":`M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10zM12 8v4M12 16h.01`,"shield-x":`M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10zM9.5 9.5l5 5M14.5 9.5l-5 5`,"shield-check":`M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10zM9 12l2 2 4-4`,x:`M18 6 6 18M6 6l12 12`};function Y(e,t=`currentColor`,n=16){return`<svg width="${n}" height="${n}" viewBox="0 0 24 24" fill="none"
    stroke="${t}" stroke-width="1.75" stroke-linecap="round"
    stroke-linejoin="round" aria-hidden="true"><path d="${pt[e]??pt.shield}"/></svg>`}var mt={spam:`垃圾`,porn_bot:`色情`,likely_spam:`疑似`,uncertain:`存疑`,legit:`正常`},ht={spam:{zh:`垃圾`,varName:`--danger`,ic:`shield-x`},porn_bot:{zh:`色情bot`,varName:`--danger`,ic:`shield-x`},likely_spam:{zh:`疑似垃圾`,varName:`--warn`,ic:`shield-alert`},uncertain:{zh:`不确定`,varName:`--neutral`,ic:`shield`},legit:{zh:`正常`,varName:`--safe`,ic:`shield-check`}};function gt(e,t=`tr`,n=`隐藏`,r={}){let i=document.createElement(`div`);i.className=`xss xss-bubble${t===`br`?` br`:``}`,i.setAttribute(`data-xss-theme`,J()),i.setAttribute(`role`,`status`),i.setAttribute(`aria-live`,`polite`);let a=document.createElement(`button`);a.className=`pill`,a.setAttribute(`aria-label`,`${H.acronym} 本页可疑账号`);let o=document.createElement(`div`);o.className=`card`,i.append(a,o);let s=!1,c=[],l=0,u=new Map,d=new Set,f=new Set,p=new Set,m=new Set,h=new Map,g=new Set,_=[],v=!1,y=new Set,b=new Map,x=[],S=new Set,C=r.autoProcess??!0,w=r.autoCategoryCount??0,T=r.autoScopeAll??!1,E=`queue`,D=new Map,ee=0,O=e=>D.set(e,++ee),te=(e,t)=>(D.get(A(t))??0)-(D.get(A(e))??0),k=0,A=e=>e.userId||`h:${e.handle}`,j=e=>u.get(A(e))??`pending`,ne=e=>{if(y.has(A(e))||S.has(A(e)))return!1;let t=j(e);return t===`pending`||t===`failed`},re=e=>e.some(e=>e.verdict.label===`spam`||e.verdict.label===`porn_bot`)?`--danger`:`--warn`;function M(){let e=0,t=0,n=0,r=0,i=0;for(let a of c)switch(j(a)){case`done`:e++;break;case`processing`:t++;break;case`queued`:n++;break;case`failed`:r++;break;default:i++}return{found:c.length,done:e,processing:t,queued:n,failed:r,pending:i,running:t+n}}function ie(e,t){return e<=0||t<=0?`0%`:`${Math.max(0,Math.min(100,e/t*100)).toFixed(2)}%`}function ae(e,t,n){return t<=0?``:`<span class="progress-seg ${e}" style="width:${ie(t,n)}"></span>`}function oe(e){let t=Math.max(1,e.found),n=Math.round(e.done/t*100),r=e.processing+e.queued+e.pending;return`<div class="block-progress" aria-label="处理进度 ${n}%">
      <div class="progress-head">
        <span>${r>0?`剩余 ${r}`:`处理完成`}</span>
        <b>${n}%</b>
      </div>
      <div class="progress-track">
        ${ae(`done`,e.done,t)}
        ${ae(`active`,e.processing,t)}
        ${ae(`queued`,e.queued,t)}
        ${ae(`failed`,e.failed,t)}
        ${ae(`idle`,e.pending,t)}
      </div>
    </div>`}function se(e){let t=Math.max(0,Math.min(100,e.percent)),n=Math.round(t*3.6);return`<span class="scan-pill">
      <span class="scan-radar ${e.busy?`busy`:``} ${e.danger?`danger`:``}" style="--angle:${n}deg">
        <span class="scan-sweep"></span>
        <span class="scan-core">${Y(e.iconName,e.iconColor,11)}</span>
      </span>
      <span class="scan-title">${e.title}</span>
      ${e.count?`<span class="scan-meta">${e.count}</span>`:``}
    </span>`}function N(){if(c.length){let e=M();if(e.running>0){a.innerHTML=se({iconName:`shield-x`,iconColor:`var(--danger)`,title:`${n}中`,count:`${e.done}/${e.found}`,percent:Math.max(8,Math.round(e.done/Math.max(1,e.found)*100)),busy:!0,danger:!0});return}if(e.done>0&&e.done+e.failed>=e.found){a.innerHTML=se({iconName:`shield-check`,iconColor:`var(--danger)`,title:`已${n}`,count:String(e.done),percent:100,danger:!0});return}a.innerHTML=se({iconName:`shield-alert`,iconColor:`var(${re(c)})`,title:`命中`,count:String(c.length),percent:100,busy:l>0,danger:!0});return}if(l>0){a.innerHTML=se({iconName:`shield`,iconColor:`var(--brand)`,title:`检查中`,count:String(l),percent:0,busy:!0});return}if(x.length>0){a.innerHTML=se({iconName:`shield-check`,iconColor:`var(--danger)`,title:`已处理`,count:String(x.length),percent:100,danger:!0});return}a.innerHTML=se({iconName:`shield-check`,iconColor:`var(--brand)`,title:`守护`,percent:100})}function P(){let e=C?w>0?`${w} 类自动 · ${T?`全局`:`仅评论区`}`:`全部仅标记`:`已暂停 · 仅标记`;return`<div class="auto-row">
      <button class="xss-sw" data-auto role="switch" aria-checked="${C}"
        aria-label="自动处理"></button>
      <span>自动处理</span>
      <span class="auto-hint">${e}</span>
    </div>`}function F(){o.querySelector(`[data-auto]`)?.addEventListener(`click`,()=>{C=!C,e.onToggleAuto?.(C),I()})}function I(){if(!c.length&&!x.length){o.innerHTML=`
        <div class="hd">${Y(`shield-check`,`var(--brand)`,16)}
          <span>${H.acronym} 已启用</span>
          <span class="x" data-x>${Y(`x`,`currentColor`,14)}</span></div>
        ${P()}
        <div class="sub" style="display:block;line-height:1.6">
          正在被动检查本页账号。发现可疑的垃圾/色情机器人时，会在这里提示并提供一键处理。</div>
        <div class="row"><span class="lnk" data-gov>为什么 / 治理</span></div>`,o.querySelector(`[data-x]`)?.addEventListener(`click`,me),o.querySelector(`[data-gov]`)?.addEventListener(`click`,()=>window.open(H.governance,`_blank`,`noopener`)),F();return}let t=M(),r=t.queued+t.pending,a=c.filter(e=>ne(e)&&!d.has(A(e))).length,s=c.filter(ne).length,l=t.done+t.processing+t.queued+t.failed>0,u=new Set(c.map(A)),h=x.filter(e=>!u.has(A(e))),_=[...c.filter(e=>m.has(A(e))),...h];E===`done`&&!_.length&&(E=`queue`);let v=(E===`done`?_:c.filter(e=>{let t=A(e);return!m.has(t)&&!g.has(t)})).sort(te);o.innerHTML=`
      <div class="hd">${Y(`shield-alert`,`var(--brand)`,16)}
        <span>${c.length?s||t.running?`本页发现 ${c.length} 个可疑账号`:`本页已处理 ${t.done} 个账号`:`近期已处理 ${_.length} 个账号`}</span>
        <span class="x" data-x>${Y(`x`,`currentColor`,14)}</span></div>
      ${P()}
      <div class="sub">
        <span class="metric" title="本页命中的可疑账号">
          <i style="background:var(--danger)"></i><b>${t.found}</b><em>命中</em>
        </span>
        <span class="metric" title="正在处理">
          <i style="background:var(--warn)"></i><b>${t.processing}</b><em>正在</em>
        </span>
        <span class="metric" title="等待处理">
          <i style="background:var(--muted)"></i><b>${r}</b><em>待处理</em>
        </span>
        <span class="metric${_.length?` tab`:``}${E===`done`?` on`:``}"
          data-done-chip ${_.length?`data-tab-done role="button" tabindex="0" aria-pressed="${E===`done`}"`:``}
          title="${t.failed?`失败 ${t.failed}，`:``}近期已处理（含之前页面与历史记录）${_.length?` · 点击查看明细`:``}">
          <i style="background:${t.failed?`var(--warn)`:`var(--danger)`}"></i><b>${_.length}</b><em>已处理</em>
        </span>
      </div>
      ${l?oe(t):``}
      <div class="queue-table">
        ${v.length?``:`<div class="queue-empty">${Y(`shield-check`,`var(--safe)`,13)}<span>本页暂无新命中 · 点「已处理」查看记录</span></div>`}
        ${v.map(e=>{let t=ht[e.verdict.label],r=`var(${t.varName})`,i=ut(e.avatarUrl),a=i?`<img src="${q(i)}" class="qavatar" alt="">`:`<span class="qavatar blank"></span>`,o=q(e.displayName?.trim()||`@${e.handle}`),s=e.snippet?q(e.snippet.replace(/\s+/g,` `).trim()).slice(0,60):``,c=A(e),l=!f.has(c);f.add(c);let u=j(e),m=u===`done`&&!p.has(c);u===`done`&&p.add(c);let h=[`qrow`,l?`new`:``,u===`processing`?`active`:u===`pending`?``:u,m?`flip`:``].filter(Boolean).join(` `),g=y.has(c),_=ne(e),v=_&&!d.has(c),x=u===`done`?`xss-act done`:u===`processing`?`xss-act queue busy`:u===`queued`?`xss-act queue`:u===`failed`?`xss-act retry`:`xss-act`,S=g?u===`done`?`已处理`:u===`failed`?`失败`:u===`queued`?`排队中`:`处理中`:u===`done`?`已${n}`:u===`processing`?`${n}中`:u===`queued`?`待处理`:u===`failed`?`重试`:n,C=g||u===`done`||u===`processing`||u===`queued`;return`<div class="${h}" data-rk="${q(c)}">
              <input type="checkbox" class="xss-row-cb" data-sel="${q(c)}"
                aria-label="选中 @${q(e.handle)}"
                ${v?`checked`:``} ${_?``:`disabled`}>
              ${a}
              <div class="qbody">
                <div class="qname">${o}</div>
                <div class="qmeta" style="color:${r}">@${q(e.handle)} · ${t.zh} ${(e.verdict.confidence*100).toFixed(0)}%<a class="qappeal" data-appeal-h="${q(e.handle)}"${e.userId?` data-appeal-u="${q(e.userId)}"`:``} title="误判？提交申诉（已预填账号信息）">误判</a></div>
                ${(()=>{let t=[];return e.source===`local-index`?(t.push(`<span class="qtag">公榜</span>`),e.tier&&t.push(`<span class="qtag">${e.tier===`confirmed`?`人工确认`:`自动收录`}</span>`)):e.source===`local-rule`?t.push(`<span class="qtag">规则</span>`):e.source===`cache`&&t.push(`<span class="qtag">缓存</span>`),e.categoryZh&&t.push(`<span class="qtag">${q(e.categoryZh)}</span>`),e.source===`local-rule`&&!g&&t.push(`<span class="qtag warn">需手动</span>`),t.length?`<div class="qtags" title="${q(e.verdict.reasons.join(`
`))}">${t.join(``)}</div>`:``})()}
                ${s?`<div class="qsnip">${s}</div>`:``}
                ${u===`processing`?`<div class="qnote" style="color:var(--danger)">${g?`自动${b.get(c)??`处理`}中…`:`正在${n}…`}</div>`:``}
                ${u===`queued`?`<div class="qnote" style="color:var(--brand)">排队等待处理</div>`:``}
                ${u===`failed`?`<div class="qnote" style="color:var(--warn)">${g?`自动${b.get(c)??`处理`}失败`:`处理失败`} · <a href="https://x.com/${q(e.handle)}" target="_blank" rel="noopener" style="color:var(--warn)">手动处理</a></div>`:``}
                ${u===`done`?`<div class="qnote" style="color:var(--danger)">✓ 已${g?`自动${b.get(c)??`处理`}`:n}</div>`:``}
              </div>
              <button class="${x}" data-one="${q(c)}"${C?` disabled`:``}>${S}</button>
            </div>`}).join(``)}
      </div>
      ${c.length?t.running>0?`<button class="btn" disabled style="background:var(--brand)">${n}中 · 正在 ${t.processing} · 待 ${t.queued}</button>`:s===0?`<button class="btn" disabled style="background:color-mix(in srgb, var(--danger) 12%, transparent);color:var(--danger);opacity:1">✓ 已全部处理 (${t.done})</button>`:a===0?`<button class="btn" disabled style="opacity:.55">未选中任何账号 (剩余 ${s})</button>`:`<button class="btn" data-run>一键${n}选中 ${a}${t.done?` · 已完成 ${t.done}`:``}${a<s?` · 跳过 ${s-a}`:``}</button>`:``}
      <div class="row"><span class="lnk" data-each>逐个查看处理</span>
        <span class="lnk" data-ign>忽略本页</span></div>`,F(),o.querySelector(`[data-x]`)?.addEventListener(`click`,me),o.querySelector(`[data-ign]`)?.addEventListener(`click`,()=>{e.onDismiss(),i.remove()}),o.querySelector(`[data-each]`)?.addEventListener(`click`,e.onReviewEach);for(let t of o.querySelectorAll(`[data-appeal-h]`))t.addEventListener(`click`,()=>{let n=t.dataset.appealH;if(!n)return;let r=t.dataset.appealU;e.onAppeal({handle:n,...r?{userId:r}:{}})});let S=o.querySelector(`[data-tab-done]`),C=()=>{E=E===`done`?`queue`:`done`,I()};S?.addEventListener(`click`,C),S?.addEventListener(`keydown`,e=>{(e.key===`Enter`||e.key===` `)&&(e.preventDefault(),C())}),o.querySelectorAll(`[data-sel]`).forEach(e=>{e.addEventListener(`change`,()=>{let t=e.dataset.sel;t&&(e.checked?d.delete(t):d.add(t),I())})}),o.querySelectorAll(`[data-one]`).forEach(e=>{e.addEventListener(`click`,()=>{let t=e.dataset.one,n=c.find(e=>A(e)===t);n&&ne(n)&&fe([A(n)])})});let w=o.querySelector(`.queue-table`);w&&E===`queue`&&(k>0&&(w.scrollTop=k),w.addEventListener(`scroll`,()=>{k=w.scrollTop},{passive:!0}));let T=o.querySelector(`[data-run]`);T?.addEventListener(`click`,()=>{T.disabled=!0,T.textContent=`处理中…`,fe(c.filter(e=>ne(e)&&!d.has(A(e))).map(A))})}function ce(e){m.has(e)||h.has(e)||h.set(e,setTimeout(()=>{h.delete(e),le(e)},400))}function le(e){m.has(e)||g.has(e)||_.includes(e)||(_.push(e),ue())}async function ue(){if(!v){v=!0;try{for(;_.length;){let e=_.shift();if(!e)break;await de([e]),await new Promise(e=>setTimeout(e,160))}}finally{v=!1}}}function de(e){let t=e.filter(e=>!m.has(e)&&!g.has(e));if(!t.length)return Promise.resolve();for(let e of t)g.add(e);let n=()=>{for(let e of t)g.delete(e),m.add(e);s&&I()},r=o.querySelector(`[data-done-chip]`),a=o.querySelector(`.queue-table`),c=window.matchMedia(`(prefers-reduced-motion: reduce)`).matches;if(!s||E!==`queue`||!r||!a||c)return n(),Promise.resolve();let l=r.getBoundingClientRect(),u=a.getBoundingClientRect();if(!l.width)return n(),Promise.resolve();let d=[],f=0;for(let e of t){let t=o.querySelector(`[data-rk="${CSS.escape(e)}"]`),n=t?.getBoundingClientRect(),r=!!t&&!!n?.width&&n.bottom>u.top+4&&n.top<u.bottom-4;if(!t||!n||!r)continue;let a=t.cloneNode(!0);a.className=`q-fly`,a.style.left=`${n.left}px`,a.style.top=`${n.top}px`,a.style.width=`${n.width}px`,t.style.overflow=`hidden`,t.animate([{height:`${n.height}px`,opacity:1},{height:`0px`,opacity:0,paddingTop:`0px`,paddingBottom:`0px`}],{duration:380,easing:`ease-in`,fill:`forwards`});let s=l.left+l.width/2-(n.left+n.width/2),c=l.top+l.height/2-(n.top+n.height/2),p=f++*70;i.appendChild(a),d.push(new Promise(e=>{a.animate([{transform:`translate(0,0) scale(1)`,opacity:1},{transform:`translate(${s}px,${c}px) scale(.06)`,opacity:.25}],{duration:520,delay:p,easing:`cubic-bezier(.55,-.05,.75,.35)`,fill:`both`}).onfinish=()=>{a.remove(),e()}}))}let p=()=>{n();let e=o.querySelector(`[data-done-chip]`);if(!e)return;e.classList.remove(`tick`),e.offsetWidth,e.classList.add(`tick`);let r=document.createElement(`span`);r.className=`m-plus`,r.textContent=`+${t.length}`,e.appendChild(r),setTimeout(()=>r.remove(),850)};return d.length?Promise.all(d).then(p):(p(),Promise.resolve())}function fe(t){if(!t.length)return;z=!1,clearTimeout(V);for(let e of[...t].reverse())O(e);t.forEach((e,t)=>{u.set(e,t===0?`processing`:`queued`),d.delete(e)}),N(),s&&I();let n=[],r=0;e.onProcess(t,(e,i)=>{u.set(e,i?`done`:`failed`),O(e),i&&n.push(e),r++,r>=t.length&&n.length&&setTimeout(()=>void de([...n]),700);let a=t.find(e=>u.get(e)===`queued`);a&&(u.set(a,`processing`),O(a)),N(),s&&I()})}function L(){s=!0,!c.length&&x.length&&(E=`done`),o.classList.remove(`closing`),o.classList.add(`open`),I()}function R(){let e=s;s=!1,o.classList.remove(`open`),e&&o.classList.add(`closing`)}o.addEventListener(`animationend`,e=>{e.animationName===`cardout`&&o.classList.remove(`closing`)});let z=!1,pe=!1,B=r.autoExpand!==!1,V;function me(){pe=!0,z=!1,clearTimeout(V),R()}function U(){clearTimeout(V),V=setTimeout(()=>{z&&s&&M().running===0&&(z=!1,R())},6e3)}o.addEventListener(`pointerenter`,()=>clearTimeout(V)),o.addEventListener(`pointerleave`,()=>{z&&s&&M().running===0&&U()}),a.addEventListener(`click`,()=>{s?me():(pe=!1,z=!1,clearTimeout(V),L())}),i.addEventListener(`keydown`,e=>{e.key===`Escape`&&me()}),N();try{localStorage.getItem(`xss_onboarded`)||(localStorage.setItem(`xss_onboarded`,`1`),L(),setTimeout(()=>{c.length||R()},6e3))}catch{}return{el:i,update(e){let t=new Set(e.map(A)),n=c.filter(e=>{let n=A(e);return!t.has(n)&&y.has(n)&&!S.has(n)&&u.has(n)}),r=[...e,...n],o=r.length>c.length;o&&(E=`queue`);for(let e of r){let t=A(e);D.has(t)||O(t)}c=r;let l=new Set([...r.map(A),...S]);for(let e of[...u.keys()])l.has(e)||u.delete(e);for(let e of[...d])l.has(e)||d.delete(e);for(let e of[...f])l.has(e)||f.delete(e);for(let e of[...p])l.has(e)||p.delete(e);for(let e of[...y])l.has(e)||y.delete(e);for(let e of[...b.keys()])l.has(e)||b.delete(e);for(let e of[...D.keys()])l.has(e)||D.delete(e);for(let e of[...m])l.has(e)||m.delete(e);for(let e of[...g])l.has(e)||g.delete(e);for(let[e,t]of[...h])l.has(e)||(clearTimeout(t),h.delete(e));i.style.display=``,N(),s&&I(),o&&(a.classList.remove(`hit-pulse`),a.offsetWidth,a.classList.add(`hit-pulse`),setTimeout(()=>a.classList.remove(`hit-pulse`),950))},setScanning(e){l=Math.max(0,e),s||N()},pageReset(){let e=new Set,t=[];for(let n of c){let r=A(n),i=u.get(r);(i===`done`||i===`failed`)&&!S.has(r)?(S.add(r),x.push(n)):y.has(r)&&(i===`queued`||i===`processing`)&&(e.add(r),t.push(n))}c=t;let n=t=>S.has(t)||e.has(t);for(let e of[...u.keys()])n(e)||u.delete(e);for(let e of[...y])n(e)||y.delete(e);for(let e of[...b.keys()])n(e)||b.delete(e);for(let e of[...f])n(e)||f.delete(e);for(let e of[...p])n(e)||p.delete(e);for(let e of[...D.keys()])n(e)||D.delete(e);d.clear(),E=`queue`,k=0;for(let e of h.values())clearTimeout(e);h.clear(),m.clear(),g.clear(),_.length=0,pe=!1,s&&t.length?(clearTimeout(V),I()):(z=!1,clearTimeout(V),R()),N()},markAuto(e,t,n){y.add(e),n&&b.set(e,n),u.set(e,t),O(e),clearTimeout(V),(t===`queued`||t===`processing`)&&B&&!s&&!pe&&(z=!0,s=!0,o.classList.add(`open`)),N(),s&&I(),t===`done`&&ce(e),z&&s&&M().running===0&&U()},markManual(e,t){c.some(t=>A(t)===e)&&(b.set(e,t),u.set(e,`done`),y.add(e),O(e),N(),s&&I(),ce(e))},setAutoProcess(e,t,n){C=e,t!==void 0&&(w=t),n!==void 0&&(T=n),s&&I()},setVerb(e){n=e,N(),s&&I()},setAutoExpand(e){B=e}}}function _t(e,t=!1){let n=document.createElement(`span`);return n.className=`xss-badge ${t?`actqueued`:`acting`}`,n.setAttribute(`aria-label`,t?`等待自动${e}`:`自动${e}中`),n.innerHTML=`<span class="xss-ico">${Y(`shield-x`,`currentColor`,12)}</span><span>${t?`待${q(e)}`:`${q(e)}中`}</span>`,n}function vt(){let e=document.createElement(`span`);return e.className=`xss-badge analyzing`,e.setAttribute(`aria-label`,`在线 AI 检测中`),e.innerHTML=`<span class="xss-spin">${Y(`shield`,`currentColor`,12)}</span><span>检测中</span>`,e}function yt(){let e=document.createElement(`span`);return e.className=`xss-checked`,e.hidden=!0,e.setAttribute(`aria-hidden`,`true`),e}var bt=[{mode:`local`,verb:`隐藏`},{mode:`mute`,verb:`静音`},{mode:`block`,verb:`拉黑`}],xt=null;function St(){if(xt?.host.isConnected)return xt;let e=document.createElement(`div`);e.setAttribute(`data-xss-overlay`,``),e.setAttribute(`data-xss-theme`,J()),e.style.cssText=`position:fixed;left:0;top:0;width:0;height:0;z-index:2147483001;`,document.documentElement.appendChild(e),xt=e.attachShadow({mode:`open`});let t=document.createElement(`style`);return t.textContent=lt,xt.appendChild(t),xt}function Ct(e,t,n,r=`fresh`,i=`local`){let a=document.createElement(`span`);a.tabIndex=0;let o=!!e&&(e.label===`spam`||e.label===`porn_bot`||e.label===`likely_spam`),s=e?o?`var(--danger)`:`var(${ht[e.label].varName})`:`var(--muted)`;if(t.whitelisted)a.className=`xss-badge ghost wl`,a.setAttribute(`aria-label`,`MXGA：本地白名单 · 不检测、不处理`),a.innerHTML=`${Y(`shield`,`currentColor`,13)}<span>白名单</span>`;else if(!e)a.className=`xss-badge ghost`,a.setAttribute(`aria-label`,`MXGA：未命中名单 · 悬停可手动处理`),a.innerHTML=`${Y(`shield`,`currentColor`,13)}<span>检查</span>`;else{let t=ht[e.label],n=r===`list`||r===`cache`||r===`rule`;a.className=`xss-badge ${n?`known`:`fresh`}`,a.style.setProperty(`--badge-color`,s);let i=r===`list`?`命中公共名单`:r===`rule`?`命中官方关键词规则（本机比对）`:r===`cache`?`本地缓存命中`:`在线 AI 检测结果`;a.setAttribute(`aria-label`,`${t.zh} ${(e.confidence*100).toFixed(0)}% · ${i}`);let o=n?``:`<span class="ntag">首发</span>`;a.innerHTML=`${Y(t.ic,`currentColor`,12)}<span>${mt[e.label]}</span>${o}`}let c=null,l,u=0,d=()=>{clearTimeout(l),cancelAnimationFrame(u),c?.remove(),c=null,window.removeEventListener(`scroll`,f,!0),document.removeEventListener(`pointerdown`,p,!0)},f=()=>{d()},p=e=>{if(!c)return;let t=e.composedPath();t.includes(a)||t.includes(c)||m(!0)},m=(e=!1)=>{if(!e&&c?.matches(`:hover`)){h();return}d()},h=()=>{clearTimeout(l),l=setTimeout(m,120)},g=()=>clearTimeout(l),_=()=>{if(g(),c)return;c=document.createElement(`div`),c.className=`xss pop card`,c.setAttribute(`data-xss-theme`,J()),c.style.display=`block`;let m=bt.map(e=>`<button data-act="${e.mode}"${e.mode===i?` data-b`:``}>${q(e.verb)}</button>`).join(``),_=t.onReport&&r!==`list`&&r!==`rule`?`<button data-report title="举报给公共名单人工审核（需 GitHub 授权）">举报为spam</button>`:``,v=t.onWhitelist?t.whitelisted?`<button data-wl title="移出本地白名单后，该账号重新参与检测">移出白名单</button>`:`<button data-wl title="加入本地白名单：永不标记、永不自动处理（仅本机，不上传）">加入白名单</button>`:``;c.innerHTML=t.whitelisted?`
      <h4 style="color:var(--safe)">本地白名单</h4>
      <div style="color:var(--muted);line-height:1.55">
        该账号在你的本地白名单中：不检测、不标记、不自动处理，即使公共名单或规则命中。</div>
      <div class="acts">${v}</div>`:e?`
      <h4 style="color:${s}">${ht[e.label].zh} · ${(e.confidence*100).toFixed(0)}%</h4>
      <ul>${e.reasons.map(e=>`<li>${q(e)}</li>`).join(``)}</ul>
      ${n?`<div style="color:var(--muted)">${q(n)}</div>`:``}
      <div class="acts">
        ${o?m:``}
        ${_}
        ${v}
        <button data-a title="打开 GitHub 提交误判申诉 issue（已预填账号信息）">误判申诉</button>
      </div>
      <div class="pop-status" data-report-status hidden></div>`:`
      <h4>手动处理</h4>
      <div style="color:var(--muted);line-height:1.55">
        未命中公共名单与官方规则。确认是垃圾/骚扰账号时，可手动处理（5 秒内可撤销），或举报给公共名单。</div>
      <div class="acts">${m}${_}${v}</div>
      <div class="pop-status" data-report-status hidden></div>`;for(let e of c.querySelectorAll(`[data-act]`))e.addEventListener(`click`,()=>t.onAct(e.dataset.act));c.querySelector(`[data-a]`)?.addEventListener(`click`,t.onAppeal);let y=c.querySelector(`[data-wl]`);if(y&&t.onWhitelist){let e=t.onWhitelist;y.addEventListener(`click`,()=>void e())}let b=c.querySelector(`[data-report]`);if(b&&t.onReport){let e=t.onReport,n=async t=>{let n=c?.querySelector(`[data-report-status]`);c?.querySelector(`[data-report-cats]`)?.remove(),b.hidden=!1,b.disabled=!0,b.textContent=`举报中…`,ft(n,`正在提交举报（${ct[t]}）…`,`info`);let r;try{r=await e(t)}catch{r={ok:!1,message:`举报失败，请稍后重试`}}c&&(ft(n,r.message,r.ok?`ok`:`err`),b.textContent=r.ok?`已举报`:`举报为spam`,b.disabled=r.ok,clearTimeout(l),l=setTimeout(d,r.ok?2600:3600))};b.addEventListener(`click`,e=>{if(e.stopPropagation(),g(),c?.querySelector(`[data-report-cats]`))return;let t=document.createElement(`div`);t.className=`rep-cats`,t.setAttribute(`data-report-cats`,``),t.innerHTML=`<span class="rep-cats-label">这是哪类垃圾？</span>${at.map(e=>`<button type="button" data-cat="${e}">${q(ct[e])}</button>`).join(``)}`;for(let e of t.querySelectorAll(`[data-cat]`))e.addEventListener(`click`,t=>{t.stopPropagation(),n(e.dataset.cat)});b.hidden=!0,b.insertAdjacentElement(`afterend`,t),ft(c?.querySelector(`[data-report-status]`),`选择类型后提交；不属于这些类型的争吵/观点不在治理范围`,`info`)})}for(let e of c.querySelectorAll(`button:not([data-report])`))e.addEventListener(`click`,d);c.addEventListener(`mouseenter`,g),c.addEventListener(`mouseleave`,h),St().appendChild(c);let x=e=>{if(!c)return;let t=c.offsetWidth||260,n=c.offsetHeight||120,r=Math.min(Math.max(8,e.left),window.innerWidth-t-8),i=e.bottom+6,a=i+n>window.innerHeight-8?Math.max(8,e.top-n-6):i;c.style.left=`${r}px`,c.style.top=`${a}px`};x(a.getBoundingClientRect());let S=()=>{if(!c)return;let e=a.getBoundingClientRect();if(!a.isConnected||!e.width&&!e.height){d();return}x(e),u=requestAnimationFrame(S)};u=requestAnimationFrame(S),window.addEventListener(`scroll`,f,{capture:!0,passive:!0}),document.addEventListener(`pointerdown`,p,!0)},v=!1;return a.addEventListener(`pointerdown`,e=>{v=e.pointerType!==`mouse`}),a.addEventListener(`click`,e=>{v&&=(e.preventDefault(),e.stopPropagation(),c?m(!0):_(),!1)}),a.addEventListener(`pointerenter`,e=>{e.pointerType===`mouse`&&_()}),a.addEventListener(`focus`,()=>{v||_()}),a.addEventListener(`mouseleave`,h),a.addEventListener(`blur`,h),a}var wt=`
:host { all: initial; }
* { box-sizing: border-box; font-family: system-ui,-apple-system,"Segoe UI",sans-serif; }
:host {
  --surface: rgba(13,17,23,.94); --border: rgba(255,255,255,.10);
  --shadow: 0 8px 28px rgba(0,0,0,.45); --text: #E6EDF3; --muted: #8B949E;
  --brand: #0EA5E9; --danger: #EF4444; --warn: #F59E0B; --safe: #16A34A;
}
@media (prefers-color-scheme: light) {
  :host {
    --surface: rgba(255,255,255,.97); --border: rgba(15,23,42,.12);
    --shadow: 0 8px 28px rgba(15,23,42,.18); --text: #0F172A; --muted: #475569;
    --brand: #0369A1; --danger: #DC2626; --warn: #B45309; --safe: #15803D;
  }
}
:host([data-xss-theme="dark"]) {
  --surface: rgba(13,17,23,.94); --border: rgba(255,255,255,.10);
  --shadow: 0 8px 28px rgba(0,0,0,.45); --text: #E6EDF3; --muted: #8B949E;
  --brand: #0EA5E9; --danger: #EF4444; --warn: #F59E0B; --safe: #16A34A;
}
:host([data-xss-theme="light"]) {
  --surface: rgba(255,255,255,.97); --border: rgba(15,23,42,.12);
  --shadow: 0 8px 28px rgba(15,23,42,.18); --text: #0F172A; --muted: #475569;
  --brand: #0369A1; --danger: #DC2626; --warn: #B45309; --safe: #15803D;
}
.kolpop {
  position: fixed; z-index: 2147483001; width: 300px;
  background: var(--surface); border: 1px solid var(--border);
  border-left: 3px solid var(--accent, var(--muted));
  border-radius: 12px; box-shadow: var(--shadow);
  color: var(--text); -webkit-font-smoothing: antialiased;
  padding: 10px 12px; font-size: 12.5px; line-height: 1.45;
}
.kol-head { display: flex; align-items: center; gap: 6px; margin-bottom: 8px; }
.kol-name { font-weight: 600; font-size: 13.5px; min-width: 0;
  overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.kol-name .h { color: var(--muted); font-weight: 400; }
.kol-flag { flex: none; font-size: 10.5px; padding: 1px 6px; border-radius: 999px;
  border: 1px solid currentColor; }
.kol-flag.wl { color: var(--safe); }
.kol-grid { display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 6px 10px; }
.kv { min-width: 0; }
.kv .k { display: block; color: var(--muted); font-size: 11px; }
.kv b { font-size: 13px; font-variant-numeric: tabular-nums; }
.kv .s { display: block; color: var(--muted); font-size: 10.5px; }
.kv .na { color: var(--muted); font-weight: 400; }
.kol-rows { margin-top: 8px; }
.kol-row { display: flex; justify-content: space-between; gap: 8px; padding: 2px 0; }
.kol-row .k { color: var(--muted); }
.kol-foot { margin-top: 8px; padding-top: 6px; border-top: 1px solid var(--border);
  color: var(--muted); font-size: 10.5px; display: flex; justify-content: space-between; }
.kol-foot a { color: var(--brand); text-decoration: none; }
`;function Tt(e){return e.replace(/&/g,`&amp;`).replace(/</g,`&lt;`).replace(/>/g,`&gt;`).replace(/"/g,`&quot;`)}function Et(e){return typeof e!=`number`||!Number.isFinite(e)||e<0?null:e>=1e8?`${(e/1e8).toFixed(1).replace(/\.0$/,``)}亿`:e>=1e4?`${(e/1e4).toFixed(1).replace(/\.0$/,``)}万`:e.toLocaleString(`zh-CN`)}function Dt(e){if(typeof e!=`number`||!Number.isFinite(e)||e<0)return null;let t;return t=e<60?`${e} 天`:e<365?`${Math.round(e/30)} 个月`:`${(e/365).toFixed(1).replace(/\.0$/,``)} 年`,{main:t,since:null}}function Ot(e,t=2){return typeof e!=`number`||!Number.isFinite(e)||e<0?null:e.toFixed(t)}var kt=null,At=null,X=null,jt,Mt=0,Nt=null;function Pt(){if(At?.host.isConnected)return At;kt=document.createElement(`div`),kt.setAttribute(`data-xss-kol`,``),kt.setAttribute(`data-xss-theme`,J()),kt.style.cssText=`position:fixed;left:0;top:0;width:0;height:0;z-index:2147483001;`,document.documentElement.appendChild(kt),At=kt.attachShadow({mode:`open`});let e=document.createElement(`style`);return e.textContent=wt,At.appendChild(e),At}function Ft(){clearTimeout(jt),cancelAnimationFrame(Mt),X?.remove(),X=null,Nt=null,window.removeEventListener(`scroll`,It,!0),document.removeEventListener(`pointerdown`,Lt,!0)}function It(){Ft()}function Lt(e){if(!X)return;let t=e.composedPath();Nt&&t.includes(Nt)||t.includes(X)||Rt(!0)}function Rt(e=!1){if(!e&&X?.matches(`:hover`)){zt();return}Ft()}function zt(){clearTimeout(jt),jt=setTimeout(()=>Rt(),120)}function Bt(e){let t=e.displayName?.trim(),n=Dt(e.accountAgeDays),r=e.accountCreatedAt&&!Number.isNaN(Date.parse(e.accountCreatedAt))?(()=>{let t=new Date(e.accountCreatedAt);return`${t.getFullYear()}.${String(t.getMonth()+1).padStart(2,`0`)} 注册`})():null,i=Et(e.followersCount),a=Et(e.followingCount),o=Et(e.statusesCount),s=typeof e.favouritesCount==`number`&&typeof e.followersCount==`number`&&e.followersCount>0?Ot(e.favouritesCount/e.followersCount):null,c=typeof e.favouritesCount==`number`&&typeof e.statusesCount==`number`&&e.statusesCount>0?Ot(e.favouritesCount/e.statusesCount,1):null,l=(e,t,n)=>`<div class="kv"><span class="k">${e}</span>${t?`<b>${t}</b>`:`<b class="na">—</b>`}${n?`<span class="s">${n}</span>`:``}</div>`,u=[e.trust?`<div class="kol-row"><span class="k">综合可信</span><span style="color:${{safe:`var(--safe)`,ok:`var(--brand)`,warn:`var(--warn)`,risk:`var(--danger)`}[e.trust.tier]}"><b>${e.trust.score}</b>/100 · ${{safe:`靠谱`,ok:`一般`,warn:`存疑`,risk:`高风险`}[e.trust.tier]}</span></div>`:``,typeof e.originalRatio==`number`?`<div class="kol-row"><span class="k">原创比</span><span>${(e.originalRatio*100).toFixed(0)}%<span class="k">（采样 ${e.sampledTweets??`?`} 条）</span></span></div>`:``,typeof e.topicFocus==`number`?`<div class="kol-row"><span class="k">主题集中度</span><span>${(e.topicFocus*100).toFixed(0)}%</span></div>`:``].filter(Boolean).join(``);return`
  <div class="kol-head">
    <span class="kol-name">${Tt(t||`@${e.handle}`)} <span class="h">@${Tt(e.handle)}</span>${e.verified?` ✓`:``}</span>
    ${e.whitelisted?`<span class="kol-flag wl">白名单</span>`:``}
  </div>
  <div class="kol-grid">
    ${l(`账号年龄`,n?n.main:null,n?r:null)}
    ${l(`粉丝`,i)}
    ${l(`关注`,a)}
    ${l(`推文`,o)}
    ${l(`赞粉比`,s)}
    ${l(`均赞/推`,c)}
  </div>
  ${u?`<div class="kol-rows">${u}</div>`:``}
  <div class="kol-foot"><span>filtrationX 本地数据 · 不联网查询</span><a href="https://x.com/${encodeURIComponent(e.handle)}" target="_blank" rel="noopener">查看主页 ↗</a></div>`}function Vt(e,t){let n=Pt();X||(X=document.createElement(`div`),X.className=`kolpop`,X.setAttribute(`data-xss-theme`,J()),X.addEventListener(`mouseenter`,()=>clearTimeout(jt)),X.addEventListener(`mouseleave`,zt),n.appendChild(X)),X.style.setProperty(`--accent`,t.whitelisted?`var(--safe)`:t.trust?{safe:`var(--safe)`,ok:`var(--brand)`,warn:`var(--warn)`,risk:`var(--danger)`}[t.trust.tier]:(t.accountAgeDays??1/0)<30?`var(--warn)`:`var(--brand)`),X.innerHTML=Bt(t),Nt=e;let r=e=>{if(!X)return;let t=X.offsetWidth||300,n=X.offsetHeight||140,r=e.right+8;r+t>window.innerWidth-8&&(r=e.left-t-8),r<8&&(r=Math.min(Math.max(8,e.left),window.innerWidth-t-8));let i=e.top;i+n>window.innerHeight-8&&(i=Math.max(8,e.top+e.height-n)),X.style.left=`${Math.max(8,r)}px`,X.style.top=`${Math.max(8,i)}px`};r(e.getBoundingClientRect()),cancelAnimationFrame(Mt);let i=()=>{if(!X||!Nt)return;let e=Nt.getBoundingClientRect();if(!Nt.isConnected||!e.width&&!e.height){Ft();return}r(e),Mt=requestAnimationFrame(i)};Mt=requestAnimationFrame(i),window.addEventListener(`scroll`,It,{capture:!0,passive:!0}),document.addEventListener(`pointerdown`,Lt,!0)}function Ht(e=!1){Rt(e)}function Ut(){return!!X}function Wt(){zt()}var Gt=`xss:kol:v1`,Kt=3*864e5,qt=600,Jt=200,Yt=40,Xt=40,Zt=20,Z=null,Qt=!1,$t;function en(e){return e.trim().replace(/^@+/,``).toLowerCase()}async function tn(){if(!Qt){Qt=!0;try{let e=(await chrome.storage.local.get(Gt))[Gt];if(!e)return;let t=Date.now();for(let[n,r]of Object.entries(e))n===`__proto__`||n===`constructor`||n===`toString`||!r||typeof r!=`object`||typeof r.handle!=`string`||t-(r.updatedAt??0)>Kt||(Z??=new Map,Z.set(n,r))}catch{}}}function nn(){clearTimeout($t),$t=setTimeout(()=>void rn(),2e3)}async function rn(){if(clearTimeout($t),$t=void 0,!Z)return;let e=Date.now();for(let[t,n]of Z)e-n.updatedAt>Kt&&Z.delete(t);if(Z.size>qt){let e=[...Z.entries()].sort((e,t)=>e[1].updatedAt-t[1].updatedAt);for(let[t]of e.slice(0,Z.size-qt))Z.delete(t)}let t={};for(let[e,n]of Z)t[e]=n;try{await chrome.storage.local.set({[Gt]:t})}catch{}}function an(e){let t=en(e.handle);if(!t||!e.statusId)return;Z??=new Map;let n=Z.get(t)??{handle:t,total:0,original:0,seen:[],tokens:{},tokenTotal:0,updatedAt:0};if(e.userId&&!n.userId&&(n.userId=e.userId),e.displayName&&!n.displayName&&(n.displayName=e.displayName),n.seen.includes(e.statusId)){n.updatedAt=Date.now(),Z.set(t,n),nn();return}if(n.seen.push(e.statusId),n.seen.length>Yt&&n.seen.splice(0,n.seen.length-Yt),n.total<Jt&&(n.total+=1,e.original&&(n.original+=1),e.original&&e.text)){let t=0;for(let r of new Set(sn(e.text)))if(n.tokens[r]=(n.tokens[r]??0)+1,n.tokenTotal+=1,++t>=Xt)break}n.updatedAt=Date.now(),Z.set(t,n),nn()}function on(e){let t=Z?.get(en(e));if(!t)return{};let n={};t.total>=5&&(n.originalRatio=t.original/t.total,n.sampledTweets=t.total);let r=cn(t);return r!==void 0&&(n.topicFocus=r),n}function sn(e){let t=[];for(let n of e.toLowerCase().matchAll(/[a-z][a-z0-9_']{2,}|[\u4e00-\u9fff]+|\d{2,}/g)){let e=n[0];if(/[\u4e00-\u9fff]/.test(e)){if(e.length<2)continue;for(let n=0;n+2<=e.length;n++)t.push(e.slice(n,n+2))}else t.push(e)}return t}function cn(e){if(e.total<5||e.tokenTotal<Zt)return;let t=e.total,n=0;for(let r of Object.values(e.tokens)){let e=r/t;n+=e*e}let r=e.tokenTotal/t;if(!(r<=0))return Math.max(0,Math.min(1,n/r))}function ln(e){return typeof e!=`number`||!Number.isFinite(e)?50:e<7?5:e<30?25:e<90?50:e<365?70:85}function un(e,t){if(typeof e!=`number`||typeof t!=`number`||e<0||t<0||t===0&&e===0)return 50;let n=e/Math.max(1,t);return t>2e3&&e<t*.5?10:n>=1?75:n>=.3?55:n>=.1?35:12}function dn(e,t,n){return typeof e!=`number`||typeof t!=`number`||t<=0?50:e/t>20?10:typeof n==`number`&&n>0&&t>1e3&&e/n<.05?35:70}function fn(e){return typeof e==`number`?e>=.8?80:e>=.5?60:e>=.2?35:10:50}function pn(e){let t=Math.round(.3*ln(e.accountAgeDays)+.25*un(e.followersCount,e.followingCount)+.25*dn(e.favouritesCount,e.followersCount,e.statusesCount)+.2*fn(e.originalRatio));return{score:t,tier:t>=75?`safe`:t>=55?`ok`:t>=35?`warn`:`risk`}}var mn={porn:`badge`,crypto:`badge`,gambling:`badge`,resource:`badge`,marketing:`badge`,other:`badge`},hn={enabled:!0,bubble:!0,bubblePos:`tr`,actionMode:`local`,categoryActions:{...mn},autoProcess:!0,autoScope:`replies`,autoTierMode:`full`,autoExpand:!0,edgeBase:``,officialRulesEnabled:!0,ruleTelemetry:!0,ruleHitsAutoAct:!1,kolCardEnabled:!0,followingWhitelist:!0},gn=`xss:settings`,_n=gn;function vn(e){return{...hn,...e??{},categoryActions:{...mn,...e?.categoryActions??{}}}}async function yn(){try{return vn((await chrome.storage.local.get(gn))[gn])}catch{return vn(void 0)}}async function bn(e,t){try{let n=await yn();await chrome.storage.local.set({[gn]:{...n,[e]:t}})}catch{}}function xn(e){let t=(t,n)=>{n===`local`&&t[gn]&&e(vn(t[gn].newValue))};return chrome.storage.onChanged.addListener(t),()=>chrome.storage.onChanged.removeListener(t)}var Sn=`xss:list:v2`,Cn=`xss:whitelist:v1`;async function wn(){try{let e=(await chrome.storage.local.get(Sn))[Sn];return e&&Array.isArray(e.entries)?e:null}catch{return null}}async function Tn(){try{let e=(await chrome.storage.local.get(Cn))[Cn];return e&&Array.isArray(e.entries)?e:null}catch{return null}}var En=RegExp(`[­͏؜᠎​‌‍‎‏‪‫‬‭‮⁠⁡⁢⁣⁤⁦⁧⁨⁩﻿]`,`g`);function Dn(e){return e.replace(En,``)}var On=new Map;function kn(e,t){if(!e)return-1;if(!/^[\x20-\x7f]+$/.test(e))return t.indexOf(e);let n=On.get(e);if(!n){let t=e.replace(/[.*+?^${}()|[\]\\]/g,`\\$&`);n=RegExp(`(?<![a-z0-9_])${t}(?![a-z0-9_])`),On.size>=512&&On.clear(),On.set(e,n)}return n.exec(t)?.index??-1}function An(e,t,n){let r=0,i=0,a=-1;for(let o of e){let e=Dn(o).toLowerCase().length;if(e&&a<0&&r+e>t&&(a=i),r+=e,i+=o.length,a>=0&&r>=t+n)return[a,i-a]}return[Math.max(0,a),n]}var jn=200;function Mn(e,t,n){if(e.length<=jn)return e;let r=Math.floor((jn-n)/2),i=Math.max(0,t-r),a=Math.min(e.length,i+jn);return`${i>0?`…`:``}${e.slice(i,a)}${a<e.length?`…`:``}`}var Nn={h:`handle`,d:`display_name`,b:`bio`,t:`tweet`,a:`any`},Pn=`xss:rules:custom`,Fn=`xss:rules:disabled`,In=200,Ln=/[㐀-鿿豈-﫿]/,Rn=e=>!!e&&Ln.test(e),zn=[`handle`,`display_name`,`bio`,`tweet`,`any`],Bn=[],Vn=[],Hn=new Set,Un=!0,Wn=!1;function Gn(e,t,n,r,i){return{pattern:e,patternLower:Dn(e).toLowerCase(),patternCJK:Rn(e),field:t,label:n,category:r,origin:i}}function Kn(e){let t=[];if(Array.isArray(e))for(let n of e){if(!Array.isArray(n)||n.length<3)continue;let[e,r,i]=n;if(typeof e!=`string`||!e)continue;let a=Nn[String(r)];a&&t.push(Gn(e,a,String(i)[0]===`p`?`porn_bot`:`spam`,st(String(i)[1]),`official`))}Bn=t}function qn(e){if(!Array.isArray(e))return[];let t=[],n=new Set;for(let r of e){if(!r||typeof r!=`object`)continue;let{pattern:e,field:i,category:a}=r;if(typeof e!=`string`)continue;let o=e.trim();if(!o||o.length>In||!i||!zn.includes(i)||!a||!at.includes(a))continue;let s=`${o.toLowerCase()}${i}`;if(!n.has(s)&&(n.add(s),t.push({pattern:o,field:i,category:a}),t.length>=200))break}return t}function Jn(e){Vn=qn(e).map(e=>Gn(e.pattern,e.field,e.category===`porn`?`porn_bot`:`spam`,e.category,`custom`))}function Yn(e){Hn=new Set(Array.isArray(e)?e.filter(e=>typeof e==`string`):[])}async function Xn(){if(!Wn){Wn=!0;try{Un=(await yn()).officialRulesEnabled;let e=await chrome.storage.local.get([Pn,Fn]);Jn(e[Pn]),Yn(e[Fn])}catch{}}}try{chrome.storage.onChanged.addListener((e,t)=>{t===`local`&&(e[`xss:rules:custom`]&&Jn(e[Pn].newValue),e[`xss:rules:disabled`]&&Yn(e[Fn].newValue),e[`xss:settings`]&&(Un=e[_n].newValue?.officialRulesEnabled!==!1))})}catch{}function Zn(e,t){if(!e.length)return null;let n=Dn(t.handle).toLowerCase(),r=Dn(t.displayName).toLowerCase(),i=Dn(t.bio).toLowerCase(),a=[...t.recentTweets,t.triggeringComment??``],o=a.map(e=>Dn(e).toLowerCase());for(let s of e){if(s.origin===`official`&&Hn.has(s.pattern))continue;let e=s.patternLower;if(!e)continue;let c=t=>s.origin===`official`?kn(e,t):t.indexOf(e),l=!s.patternCJK||!t.tweetsTranslated,u=s.field===`any`,d,f=``,p=-1;if((u||s.field===`handle`)&&(p=c(n))>=0)d=`handle`,f=t.handle;else if((u||s.field===`display_name`)&&(p=c(r))>=0)d=`display_name`,f=t.displayName;else if((u||s.field===`bio`)&&(p=c(i))>=0)d=`bio`,f=t.bio;else if((u||s.field===`tweet`)&&l){let e=o.findIndex(e=>c(e)>=0);e>=0&&(d=`tweet`,f=a[e]??``,p=c(o[e]??``))}if(d){let[t,n]=An(f,Math.max(0,p),e.length);return{pattern:s.pattern,label:s.label,category:s.category,origin:s.origin,field:d,matchedText:Mn(f,t,n)}}}return null}function Qn(e){if(Un){let t=Zn(Bn,e);if(t)return t}return Zn(Vn,e)}var $n={p:`porn_bot`,s:`spam`},er=null,tr=null,nr=new Date(0).toISOString(),rr=new Set,ir=new Set,ar=!1;function or(e){let t=new Set,n=new Set;for(let[r,i]of e.entries)r&&t.add(r),i&&n.add(i.toLowerCase());rr=t,ir=n}function sr(e,t){let[n,r,i]=e,a=$n[String(i)[0]??``];if(!a)return null;let o=st(String(i)[1]),s=String(i)[2]===`h`?`confirmed`:`auto`;return{userId:n,handle:r,verdict:{label:a,confidence:1,reasons:[`公共黑名单收录 · ${ct[o]}${s===`confirmed`?` · 人工确认`:` · 自动收录`}`]},category:o,tier:s,source:`curated`,updatedAt:t}}function cr(e){let t=new Map,n=new Map;for(let r of e.entries){if(!Array.isArray(r)||r.length<3)continue;let[e,i,a]=r;$n[String(a)[0]??``]&&(e&&t.set(e,r),i&&n.set(i.toLowerCase(),r))}er=t,tr=n,nr=new Date(e.fetchedAt).toISOString(),Kn(e.rules)}try{chrome.storage.onChanged.addListener((e,t)=>{t===`local`&&(e[`xss:list:v2`]?.newValue&&cr(e[Sn].newValue),e[`xss:whitelist:v1`]?.newValue&&or(e[Cn].newValue))})}catch{}async function lr(){return null}async function ur(){try{await chrome.runtime.sendMessage({type:`list-sync`})}catch{}}async function dr(){if(ar)return;let e=await Tn();e&&or(e);let t=await wn();if(t){cr(t),ar=!0;return}let n=await lr();if(n){cr(n),ar=!0,ur();return}er??=new Map,tr??=new Map,ur()}function fr(e){let t=er?.get(e);return t?sr(t,nr):null}function pr(e){let t=tr?.get(e.toLowerCase());return t?sr(t,nr):null}function mr(e,t){return!!(e&&rr.has(e)||t&&ir.has(t.toLowerCase()))}function hr(e,t){if(e&&rr.has(e)||t&&ir.has(t.toLowerCase()))return null;if(e){let t=fr(e);if(t)return t}return t?pr(t):null}async function gr(e){let t=await chrome.runtime.sendMessage({type:`local-data`,mutation:e});if(!t?.ok)throw Error(t?.error??`本地数据写入失败`);return t.data}var _r=`xss:whitelist:local`;async function vr(e){let t=await gr({kind:`whitelist`,mutation:e});return Ar(Nr(t.store)),t.changed}var yr=e=>vr({action:`add`,input:e}),br=e=>vr({action:`remove`,handle:e}),xr=5e3,Sr=/^[A-Za-z0-9_]{1,15}$/,Cr=/^\d{1,32}$/,wr=/^https:\/\/pbs\.twimg\.com\/[^\s"'<>]{1,300}$/;function Tr(e){if(typeof e!=`string`)return null;let t=e.trim().replace(/^@+/,``);return Sr.test(t)?t:null}var Er=new Map,Dr=new Set,Or=new Set,kr=null;function Ar(e){let t=new Map,n=new Set;for(let r of e.entries)r?.handle&&t.set(r.handle.toLowerCase(),r.userId),r?.userId&&n.add(r.userId);Er=t,Dr=n,Or=new Set(e.excluded)}function jr(e){if(!Array.isArray(e))return[];let t=[],n=new Set;for(let r of e){let e=Tr(r?.handle);if(!e)continue;let i=e.toLowerCase();if(!n.has(i)&&(n.add(i),t.push({handle:e,...typeof r.userId==`string`&&Cr.test(r.userId)?{userId:r.userId}:{},...typeof r.displayName==`string`&&r.displayName?{displayName:r.displayName.slice(0,80)}:{},...typeof r.avatarUrl==`string`&&wr.test(r.avatarUrl)?{avatarUrl:r.avatarUrl}:{},source:r.source===`following`?`following`:`manual`,addedAt:typeof r.addedAt==`number`&&Number.isFinite(r.addedAt)&&r.addedAt>=0?r.addedAt:0}),t.length>=2e4))break}return t}function Mr(e){if(!Array.isArray(e))return[];let t=[],n=new Set;for(let r of e){let e=Tr(typeof r==`string`?r:void 0);if(!e)continue;let i=e.toLowerCase();if(!n.has(i)&&(n.add(i),t.push(i),t.length>=xr))break}return t}function Nr(e){let t=e&&typeof e==`object`?e:{};return{entries:jr(t.entries),excluded:Mr(t.excluded)}}async function Pr(){return Nr((await chrome.storage.local.get(_r))[_r])}Promise.resolve();async function Fr(){Ar(await Pr());try{let e=chrome.storage.onChanged;if(kr===e)return;kr=e,e.addListener((e,t)=>{t!==`local`||!e[`xss:whitelist:local`]||Ar(Nr(e[_r].newValue))})}catch{}}function Ir(e,t){if(e&&Dr.has(e))return!0;if(t&&Er.has(t.toLowerCase())){let n=Er.get(t.toLowerCase());return!e||!n||n===e}return!1}function Lr(e){return!!e&&Or.has(e.toLowerCase())}async function Rr(e,t){!t||!e.viewerFollowing||e.viewerIsSelf||Ir(e.userId,e.handle)||Lr(e.handle)||await yr({handle:e.handle,...e.userId?{userId:e.userId}:{},...e.displayName?{displayName:e.displayName}:{},...e.avatarUrl?{avatarUrl:e.avatarUrl}:{},source:`following`}).catch(()=>{})}var zr=class{limit;active=0;waiting=[];constructor(e=3){if(this.limit=e,!Number.isInteger(e)||e<1)throw Error(`limit must be a positive integer`)}async acquire(){if(this.active<this.limit){this.active+=1;return}await new Promise(e=>this.waiting.push(e))}release(){let e=this.waiting.shift();e?e():--this.active}async run(e){await this.acquire();try{return await e()}finally{this.release()}}};function Br(e){return e.authenticated&&e.localResult===`unknown`&&e.requestsStarted<40}function Vr(e){return e.label===`legit`||e.label===`uncertain`||e.label===`likely_spam`&&e.confidence<.8?`silent`:`badge`}var Hr=new Set([`removed`,`rejected`,`whitelisted`,`viewer_ignored`]);function Ur(e,t){return!t||!Hr.has(t)||e.label===`legit`?e:{label:`legit`,confidence:1,reasons:[t===`whitelisted`?`官方白名单保护`:t===`viewer_ignored`?`你与该账号有关注/屏蔽关系，不检测`:`判定已被人工撤回`]}}var Wr=new Set([`spam`,`porn_bot`,`likely_spam`,`uncertain`,`legit`]);function Gr(e){if(!e||typeof e!=`object`)return null;let t=e;return!t.label||!Wr.has(t.label)||typeof t.confidence!=`number`||!Number.isFinite(t.confidence)||!Array.isArray(t.reasons)||!t.reasons.every(e=>typeof e==`string`)?null:{label:t.label,confidence:t.confidence,reasons:t.reasons}}async function Kr(e,t,n={}){let r=n.send??(e=>chrome.runtime.sendMessage(e)),i=n.writeCache??ye,a=n.now??Date.now,o;try{o=await r({type:`classify`,sig:t})}catch{return{status:`failed`}}if(!o.ok)return o.error===`no_token`?{status:`unauthenticated`}:{status:`failed`};let s=o.data,c=typeof s?.status==`number`?s.status:0;if(c===401)return{status:`unauthenticated`};if(c<200||c>=300)return{status:`failed`,httpStatus:c};let l=Gr(s?.body?.record?.verdict);if(!l)return{status:`failed`,httpStatus:c};let u=typeof s?.body?.record?.status==`string`?s.body.record.status:void 0,d=Ur(l,u),f=typeof s?.body?.record?.model==`string`?s.body.record.model:`edge`;return await i(e,{verdict:d,signalsHash:_e(t),model:f,ts:a(),handle:t.handle,displayName:t.displayName,...t.avatarUrl?{avatarUrl:t.avatarUrl}:{}}),{status:`classified`,verdict:d,cached:s?.body?.cached===!0,...u?{reviewStatus:u}:{}}}var qr=`mxga_stats_v1`;async function Jr(){return new Promise(e=>{chrome.storage.local.get(qr,t=>{let n=t?.[qr]??{};e({scanned:n.scanned??0,hitPublic:n.hitPublic??0,blocked:n.blocked??0,firstUsedAt:n.firstUsedAt??Date.now()})})})}async function Yr(e,t=1){let n=await Jr();n[e]=(n[e]??0)+Math.max(0,Math.floor(t)),n.firstUsedAt||=Date.now(),await new Promise(e=>chrome.storage.local.set({[qr]:n},()=>e()))}async function Xr(e){await Yr(e,1)}var Zr=`xss:tpl:v1`,Qr=3e3,$r=14*864e5;function ei(e){let t=e.trim().toLowerCase().replace(/\s+/g,` `),n=5381;for(let e=0;e<t.length;e++)n=(n*33^t.charCodeAt(e))>>>0;return n.toString(36)}async function ti(){try{let e=(await chrome.storage.local.get(Zr))[Zr];return Object.assign(Object.create(null),e&&typeof e==`object`&&!Array.isArray(e)?e:{})}catch{return Object.create(null)}}async function ni(e){try{await chrome.storage.local.set({[Zr]:e})}catch{}}var ri=Promise.resolve();function ii(e){let t=ri.then(e,e);return ri=t.catch(()=>{}),t}function ai(e,t=Date.now(),n=null){let r=(e.triggeringComment??``).trim();return r.length<6?Promise.resolve(0):ii(async()=>{let i=await ti(),a=e.handle.toLowerCase(),o=ei(r),s=(i[a]??[]).filter(e=>t-e.ts<$r);if(n&&s.some(e=>e.id===n)){let e=s.filter(e=>e.h===o&&e.id!==n).length;return i[a]=s,await ni(i),e}let c=s.filter(e=>e.h===o).length;s.push({h:o,ts:t,...n?{id:n}:{}}),i[a]=s.slice(-6);let l=Object.keys(i);return l.length>Qr&&l.map(e=>[e,Math.max(...(i[e]??[]).map(e=>e.ts),0)]).sort((e,t)=>e[1]-t[1]).slice(0,l.length-Qr).forEach(([e])=>delete i[e]),await ni(i),c})}var oi=`xss:blocklist:v2`,si=`xss:blocked`,ci=`xss:stats`,li=`xss:pending-actions`;async function ui(e,t){try{return(await chrome.storage.local.get(e))[e]??t}catch{return t}}async function di(e,t){try{await chrome.storage.local.set({[e]:t})}catch{}}async function fi(){let e=await ui(oi,null);if(e)return e;let t=(await ui(si,[])).map(e=>({id:e,handle:e.startsWith(`h:`)?e.slice(2):e,source:`manual`,ts:Date.now()}));return t.length&&await di(oi,t),t}function pi(e){return!e.displayName&&!e.verdict&&!e.tweetId&&(e.handle===e.id||`h:${e.handle}`===e.id)&&/^\d+$/.test(e.handle)}async function mi(e){let t=await fi(),n=t.findIndex(t=>t.id===e.id);if(n>=0){let r=t[n];if(!r||!pi(r))return;t[n]={...r,...e}}else t.push(e);await di(oi,t)}async function hi(e,t){let n=await fi(),r=n.findIndex(t=>t.id===e),i=n[r];if(!i)return;let a={...i,...t};for(let e of Object.keys(t))t[e]===void 0&&delete a[e];n[r]=a,await di(oi,n)}var gi=Promise.resolve();function _i(e){let t=gi.then(e,e);return gi=t.catch(()=>{}),t}async function vi(){return ui(li,[])}async function yi(e){return _i(async()=>{let t=await vi();t.some(t=>t.id===e.id)||(t.push(e),await di(li,t))})}async function bi(e){return _i(async()=>{let t=await vi(),n=t.filter(t=>t.id!==e);n.length!==t.length&&await di(li,n)})}async function xi(e){await di(oi,(await fi()).filter(t=>t.id!==e)),await V(e)}async function Si(){return ui(ci,{detections:0,cacheHits:0,blocks:0,byLabel:{}})}async function Ci(e){let t=await Si();t.detections+=e.detections??0,t.cacheHits+=e.cacheHits??0,t.blocks+=e.blocks??0,e.label&&(t.byLabel[e.label]=(t.byLabel[e.label]??0)+1),await di(ci,t)}var wi=c({X_PUBLIC_BEARER:()=>Gi,performXAction:()=>Hi,retryDelayForAttempt:()=>Ui});function Ti(e){try{let t=e?.message;return typeof t==`string`&&t?t:String(e)}catch{return`unknown error`}}function Ei(){try{return document.cookie.match(/ct0=([^;]+)/)?.[1]??``}catch{return``}}function Di(){return location.hostname.endsWith(`twitter.com`)?`https://twitter.com`:`https://x.com`}function Oi(e){return String(e??``).trim().replace(/^@+/,``)}function ki(e){try{return Number(localStorage.getItem(e)||0)||0}catch{return 0}}function Ai(e,t){try{localStorage.setItem(e,String(Math.max(0,Math.floor(t))))}catch{}}function ji(){try{let e=JSON.parse(localStorage.getItem(na)||`{}`);return{count:Math.max(0,Number(e.count||0)||0),cooldownUntil:Math.max(0,Number(e.cooldownUntil||0)||0)}}catch{return{count:0,cooldownUntil:0}}}function Mi(e){try{localStorage.setItem(na,JSON.stringify({count:Math.max(0,Number(e.count||0)||0),cooldownUntil:Math.max(0,Number(e.cooldownUntil||0)||0)}))}catch{}}function Ni(e){return e>0&&e%Zi===0?Qi:e>0&&e%Yi===0?Xi:0}function Pi(e){if(!e)return;let t=Number(e);if(Number.isFinite(t))return Math.max(0,t*1e3);let n=Date.parse(e);return Number.isFinite(n)?Math.max(0,n-Date.now()):void 0}function Fi(e){if(e<=0)return;let t=ji();Mi({...t,cooldownUntil:Math.max(t.cooldownUntil,Date.now()+e)})}function Ii(e){e.status===429?Fi(e.retryAfterMs??$i):e.retryable&&Fi(ea)}function Li(){let e=ji().count+1,t=Ni(e);Mi({count:e,cooldownUntil:t?Date.now()+t:0})}async function Ri(){for(;;){let e=ji().cooldownUntil-Date.now();if(e>0){await ra(Math.min(1e3,e));continue}let t=ki(ta),n=Math.floor(Math.random()*Ji),r=t+qi+n-Date.now();if(r<=0)break;await ra(Math.min(1e3,r))}Ai(ta,Date.now())}async function zi(e){let t=ia.then(e,e);return ia=t.catch(()=>{}),t}function Bi(e,t,n,r){return new Promise((i,a)=>{let o;try{o=new XMLHttpRequest}catch(e){a(e);return}try{o.open(`POST`,e,!0),o.withCredentials=!0,o.timeout=r;for(let[e,n]of Object.entries(t))o.setRequestHeader(e,n);o.onload=()=>i({status:o.status,header:e=>{try{return o.getResponseHeader(e)}catch{return null}}}),o.onerror=()=>a(Error(`网络错误`)),o.ontimeout=()=>a(Error(`请求超时（${r}ms）`)),o.onabort=()=>a(Error(`请求被中止`)),o.send(n)}catch(e){a(e)}})}async function Vi(e,t,n){try{let r=Ei();if(!r)return{ok:!1,retryable:!1,reason:`未取到 ct0（未登录 X，或浏览器阻止了 content script 读取 cookie）`};let i=Oi(n),a=new URLSearchParams;if(t&&/^\d+$/.test(t))a.set(`user_id`,t);else if(i)a.set(`screen_name`,i);else return{ok:!1,retryable:!1,reason:`既无合法 user_id 也无 screen_name，无法定位账号`};let o;try{o=await Bi(`${Di()}${Ki[e]}`,{authorization:Wi,"x-csrf-token":r,"x-twitter-auth-type":`OAuth2Session`,"x-twitter-active-user":`yes`,"content-type":`application/x-www-form-urlencoded`},a.toString(),15e3)}catch(e){return{ok:!1,retryable:!0,reason:`请求异常：${Ti(e)}`}}let s=o.status,c=s>=200&&s<300,l=s===408||s===425||s===429||s>=500;return{ok:c,status:s,retryAfterMs:Pi(o.header(`retry-after`)),retryable:l,reason:c?void 0:`X 返回 HTTP ${s}`}}catch(e){return{ok:!1,retryable:!0,reason:`请求异常：${Ti(e)}`}}}async function Hi(e,t,n,r=()=>!0){return zi(async()=>{if(!r()||(await Ri(),!r()))return{ok:!1,retryable:!1};let i=await Vi(e,t,n);return i.ok?Li():Ii(i),i})}function Ui(e,t){return e.retryable?e.status===429?Math.min(6e4,e.retryAfterMs??$i):Math.min(12e3,900*2**Math.max(0,t-1)):0}var Wi,Gi,Ki,qi,Ji,Yi,Xi,Zi,Qi,$i,ea,ta,na,ra,ia,aa=o((()=>{Wi=`Bearer AAAAAAAAAAAAAAAAAAAAANRILgAAAAAAnNwIzUejRCOuH5E6I8xnZz4puTs%3D1Zv7ttfk8LF81IUq16cHjhLTvJu4FA33AGWWjCpTnA`,Gi=Wi,Ki={block:`/i/api/1.1/blocks/create.json`,mute:`/i/api/1.1/mutes/users/create.json`,unblock:`/i/api/1.1/blocks/destroy.json`},qi=1200,Ji=700,Yi=45,Xi=8e3,Zi=120,Qi=6e4,$i=45e3,ea=8e3,ta=`mxga:last-x-action`,na=`mxga:x-action-round`,ra=e=>new Promise(t=>setTimeout(t,e)),ia=Promise.resolve()}));function oa(e){let t=H.appealNewIssue;if(e?.handle){let n=new URLSearchParams;n.set(`handle`,`@${e.handle}`),e.userId&&n.set(`userid`,e.userId),n.set(`title`,`[Appeal] @${e.handle} wrongly listed`),t+=`&${n.toString()}`}window.open(t,`_blank`,`noopener`)}var sa=50;async function ca(e,t){let n;try{n=await chrome.runtime.sendMessage({type:`report`,sig:e,category:t})}catch{return{ok:!1,message:`网络错误，举报未提交`}}if(!n||!n.ok){if(n?.error===`no_token`){try{chrome.runtime.sendMessage({type:`open_options`})}catch{}return{ok:!1,message:`举报需先在设置页用 GitHub 授权（已为你打开设置）`}}return{ok:!1,message:`网络错误，举报未提交`}}let{status:r,body:i}=n.data??{status:0,body:{}};if(r>=200&&r<300&&i.ok)return i.duplicate?{ok:!0,message:`你已举报过该账号，感谢`}:i.status===`whitelisted`?{ok:!0,message:`该账号已被官方列入白名单，举报已忽略`}:i.status===`viewer_ignored`?{ok:!0,message:`这是你自己的账号，举报已忽略`}:{ok:!0,message:`已举报，进入人工审核队列，感谢贡献`};switch(r){case 401:try{chrome.runtime.sendMessage({type:`open_options`})}catch{}return{ok:!1,message:`GitHub 授权已失效，请在设置页重新授权`};case 403:return{ok:!1,message:`你的举报权限已被限制`};case 429:return{ok:!1,message:`举报过于频繁，请稍后再试`};case 503:return{ok:!1,message:`服务暂未就绪，请稍后再试`};default:return{ok:!1,message:`举报失败，请稍后重试`}}}function Q(e){return e?.closest(`article`)??null}function la(e){return e===`block`?`拉黑`:e===`mute`?`静音`:`隐藏`}function ua(e){return Object.values(e.categoryActions).filter(e=>e!==`badge`).length}async function da(e,t,n=()=>!0){if(!n())return!1;if(e===`local`)return!0;let{performXAction:r,retryDelayForAttempt:i}=await Promise.resolve().then(()=>(aa(),wi)),a=await r(e,t.userId,t.handle,n);if(a.ok)return!0;let o=i(a,1);return o>0?(await new Promise(e=>setTimeout(e,o)),(await r(e,t.userId,t.handle,n)).ok):!1}var fa=/^(following|正在关注|關注中|フォロー中|팔로잉|abonnements|siguiendo|seguindo|folge ich|volgend)$/i;function pa(){if(location.pathname!==`/home`)return!1;let e=document.querySelector(`[role="tablist"] [role="tab"][aria-selected="true"]`);return!!e&&fa.test((e.textContent??``).trim())}function ma(e){if(e.querySelector(`[data-testid="socialContext"]`))return!1;let t=e.closest(`[data-testid="cellInnerDiv"]`);return t?t.querySelectorAll(`article[data-testid="tweet"]`).length===1:!1}function ha(){return location.pathname.match(/^\/[^/]+\/status\/(\d+)/)?.[1]??null}function ga(e){for(let t of e.querySelectorAll(`a[href*="/status/"]`)){if(!t.querySelector(`time`))continue;let e=(t.getAttribute(`href`)??``).match(/\/status\/(\d+)/);if(e?.[1])return e[1]}return null}function _a(e,t){let n=document.createElement(`span`);n.className=`xss-mount`,n.style.cssText=`display:inline-flex;align-items:center;align-self:center;vertical-align:middle;flex:none;`,n.setAttribute(`data-xss-theme`,J());let r=n.attachShadow({mode:`open`}),i=document.createElement(`style`);i.textContent=lt,r.append(i,t()),va(e).appendChild(n)}function va(e){try{if(getComputedStyle(e).flexDirection!==`column`)return e;let t=e.querySelector(`a[href^="/"]`);for(;t&&t.parentElement!==e;)t=t.parentElement;let n=t??e.firstElementChild;return n instanceof HTMLElement?n:e}catch{return e}}function ya(e){return e.querySelectorAll(`.xss-mount, .xss-pending`)}function $(e){ya(e).forEach(e=>e.remove())}var ba=5e3,xa=d({matches:[`https://x.com/*`,`https://twitter.com/*`],cssInjectionMode:`manual`,async main(e){let t=null,n=!1,r=new Map,i=new WeakMap,a=[],o=new Map,s=new Set,c=new Set;async function l(e,t){if(/^\d+$/.test(t.handle))return;let n=(await fi()).find(t=>t.id===e);!n||!pi(n)||await hi(e,{handle:t.handle,...t.displayName?{displayName:t.displayName}:{},...t.avatarUrl?{avatarUrl:t.avatarUrl}:{}})}let u=new Set,d=new zr,f=0,p=0,m=!1,h=await yn();if(!h.enabled)return;console.info(`[MXGA] content script ready · build 2026-09-06 (fp-reduction)`),xn(e=>{let n=e.actionMode!==h.actionMode;if(h=e,t?.setAutoProcess(e.autoProcess,ua(e),e.autoScope===`all`),t?.setAutoExpand(e.autoExpand),n){t?.setVerb(la(e.actionMode));for(let e of document.querySelectorAll(`.xss-mount`))e.shadowRoot?.querySelector(`.xss-badge.pending`)||e.remove();W()}}),await pe(),await dr(),await Xn(),await Fr(),await tn();async function g(){let e=m;try{let e=await chrome.runtime.sendMessage({type:`auth_status`});m=e?.ok===!0&&e.data?.authenticated===!0}catch{m=!1}return e!==m}await g();let _=e=>e.userId||`h:${e.handle}`,v=e=>Ir(e.userId,e.handle)||mr(e.userId,e.handle);chrome.runtime.onMessage.addListener((e,t,n)=>{if(e?.type===`block_queue_exec`)return(async()=>{try{let t=e.item;if(!t||!t.u&&!t.h){n({ok:!1,retryable:!1});return}let r=Pe()??H,i=()=>h.enabled&&(!t.h||t.h.toLowerCase()!==(r??``).toLowerCase())&&!v({...t.u?{userId:t.u}:{},handle:t.h});if(!i()){n({ok:!1,retryable:!1,skipped:!0});return}let{performXAction:a}=await Promise.resolve().then(()=>(aa(),wi)),o=await a(`block`,t.u||void 0,t.h,i);if(o.ok){let e=t.u||`h:${t.h}`;B(e),mi({id:e,handle:t.h,source:`block_all`,reason:`黑名单一键拉黑`,ts:Date.now()})}n(o)}catch{n({ok:!1,retryable:!1})}})(),!0}),chrome.runtime.onMessage.addListener((e,t,n)=>{if(e?.type===`blocks_sync_fetch`)return(async()=>{try{let{X_PUBLIC_BEARER:t}=await Promise.resolve().then(()=>(aa(),wi)),r=document.cookie.match(/(?:^|;\s*)ct0=([^;]+)/)?.[1]??``;if(!r){n({error:`not_logged_in`});return}let i=typeof e.cursor==`string`?e.cursor:`-1`,a=`https://x.com/i/api/1.1/blocks/list.json?count=200&skip_status=true&include_entities=false&cursor=${encodeURIComponent(i)}`,o=await fetch(a,{headers:{authorization:t,"x-csrf-token":r,"x-twitter-auth-type":`OAuth2Session`,accept:`application/json`},credentials:`include`});if(o.status===401||o.status===403){n({error:`not_logged_in`});return}if(o.status===429){n({error:`rate_limited`});return}if(!o.ok){n({error:`http_${o.status}`});return}let s=await o.json();n({users:(s.users??[]).map(e=>({u:typeof e.id_str==`string`?e.id_str:``,h:typeof e.screen_name==`string`?e.screen_name.toLowerCase():``,...typeof e.name==`string`&&e.name?{n:e.name}:{},...typeof e.profile_image_url_https==`string`&&e.profile_image_url_https?{a:e.profile_image_url_https}:{}})).filter(e=>e.u||e.h),next_cursor:String(s.next_cursor??`0`)})}catch{n({error:`network`})}})(),!0}),chrome.runtime.onMessage.addListener((e,t,n)=>{if(e?.type===`x_unblock_exec`)return(async()=>{try{let{performXAction:t}=await Promise.resolve().then(()=>(aa(),wi));n(await t(`unblock`,e.u||void 0,e.h,()=>h.enabled))}catch{n({ok:!1,retryable:!1})}})(),!0});try{chrome.runtime.sendMessage({type:`block_queue_hello`}).catch(()=>{})}catch{}let y,b=null,x=``,S=()=>{clearTimeout(y),y=void 0};document.addEventListener(`mouseover`,e=>{if(!h.kolCardEnabled)return;let t=e.target instanceof Element?e.target:null;if(!t)return;let n=t.closest(`[data-testid="User-Name"]`);if(!n){(y||b)&&(S(),Wt());return}let r=n.querySelector(`a[href^="/"]`),i=/^\/([A-Za-z0-9_]{1,15})(?:$|\/)/.exec(r?.getAttribute(`href`)??``);if(!i){S(),Wt();return}let a=i[1]??``;if(!a){S(),Wt();return}b&&a.toLowerCase()===x.toLowerCase()&&(y!==void 0||Ut())||(S(),Wt(),Ht(),x=a,b=n,y=setTimeout(()=>{y=void 0;let e=b;if(!e)return;let t=Se(e.closest(`article[data-testid="tweet"]`)??null,a);if(!Object.keys(t).length){let e=Ue();e&&e.toLowerCase()===a.toLowerCase()&&(t=Se(document.querySelector(`[data-testid="primaryColumn"]`),e))}let n=Ir(t.userId,a)||mr(t.userId,a);if(!Object.keys(t).length&&!n)return;let r=e.querySelector(`a[href^="/"]`)?.textContent?.trim()??``;Vt(e,{handle:a,displayName:r&&!/^@/.test(r)&&r.toLowerCase()!==a.toLowerCase()?r:void 0,verified:t.isVerified,accountAgeDays:t.accountAgeDays,accountCreatedAt:t.accountCreatedAt,followersCount:t.followersCount,followingCount:t.followingCount,statusesCount:t.statusesCount,favouritesCount:t.favouritesCount,whitelisted:n,viewerFollowing:t.viewerFollowing,...on(a),trust:pn({accountAgeDays:t.accountAgeDays,followersCount:t.followersCount,followingCount:t.followingCount,statusesCount:t.statusesCount,favouritesCount:t.favouritesCount,...on(a)})})},450))},!0);function C(){let e=new Set;for(let t of document.querySelectorAll(`[data-xss-hidden-key]`)){let n=t.getAttribute(`data-xss-hidden-key`);if(!n)continue;let r=t.matches(`article`)?t:t.querySelector(`article`),i=n.startsWith(`h:`)?n.slice(2):r?We(r):void 0;v({userId:n.startsWith(`h:`)?void 0:n,handle:i??``})||e.add(n)}le(e)}function w(e,t,n,r){if(o.has(e))return;let i=Q(n);i?.setAttribute(`data-xss-key`,e);let a=i?ga(i):null,s=t.triggeringComment||t.recentTweets[0],c=setTimeout(()=>{try{E(e,t).catch(()=>{})}finally{o.delete(e),$(n)}},ba);o.set(e,{key:e,sig:t,anchor:n,timer:c,ts:Date.now(),...r?{mode:r}:{},...a?{tweetId:a}:{},...s?{tweetText:s}:{}}),D(n,t,r)}function T(e){let t=o.get(e);t&&(clearTimeout(t.timer),o.delete(e),Q(t.anchor)?.removeAttribute(`data-xss-key`),$(t.anchor))}function E(e,n){let i=o.get(e),s=i?.mode??h.actionMode,c=a.find(t=>(t.userId||`h:${t.handle}`)===e),l=i?.tweetId??c?.tweetId,u=i?.tweetText??c?.snippet;B(e),n.userId&&B(n.userId),mi({id:e,handle:n.handle,...n.displayName?{displayName:n.displayName}:{},...n.avatarUrl?{avatarUrl:n.avatarUrl}:{},...l?{tweetId:l}:{},...u?{tweetText:u}:{},source:`manual`,ts:Date.now()}),Ci({blocks:1}),Xr(`blocked`);let d=o.get(e)?.anchor??r.get(e)??null,f=Q(d),p=f&&We(f)?.toLowerCase()===n.handle.toLowerCase()||d&&!f?d:document.querySelector(`[data-xss-key="${CSS.escape(e)}"]`);return p&&ce(p,e),t?.markManual(e,la(s)),(s===`mute`||s===`block`)&&yi({id:e,handle:n.handle,action:s,ts:Date.now()}),da(s,n).then(t=>((s===`mute`||s===`block`)&&bi(e),t||hi(e,{reason:`手动${la(s)}（X 动作失败，仅本地隐藏）`}),t))}function D(e,t,n){$(e);let r=la(n??h.actionMode);_a(e,()=>{let e=document.createElement(`span`);return e.className=`xss-badge pending`,e.innerHTML=`<span style="color:var(--warn)">⏳ 5秒后${r}</span>
          <button data-undo style="margin-left:6px;padding:1px 6px;border:1px solid var(--warn);background:transparent;color:var(--warn);border-radius:4px;font-size:10px;cursor:pointer">撤销</button>`,e.querySelector(`[data-undo]`)?.addEventListener(`click`,e=>{e.stopPropagation(),T(_(t))}),e})}let ee=e=>new Promise(t=>setTimeout(t,e)),O=[],te=new Set,k=!1;function A(e,t,n){$(e),_a(e,()=>_t(t,n))}function j(e){let t=Q(e.anchor);return t&&We(t)?.toLowerCase()===e.sig.handle.toLowerCase()?e.anchor:document.querySelector(`[data-xss-key="${CSS.escape(e.key)}"]`)}function ne(e){if(te.has(e.key)||v(e.sig))return;te.add(e.key),B(e.key),e.sig.userId&&B(e.sig.userId);let n=e.sig.triggeringComment||e.sig.recentTweets[0];mi({id:e.key,handle:e.sig.handle,...e.sig.displayName?{displayName:e.sig.displayName}:{},...e.sig.avatarUrl?{avatarUrl:e.sig.avatarUrl}:{},...e.tweetId?{tweetId:e.tweetId}:{},...n?{tweetText:n}:{},verdict:e.verdict,reason:`${e.categoryZh} · 自动${e.verb}`,source:`auto`,ts:Date.now()}),(e.action===`mute`||e.action===`block`)&&yi({id:e.key,handle:e.sig.handle,action:e.action,ts:Date.now()}),Ci({blocks:1}),Xr(`blocked`),r.set(e.key,e.anchor),Q(e.anchor)?.setAttribute(`data-xss-key`,e.key),A(e.anchor,e.verb,!0),t?.markAuto(e.key,`queued`,e.verb),O.push(e),ie()}let re,M=0;function ie(){if(k)return;let e=Date.now();M||=e;let t=Math.min(1600,Math.max(0,M+4e3-e));clearTimeout(re),re=setTimeout(()=>void ae(),t)}async function ae(){if(!k){k=!0,M=0;try{await oe()}finally{k=!1}O.length&&ie()}}async function oe(){for(;O.length;){let e=O.shift();if(!e)break;try{let n=()=>h.enabled&&h.autoProcess&&!v(e.sig),r=async()=>{await xi(e.key),e.sig.userId&&e.sig.userId!==e.key&&await xi(e.sig.userId),Ci({blocks:-1}),bi(e.key),t?.markAuto(e.key,`failed`,e.verb);let n=j(e);n&&F(n,e.key,e.sig,null)};if(!n()){await r();continue}let i=Date.now(),a=j(e);a&&A(a,e.verb,!1),t?.markAuto(e.key,`processing`,e.verb);let o=e.action===`mute`||e.action===`block`?await da(e.action,e.sig,n):!0;if(!n()){await r();continue}o||console.warn(`[MXGA] 自动${e.verb}：X 原生动作失败`,e.sig.handle,e.sig.userId);let s=900-(Date.now()-i);if(s>0&&await ee(s),!n()){await r();continue}ce(j(e),e.key),(e.action===`mute`||e.action===`block`)&&(bi(e.key),o||hi(e.key,{reason:`${e.categoryZh} · 自动${e.verb}（X 动作失败，仅本地隐藏）`})),t?.markAuto(e.key,o?`done`:`failed`,e.verb)}catch(n){console.warn(`[MXGA] 自动${e.verb}处理异常`,e.sig.handle,n);try{t?.markAuto(e.key,`failed`,e.verb)}catch{}}finally{te.delete(e.key)}await ee(240)}}async function N(e){if(h.actionMode===`local`){for(let t of e)bi(t.id);return}for(let t of e.slice(0,sa)){if(t.action!==`mute`&&t.action!==`block`){bi(t.id);continue}let e={handle:t.handle,.../^\d+$/.test(t.id)?{userId:t.id}:{}},n=()=>h.enabled&&h.actionMode!==`local`&&!v(e);if(!n()){await bi(t.id);continue}await da(t.action,e,n).catch(()=>!1)||hi(t.id,{reason:`自动${t.action===`block`?`拉黑`:`静音`}（X 动作失败，仅本地隐藏）`}),bi(t.id)}}function P(e,r,i,o){if(v(e)||![`spam`,`porn_bot`,`likely_spam`].includes(r.label))return;let s=_(e),c=e.handle.toLowerCase();if(a.some(e=>(e.userId||`h:${e.handle}`)===s||e.handle.toLowerCase()===c))return;let l=e.triggeringComment||e.recentTweets[0]||e.bio;a.push({handle:e.handle,verdict:r,source:i,...o?.categoryZh?{categoryZh:o.categoryZh}:{},...o?.tweetId?{tweetId:o.tweetId}:{},...o?.tier?{tier:o.tier}:{},...e.userId?{userId:e.userId}:{},...e.avatarUrl?{avatarUrl:e.avatarUrl}:{},...e.displayName?{displayName:e.displayName}:{},...l?{snippet:l}:{}}),n||t?.update(a)}function F(e,t,n,i,a,s=`fresh`){i&&r.set(t,e),$(e);let c=Ir(n.userId,n.handle);_a(e,()=>Ct(c?null:i,{onAct:r=>w(t,n,e,r),onAppeal:()=>oa({handle:n.handle,...n.userId?{userId:n.userId}:{}}),onReport:e=>ca(n,e),whitelisted:c,onWhitelist:async()=>{if(c)await br(n.handle);else{let e=o.get(t);e&&(clearTimeout(e.timer),o.delete(t)),await yr({handle:n.handle,...n.userId?{userId:n.userId}:{},...n.displayName?{displayName:n.displayName}:{},...n.avatarUrl?{avatarUrl:n.avatarUrl}:{},source:`manual`});for(let e of[t,n.userId,`h:${n.handle}`])e&&xi(e)}$(e),V(n,e)}},a,s,h.actionMode))}function I(e){$(e),_a(e,yt)}async function fe(e,t,n,r){if(Vr(r.verdict)===`silent`){I(e);return}if(m&&Date.now()-r.ts>864e5&&p<10){p+=1;let r=await d.run(()=>v(n)?Promise.resolve({status:`failed`}):Kr(t,n));if(v(n)){F(e,t,n,null);return}if(r.status===`classified`){if(Vr(r.verdict)===`silent`){I(e);return}F(e,t,n,r.verdict,void 0,`cache`),P(n,r.verdict,`cache`);return}}F(e,t,n,r.verdict,void 0,`cache`),P(n,r.verdict,`cache`)}async function L(e,t,n){$(e),_a(e,vt);let r=await d.run(async()=>v(n)?{status:`failed`}:m?Kr(t,n):{status:`unauthenticated`});if(v(n)){F(e,t,n,null);return}if(r.status===`unauthenticated`&&(m=!1),r.status!==`classified`){F(e,t,n,null);return}if(r.cached||(Ci({detections:1,label:r.verdict.label}),Xr(`scanned`)),Vr(r.verdict)===`silent`){I(e);return}F(e,t,n,r.verdict,r.cached?`在线记录命中`:`在线 AI 检测完成`,`fresh`),P(n,r.verdict,`online-ai`)}function R(e,t,n,r,i=`list`,a=`feed`){u.has(t)||(u.add(t),Xr(`hitPublic`));let o=Q(e),s=o?ga(o):null,c=ue({source:i,tier:r.tier,inReply:a===`reply`,autoScope:h.autoScope,autoTierMode:h.autoTierMode})?de(h.categoryActions[r.category]??`badge`,{source:i,tier:r.tier,autoTierMode:h.autoTierMode,ruleHitsAutoAct:h.ruleHitsAutoAct}):`badge`;if(c===`badge`||!h.autoProcess){F(e,t,n,r.verdict,void 0,i),P(n,r.verdict,i===`rule`?`local-rule`:`local-index`,{categoryZh:ct[r.category],...s?{tweetId:s}:{},...i===`list`?{tier:r.tier}:{}});return}P(n,r.verdict,i===`rule`?`local-rule`:`local-index`,{categoryZh:ct[r.category],...s?{tweetId:s}:{},...i===`list`?{tier:r.tier}:{}}),ne({key:t,sig:n,action:c,verb:c===`mute`?`静音`:c===`block`?`拉黑`:`隐藏`,anchor:e,verdict:r.verdict,categoryZh:ct[r.category],...s?{tweetId:s}:{}})}async function V(e,t,n=`feed`){let r=_(e);if(!s.has(r)){s.add(r);try{if(await Rr(e,h.followingWhitelist),v(e)){T(r),F(t,r,e,null);return}let i=z(r)?r:e.userId&&z(e.userId)?e.userId:z(`h:${e.handle}`)?`h:${e.handle}`:null;if(i){if(te.has(r)&&Q(t)?.getAttribute(`data-xss-key`)===r)return;c.has(i)||(c.add(i),l(i,e)),ce(t,i);return}if(o.has(r))return;if(mr(e.userId,e.handle)){F(t,r,e,null);return}let a=hr(e.userId,e.handle);if(a){R(t,r,e,a,`list`,n);return}let s=await ve(r);if(v(e)){F(t,r,e,null);return}if(s){let n=[`spam`,`porn_bot`,`likely_spam`].includes(s.verdict.label);if(s.signalsHash===_e(e)||n&&(!m||Date.now()-s.ts<864e5)){await fe(t,r,e,s),Ci({cacheHits:1});return}}let u=Qn(e);if(u){if(u.origin===`official`&&h.ruleTelemetry)try{chrome.runtime.sendMessage({type:`rule-hit`,hit:{pattern:u.pattern,handle:e.handle,...e.userId?{xUserId:e.userId}:{},category:u.category,field:u.field,matchedText:u.matchedText}})}catch{}R(t,r,e,{userId:e.userId??``,handle:e.handle,verdict:{label:u.label,confidence:.95,reasons:[`命中${u.origin===`custom`?`自定义`:`官方`}规则 · ${ct[u.category]}`]},category:u.category,tier:`auto`,source:`community`,updatedAt:new Date().toISOString()},`rule`,n);return}if(Br({authenticated:m,localResult:`unknown`,requestsStarted:f})){f+=1;let n=Q(t);e.templateRepeats=await ai(e,Date.now(),n?ga(n):null),await L(t,r,e);return}F(t,r,e,null)}finally{s.delete(r)}}}let H;try{chrome.storage.local.get(`xss:viewer`).then(e=>{let t=e[`xss:viewer`]?.handle;t&&!H&&(H=t)})}catch{}function me(){let e=Pe();if(e&&e!==H){H=e;try{chrome.storage.local.set({"xss:viewer":{handle:e,ts:Date.now()}})}catch{}}}let U=``;function he(){if(!h.followingWhitelist)return;let e=location.pathname.match(/^\/([A-Za-z0-9_]{1,15})\/following\/?$/);if(!e)return;let t=Pe()??H,n=e[1]??``;if(!t||n.toLowerCase()!==t.toLowerCase()){let e=t?`page owner @${n} is not the viewer @${t}`:`viewer handle unknown`;U!==e&&(U=e,console.info(`[MXGA] following harvest skipped: ${e}`));return}let r=120,i=0,a=0;for(let e of document.querySelectorAll(`[data-testid="UserCell"]`)){if(r--<=0)break;i+=1;let t=e.querySelector(`[data-testid$="-unfollow"]`);if(!t)continue;let n=t.getAttribute(`data-testid`)?.match(/^(\d+)-unfollow$/)?.[1],o;for(let t of e.querySelectorAll(`a[href^="/"]`)){let e=(t.getAttribute(`href`)??``).split(`/`).filter(Boolean);if(e.length===1&&/^[A-Za-z0-9_]{1,15}$/.test(e[0]??``)){o=e[0];break}}if(!o||Ir(n,o)||Lr(o))continue;let s=e.querySelector(`img[src*="profile_images/"]`)?.src,c=e.querySelector(`a[href="/${o}"] span`)?.textContent?.trim();a+=1,yr({handle:o,...n?{userId:n}:{},...c?{displayName:c}:{},...s?{avatarUrl:s}:{},source:`following`}).catch(()=>{})}let o=`[MXGA] following harvest: ${i} cells, +${a} to local whitelist`;(a>0||U!==o)&&(U=o,console.info(o))}function ge(){for(let e of document.querySelectorAll(`article[data-testid="tweet"]`)){let t=ga(e),n=We(e);if(!t||!n)continue;let r=e.querySelector(`[data-testid="socialContext"]`);if(!r){let r=e.querySelector(`[data-testid="tweetText"]`)?.textContent?.trim().slice(0,400)??``;an({handle:n,statusId:t,original:!0,...r?{text:r}:{}});continue}if(!/转推|转发|retweet|リツイート|리트윗/i.test(r.textContent??``))continue;let i;for(let e of r.querySelectorAll(`a[href^="/"]`)){let t=(e.getAttribute(`href`)??``).split(`/`).filter(Boolean);if(t.length===1&&/^[A-Za-z0-9_]{1,15}$/.test(t[0]??``)){i=t[0];break}}i&&an({handle:i,statusId:`rt:${t}`,original:!1})}}function W(){me(),he(),h.kolCardEnabled&&ge();let e=Ge();if(e){let t=document.querySelector(`[data-testid="UserName"]`);if(t){let n=!!t.querySelector(`.xss-mount`);(i.get(t)!==e.handle||!n)&&(i.get(t)!==e.handle&&$(t),i.set(t,e.handle),V(e,t,`profile`))}}let t=it(),n=ha(),r=document.querySelectorAll(`article[data-testid="tweet"]`),a;if(n){for(let e of r)if(ga(e)===n){a=We(e);break}}let o=h.followingWhitelist&&pa();for(let e of r){let r=We(e),s=e.querySelector(`[data-testid="User-Name"]`);if(!r||!s)continue;let c=!!s.querySelector(`.xss-mount`);if(i.get(e)===r&&c)continue;let l=rt(e);if(!l)continue;t&&!l.threadTopic&&(l.threadTopic=t),o&&!l.viewerFollowing&&!l.isReply&&ma(e)&&(l.viewerFollowing=!0),i.get(e)!==r&&$(s),i.set(e,r);let u=n?ga(e):null,d=!!(n&&u&&u!==n),f=d?`reply`:`feed`;d?(l.isReply=!0,a&&(l.rootAuthorHandle=a)):a&&l.isReply&&!l.rootAuthorHandle&&(l.rootAuthorHandle=a),V(l,s,f)}}(await se(e,{name:`xss-bubble`,position:`overlay`,anchor:`body`,onMount(i){let s=document.createElement(`style`);s.textContent=lt,i.appendChild(s);let c=gt({onProcess(e,t){(async()=>{for(let n of e){let e=a.find(e=>(e.userId||`h:${e.handle}`)===n);if(!e){t(n,!1);continue}let r={isProfile:!1,handle:e.handle,displayName:e.displayName??``,bio:``,hasDefaultAvatar:!1,recentTweets:[],...e.userId?{userId:e.userId}:{},...e.avatarUrl?{avatarUrl:e.avatarUrl}:{}},i=o.get(n);i&&(clearTimeout(i.timer),o.delete(n)),t(n,await E(n,r).catch(()=>!1))}})()},onReviewEach(){let e=a[0];e&&r.get(e.userId||`h:${e.handle}`)?.scrollIntoView({behavior:`smooth`,block:`center`})},onDismiss(){n=!0},onAppeal(e){oa(e)},onToggleAuto(e){bn(`autoProcess`,e)}},h.bubblePos,la(h.actionMode),{autoProcess:h.autoProcess,autoCategoryCount:ua(h),autoScopeAll:h.autoScope===`all`,autoExpand:h.autoExpand});i.appendChild(c.el),h.bubble||(c.el.style.display=`none`),t=c;let l=()=>{if(h.bubblePos!==`tr`)return;let e=document.querySelector(`[data-testid="SearchBox_Search_Input"], form[role="search"], input[placeholder][data-testid*="Search"]`),t=e?.closest(`[data-testid="sidebarColumn"]`)?e:null,n=``;if(t){let e=t.getBoundingClientRect(),r=(c.el.querySelector(`.pill`)??c.el).getBoundingClientRect();e.width>0&&e.bottom>0&&e.top<70&&r.left<e.right+8&&r.right>e.left-8&&(n=`${Math.round(e.bottom+10)}px`)}c.el.style.setProperty(`--xss-bubble-top`,n)};return l(),e.addEventListener(window,`resize`,l),e.setInterval(l,4e3),vi().then(e=>{e.length&&N(e)}),c}})).mount(),e.addEventListener(window,`wxt:locationchange`,()=>{for(let[e,t]of o)clearTimeout(t.timer),E(e,t.sig);o.clear(),r.clear(),a=[],f=0,p=0,t?.pageReset()});let ye,be=new MutationObserver(()=>{clearTimeout(ye),ye=setTimeout(W,600)});be.observe(document.documentElement,{childList:!0,subtree:!0}),e.onInvalidated(()=>{be.disconnect(),clearTimeout(ye),rn()}),e.setInterval(W,4e3);let xe=J(),Ce=new MutationObserver(()=>{let e=J();e!==xe&&(xe=e,dt(e))});document.body&&Ce.observe(document.body,{attributes:!0,attributeFilter:[`style`,`class`]}),e.onInvalidated(()=>Ce.disconnect());try{chrome.storage.onChanged.addListener((e,n)=>{if(n!==`local`)return;let r=!1;if(e[`xss:ghToken`]&&g().then(e=>{if(!(!e||!m)){for(let e of document.querySelectorAll(`.xss-mount`))e.shadowRoot?.querySelector(`.xss-badge.ghost`)&&e.remove();W()}}),e[`xss:blocked`]&&(r=le(new Set(e[`xss:blocked`]?.newValue??[]))>0),e[`xss:list:v2`]||e[`xss:whitelist:v1`]||e[`xss:whitelist:local`]){C();for(let[e,t]of o)v(t.sig)&&T(e);a=a.filter(e=>!v(e)),t?.update(a);for(let e of document.querySelectorAll(`.xss-mount`))e.shadowRoot?.querySelector(`.xss-badge.pending`)||e.remove();r=!0}r&&W()})}catch{}W()}}),Sa=class e extends Event{static EVENT_NAME=Ca(`wxt:locationchange`);constructor(t,n){super(e.EVENT_NAME,{}),this.newUrl=t,this.oldUrl=n}};function Ca(e){return`${re?.runtime?.id}:content:${e}`}var wa=typeof globalThis.navigation?.addEventListener==`function`;function Ta(e){let t,n=!1;return{run(){n||(n=!0,t=new URL(location.href),wa?globalThis.navigation.addEventListener(`navigate`,e=>{let n=new URL(e.destination.url);n.href!==t.href&&(window.dispatchEvent(new Sa(n,t)),t=n)},{signal:e.signal}):e.setInterval(()=>{let e=new URL(location.href);e.href!==t.href&&(window.dispatchEvent(new Sa(e,t)),t=e)},1e3))}}}var Ea=class e{static SCRIPT_STARTED_MESSAGE_TYPE=Ca(`wxt:content-script-started`);id;abortController;locationWatcher=Ta(this);constructor(e,t){this.contentScriptName=e,this.options=t,this.id=Math.random().toString(36).slice(2),this.abortController=new AbortController,this.stopOldScripts(),this.listenForNewerScripts()}get signal(){return this.abortController.signal}abort(e){return this.abortController.abort(e)}get isInvalid(){return re.runtime?.id??this.notifyInvalidated(),this.signal.aborted}get isValid(){return!this.isInvalid}onInvalidated(e){return this.signal.addEventListener(`abort`,e),()=>this.signal.removeEventListener(`abort`,e)}block(){return new Promise(()=>{})}setInterval(e,t){let n=setInterval(()=>{this.isValid&&e()},t);return this.onInvalidated(()=>clearInterval(n)),n}setTimeout(e,t){let n=setTimeout(()=>{this.isValid&&e()},t);return this.onInvalidated(()=>clearTimeout(n)),n}requestAnimationFrame(e){let t=requestAnimationFrame((...t)=>{this.isValid&&e(...t)});return this.onInvalidated(()=>cancelAnimationFrame(t)),t}requestIdleCallback(e,t){let n=requestIdleCallback((...t)=>{this.signal.aborted||e(...t)},t);return this.onInvalidated(()=>cancelIdleCallback(n)),n}addEventListener(e,t,n,r){t===`wxt:locationchange`&&this.isValid&&this.locationWatcher.run(),e.addEventListener?.(t.startsWith(`wxt:`)?Ca(t):t,n,{...r,signal:this.signal})}notifyInvalidated(){this.abort(`Content script context invalidated`),f.debug(`Content script "${this.contentScriptName}" context invalidated`)}stopOldScripts(){document.dispatchEvent(new CustomEvent(e.SCRIPT_STARTED_MESSAGE_TYPE,{detail:{contentScriptName:this.contentScriptName,messageId:this.id}})),this.options?.noScriptStartedPostMessage||window.postMessage({type:e.SCRIPT_STARTED_MESSAGE_TYPE,contentScriptName:this.contentScriptName,messageId:this.id},`*`)}verifyScriptStartedEvent(e){let t=e.detail?.contentScriptName===this.contentScriptName,n=e.detail?.messageId===this.id;return t&&!n}listenForNewerScripts(){let t=e=>{!(e instanceof CustomEvent)||!this.verifyScriptStartedEvent(e)||this.notifyInvalidated()};document.addEventListener(e.SCRIPT_STARTED_MESSAGE_TYPE,t),this.onInvalidated(()=>document.removeEventListener(e.SCRIPT_STARTED_MESSAGE_TYPE,t))}},Da={debug:(...e)=>([...e],void 0),log:(...e)=>([...e],void 0),warn:(...e)=>([...e],void 0),error:(...e)=>([...e],void 0)};return(async()=>{try{let{main:e,...t}=xa;return await e(new Ea(`content`,t))}catch(e){throw Da.error(`The content script "content" crashed on startup!`,e),e}})()})();
content;