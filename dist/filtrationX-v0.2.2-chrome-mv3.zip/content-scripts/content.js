var content=(function(){var e=Object.create,t=Object.defineProperty,n=Object.getOwnPropertyDescriptor,r=Object.getOwnPropertyNames,i=Object.getPrototypeOf,a=Object.prototype.hasOwnProperty,o=(e,t)=>()=>(e&&(t=e(e=0)),t),s=(e,t)=>()=>(t||(e((t={exports:{}}).exports,t),e=null),t.exports),c=(e,n)=>{let r={};for(var i in e)t(r,i,{get:e[i],enumerable:!0});return n||t(r,Symbol.toStringTag,{value:`Module`}),r},l=(e,i,o,s)=>{if(i&&typeof i==`object`||typeof i==`function`)for(var c=r(i),l=0,u=c.length,d;l<u;l++)d=c[l],!a.call(e,d)&&d!==o&&t(e,d,{get:(e=>i[e]).bind(null,d),enumerable:!(s=n(i,d))||s.enumerable});return e},u=(n,r,a)=>(a=n==null?{}:e(i(n)),l(r||!n||!n.__esModule?t(a,`default`,{value:n,enumerable:!0}):a,n));function d(e){return e}var f={debug:(...e)=>([...e],void 0),log:(...e)=>([...e],void 0),warn:(...e)=>([...e],void 0),error:(...e)=>([...e],void 0)},p=Symbol(`null`),m=0,h=class extends Map{constructor(...e){super(),this._objectHashes=new WeakMap,this._symbolHashes=new Map,this._publicKeys=new Map;let[t]=e;if(t!=null){if(typeof t[Symbol.iterator]!=`function`)throw TypeError(typeof t+` is not iterable (cannot read property Symbol(Symbol.iterator))`);for(let[e,n]of t)this.set(e,n)}}_getPublicKeys(e,t=!1){if(!Array.isArray(e))throw TypeError(`The keys parameter must be an array`);let n=this._getPrivateKey(e,t),r;return n&&this._publicKeys.has(n)?r=this._publicKeys.get(n):t&&(r=[...e],this._publicKeys.set(n,r)),{privateKey:n,publicKey:r}}_getPrivateKey(e,t=!1){let n=[];for(let r of e){let e=r===null?p:r,i;if(i=typeof e==`object`||typeof e==`function`?`_objectHashes`:typeof e==`symbol`?`_symbolHashes`:!1,!i)n.push(e);else if(this[i].has(e))n.push(this[i].get(e));else if(t){let t=`@@mkm-ref-${m++}@@`;this[i].set(e,t),n.push(t)}else return!1}return JSON.stringify(n)}set(e,t){let{publicKey:n}=this._getPublicKeys(e,!0);return super.set(n,t)}get(e){let{publicKey:t}=this._getPublicKeys(e);return super.get(t)}has(e){let{publicKey:t}=this._getPublicKeys(e);return super.has(t)}delete(e){let{publicKey:t,privateKey:n}=this._getPublicKeys(e);return!!(t&&super.delete(t)&&this._publicKeys.delete(n))}clear(){super.clear(),this._symbolHashes.clear(),this._publicKeys.clear()}get[Symbol.toStringTag](){return`ManyKeysMap`}get size(){return super.size}};function g(e){if(typeof e!=`object`||!e)return!1;let t=Object.getPrototypeOf(e);return t!==null&&t!==Object.prototype&&Object.getPrototypeOf(t)!==null||Symbol.iterator in e?!1:Symbol.toStringTag in e?Object.prototype.toString.call(e)===`[object Module]`:!0}function _(e,t,n=`.`,r){if(!g(t))return _(e,{},n,r);let i={...t};for(let t of Object.keys(e)){if(t===`__proto__`||t===`constructor`)continue;let a=e[t];a!=null&&(r&&r(i,t,a,n)||(Array.isArray(a)&&Array.isArray(i[t])?i[t]=[...a,...i[t]]:g(a)&&g(i[t])?i[t]=_(a,i[t],(n?`${n}.`:``)+t.toString(),r):i[t]=a))}return i}function v(e){return(...t)=>t.reduce((t,n)=>_(t,n,``,e),{})}var y=v(),b=e=>e===null?{isDetected:!1}:{isDetected:!0,result:e},x=e=>e===null?{isDetected:!0,result:null}:{isDetected:!1},S=()=>({target:globalThis.document,unifyProcess:!0,detector:b,observeConfigs:{childList:!0,subtree:!0,attributes:!0},signal:void 0,customMatcher:void 0}),C=(e,t)=>y(e,t),w=new h;function ee(e){let{defaultOptions:t}=e;return(e,n)=>{let{target:r,unifyProcess:i,observeConfigs:a,detector:o,signal:s,customMatcher:c}=C(n,t),l=[e,r,i,a,o,s,c],u=w.get(l);if(i&&u)return u;let d=new Promise(async(t,n)=>{if(s?.aborted)return n(s.reason);let i=new MutationObserver(async n=>{for(let a of n){if(s?.aborted){i.disconnect();break}let n=await T({selector:e,target:r,detector:o,customMatcher:c});if(n.isDetected){i.disconnect(),t(n.result);break}}});s?.addEventListener(`abort`,()=>(i.disconnect(),n(s.reason)),{once:!0});let l=await T({selector:e,target:r,detector:o,customMatcher:c});if(l.isDetected)return t(l.result);i.observe(r,a)}).finally(()=>{w.delete(l)});return w.set(l,d),d}}async function T({target:e,selector:t,detector:n,customMatcher:r}){return await n(r?r(t):e.querySelector(t))}var E=ee({defaultOptions:S()});function te(e,t,n){n.position!==`inline`&&(n.zIndex!=null&&(e.style.zIndex=String(n.zIndex)),e.style.overflow=`visible`,e.style.position=`relative`,e.style.width=`0`,e.style.height=`0`,e.style.display=`block`,t&&(n.position===`overlay`?(t.style.position=`absolute`,n.alignment?.startsWith(`bottom-`)?t.style.bottom=`0`:t.style.top=`0`,n.alignment?.endsWith(`-right`)?t.style.right=`0`:t.style.left=`0`):(t.style.position=`fixed`,t.style.top=`0`,t.style.bottom=`0`,t.style.left=`0`,t.style.right=`0`)))}function D(e){if(e.anchor==null)return document.body;let t=typeof e.anchor==`function`?e.anchor():e.anchor;return typeof t==`string`?t.startsWith(`/`)?document.evaluate(t,document,null,XPathResult.FIRST_ORDERED_NODE_TYPE,null).singleNodeValue??void 0:document.querySelector(t)??void 0:t??void 0}function ne(e,t){let n=D(t);if(n==null)throw Error(`Failed to mount content script UI: could not find anchor element`);switch(t.append){case void 0:case`last`:n.append(e);break;case`first`:n.prepend(e);break;case`replace`:n.replaceWith(e);break;case`after`:n.parentElement?.insertBefore(e,n.nextElementSibling);break;case`before`:n.parentElement?.insertBefore(e,n);break;default:t.append(n,e)}}function O(e,t){let n,r=()=>{n?.stopAutoMount(),n=void 0},i=()=>{e.mount()},a=e.remove;return{mount:i,remove:()=>{r(),e.remove()},autoMount:e=>{n&&f.warn(`autoMount is already set.`),n=k({mount:i,unmount:a,stopAutoMount:r},{...t,...e})}}}function k(e,t){let n=new AbortController,r=`explicit_stop_auto_mount`,i=()=>{n.abort(r),t.onStop?.()},a=typeof t.anchor==`function`?t.anchor():t.anchor;if(a instanceof Element)throw Error("autoMount and Element anchor option cannot be combined. Avoid passing `Element` directly or `() => Element` to the anchor.");async function o(i){let a=!!D(t);for(a&&e.mount();!n.signal.aborted;)try{a=!!await E(i??`body`,{customMatcher:()=>D(t)??null,detector:a?x:b,signal:n.signal}),a?e.mount():(e.unmount(),t.once&&e.stopAutoMount())}catch(e){if(n.signal.aborted&&n.signal.reason===r)break;throw e}}return o(a),{stopAutoMount:i}}var re=/(\s*@(property|font-face)[\s\S]*?{[\s\S]*?})/gm;function A(e){return{documentCss:Array.from(e.matchAll(re),e=>e[0]).join(``).trim(),shadowCss:e.replace(re,``).trim()}}var ie=globalThis.browser?.runtime?.id?globalThis.browser:globalThis.chrome,j=u(s(((e,t)=>{var n=/^[a-z](?:[\.0-9_a-z\xB7\xC0-\xD6\xD8-\xF6\xF8-\u037D\u037F-\u1FFF\u200C\u200D\u203F\u2040\u2070-\u218F\u2C00-\u2FEF\u3001-\uD7FF\uF900-\uFDCF\uFDF0-\uFFFD]|[\uD800-\uDB7F][\uDC00-\uDFFF])*-(?:[\x2D\.0-9_a-z\xB7\xC0-\xD6\xD8-\xF6\xF8-\u037D\u037F-\u1FFF\u200C\u200D\u203F\u2040\u2070-\u218F\u2C00-\u2FEF\u3001-\uD7FF\uF900-\uFDCF\uFDF0-\uFFFD]|[\uD800-\uDB7F][\uDC00-\uDFFF])*$/;t.exports=function(e){return n.test(e)}}))(),1),ae=(e,t,n)=>new Promise((r,i)=>{var a=e=>{try{s(n.next(e))}catch(e){i(e)}},o=e=>{try{s(n.throw(e))}catch(e){i(e)}},s=e=>e.done?r(e.value):Promise.resolve(e.value).then(a,o);s((n=n.apply(e,t)).next())}),M=[`article`,`aside`,`blockquote`,`body`,`div`,`footer`,`h1`,`h2`,`h3`,`h4`,`h5`,`h6`,`header`,`main`,`nav`,`p`,`section`,`span`];function oe(e){return ae(this,null,function*(){let{name:t,mode:n=`closed`,css:r,isolateEvents:i=!1}=e;if(!M.includes(t)&&!(0,j.default)(t))throw Error(`"${t}" cannot have a shadow root attached to it. It must be two words and kebab-case, with a few exceptions. See https://developer.mozilla.org/en-US/docs/Web/API/Element/attachShadow#elements_you_can_attach_a_shadow_to`);let a=document.createElement(t),o=a.attachShadow({mode:n}),s=document.createElement(`html`),c=document.createElement(`body`),l=document.createElement(`head`);if(r){let e=document.createElement(`style`);`url`in r?e.textContent=yield fetch(r.url).then(e=>e.text()):e.textContent=r.textContent,l.appendChild(e)}return s.appendChild(l),s.appendChild(c),o.appendChild(s),i&&(Array.isArray(i)?i:[`keydown`,`keyup`,`keypress`]).forEach(e=>{c.addEventListener(e,e=>e.stopPropagation())}),{parentElement:a,shadow:o,isolatedElement:c}})}async function se(e,t){let n=Math.random().toString(36).substring(2,15),r=[];if(t.inheritStyles||r.push(`/* WXT Shadow Root Reset */ :host{all:initial !important;}`),t.css&&r.push(t.css),e.options?.cssInjectionMode===`ui`){let e=await N();r.push(e.replaceAll(`:root`,`:host`))}let{shadowCss:i,documentCss:a}=A(r.join(`
`).trim()),{isolatedElement:o,parentElement:s,shadow:c}=await oe({name:t.name,css:{textContent:i},mode:t.mode??`open`,isolateEvents:t.isolateEvents}),l,u=()=>{if(ne(s,t),te(s,c.querySelector(`html`),t),a&&!document.querySelector(`style[wxt-shadow-root-document-styles="${n}"]`)){let e=document.createElement(`style`);e.textContent=a,e.setAttribute(`wxt-shadow-root-document-styles`,n),(document.head??document.body).append(e)}l=t.onMount(o,c,s)},d=()=>{for(t.onRemove?.(l),s.remove(),document.querySelector(`style[wxt-shadow-root-document-styles="${n}"]`)?.remove();o.lastChild;)o.removeChild(o.lastChild);l=void 0},f=O({mount:u,remove:d},t);return e.onInvalidated(d),{shadow:c,shadowHost:s,uiContainer:o,...f,get mounted(){return l}}}async function N(){let e=ie.runtime.getURL(`/content-scripts/content.css`);try{return await(await fetch(e)).text()}catch(t){return f.warn(`Failed to load styles @ ${e}. Did you forget to import the stylesheet in your entrypoint?`,t),``}}function ce(e){let t=e?.closest(`[data-testid="UserName"]`);if(!t)return null;let n=t.closest(`[data-testid="primaryColumn"]`);for(let e=t.parentElement;e&&e!==n;e=e.parentElement)if(e.querySelector(`a[href$="/header_photo"]`))return e;return null}var P=`data-xss-hidden-key`,F=`data-xss-previous-display`;function le(e,t){let n=e?.closest(`[data-testid="cellInnerDiv"]`)??e?.closest(`article`)??ce(e);return n?(t&&!n.hasAttribute(P)&&(n.setAttribute(P,t),n.setAttribute(F,n.style.display)),n.style.display=`none`,!0):!1}function ue(e,t=document){let n=0;for(let r of t.querySelectorAll(`[${P}]`)){let t=r.getAttribute(P);!t||e.has(t)||(r.style.display=r.getAttribute(F)??``,r.removeAttribute(P),r.removeAttribute(F),n++)}return n}function de(e){return e.source===`list`?e.tier!==`confirmed`&&e.autoTierMode===`badge`?!1:e.autoScope===`all`||e.inReply:e.source===`rule`?e.autoTierMode===`badge`?!1:e.inReply:!1}function fe(e,t){return t.source===`list`&&t.tier===`confirmed`?e:t.source===`rule`?t.ruleHitsAutoAct&&t.autoTierMode===`full`?e:e===`badge`?`badge`:`hide`:t.autoTierMode===`full`?e:e===`badge`?`badge`:`hide`}var I=`xss:blocked`,L=null;try{chrome.storage.onChanged.addListener((e,t)=>{t===`local`&&e[`xss:blocked`]&&(L=new Set(e[`xss:blocked`]?.newValue??[]))})}catch{}async function R(){if(L)return L;try{let e=await chrome.storage.local.get(I);L=new Set(e[`xss:blocked`]??[])}catch{L=new Set}return L}function z(e){return L?L.has(e):!1}async function pe(){await R()}async function me(e){let t=await R();if(!t.has(e)){t.add(e);try{await chrome.storage.local.set({[I]:[...t]})}catch{}}}async function B(e){let t=await R();if(t.delete(e))try{await chrome.storage.local.set({[I]:[...t]})}catch{}}var he={name:`Make X Great Again 二开版`,acronym:`filtrationX`,tagline:`AI 帮你拦 X 上的垃圾`,repo:`https://github.com/xiaoyi36c/filtrationX`,release:`https://github.com/xiaoyi36c/filtrationX/releases/latest`,upstreamRepo:`https://github.com/foru17/make-x-great-again`,chromeWebStore:`https://chromewebstore.google.com/detail/make-x-great-again/aeoldnecphbkkckeedfgfcdcekkljdea`,firefoxAddons:`https://addons.mozilla.org/firefox/addon/make-x-great-again/`,testFlight:`https://testflight.apple.com/join/SeH4raps`,edgeBase:`https://x.zuoluo.tv`,governance:`https://github.com/foru17/make-x-great-again/blob/main/GOVERNANCE.md`,privacy:`https://github.com/foru17/make-x-great-again/blob/main/docs/PRIVACY.md`,appealNewIssue:`https://github.com/foru17/make-x-great-again/issues/new?template=appeal.yml`,issues:`https://github.com/foru17/make-x-great-again/issues`,owner:`xiaoyi36c`,license:`AGPL-3.0`},V=`xss:v1:`,ge=864e5;function _e(e){return e===`spam`||e===`porn_bot`||e===`likely_spam`?7*ge:e===`legit`?14*ge:3*ge}function H(e){return typeof e!=`number`||!Number.isFinite(e)||e<0?null:e<2?e:Math.round(Math.log2(e)*2)}function ve(e){let t=JSON.stringify([e.handle,e.displayName,e.bio,e.recentTweets,e.triggeringComment??``,e.hasDefaultAvatar,e.avatarSource??null,e.isVerified??!1,e.location??``,H(e.accountAgeDays===void 0?void 0:Math.floor(e.accountAgeDays/30)),H(e.followersCount),H(e.followingCount),H(e.statusesCount),H(e.mediaCount),H(e.favouritesCount)]),n=5381;for(let e=0;e<t.length;e++)n=(n*33^t.charCodeAt(e))>>>0;return n.toString(36)}var ye=e=>V+e;async function be(e){try{let t=ye(e),n=(await chrome.storage.local.get(t))[t];return n?Date.now()-n.ts>_e(n.verdict.label)?(chrome.storage.local.remove(t),null):n:null}catch{return null}}async function U(e,t){try{await chrome.storage.local.set({[ye(e)]:t})}catch{}}var xe=`data-mxga-u`;function Se(e){return e?.trim().replace(/^@+/,``).toLowerCase()??``}function Ce(e,t){if(!e)return{};let n=Se(t);if(!n||Se(e.getAttribute(`data-mxga-uh`)??void 0)!==n)return{};let r=e.getAttribute(xe);if(!r)return{};try{let e=JSON.parse(r);return!e||typeof e!=`object`||Array.isArray(e)?{}:e}catch{return{}}}var we=new Set([`home`,`explore`,`notifications`,`messages`,`i`,`search`,`settings`,`compose`,`hashtag`,`bookmarks`,`lists`,`communities`,`jobs`,`tos`,`privacy`,`login`,`signup`]),Te=1288834974657n,Ee=2*864e5;function De(e){if(!e)return;let t=Date.now(),n,r=e.match(/(\d{4})年(\d{1,2})月/);if(r&&(n=new Date(Number(r[1]),Number(r[2])-1,1)),!n){let t=e.match(/Joined\s+([A-Za-z]+)\s+(\d{4})/i);t&&(n=new Date(`${t[1]} 1, ${t[2]}`))}if(!(!n||Number.isNaN(n.getTime())))return Math.max(0,Math.round((t-n.getTime())/864e5))}function Oe(e){if(!e)return;let t=e.replace(/[, ]/g,``).match(/([\d.]+)\s*([万KkMm千]?)/);if(!(!t||t[1]===void 0))return Math.round(Number.parseFloat(t[1])*({万:1e4,千:1e3,K:1e3,k:1e3,M:1e6,m:1e6}[t[2]??``]??1))}function ke(e){let t=e.querySelector(`img[src*="profile_images/"]`);return{hasDefaultAvatar:!t,avatarUrl:t?.src}}function W(e){return e?.trim().replace(/^@+/,``).toLowerCase()||void 0}function Ae(e){return typeof e==`string`&&/^\d+$/.test(e)?e:void 0}function je(e){return typeof e==`number`&&Number.isSafeInteger(e)?String(e):Ae(e)}function G(e){return e===!0?!0:void 0}function Me(e){let t=e.querySelector(`[src*="profile_banners/"], [style*="profile_banners/"]`);return Ae((t instanceof HTMLImageElement?t.src:t?.getAttribute(`style`)??``).match(/profile_banners\/(\d+)\//)?.[1])}function Ne(e){if(!(e.length<16))try{return Number((BigInt(e)>>22n)+Te)}catch{return}}function Pe(e){for(let t of document.querySelectorAll(`script[type="application/ld+json"]`))try{let n=JSON.parse(t.textContent??``),r=Array.isArray(n)?n:[n];for(let t of r){if(!t||typeof t!=`object`)continue;let n=t;if(n[`@type`]!==`ProfilePage`)continue;let r=n.mainEntity;if(!r||typeof r!=`object`)continue;let i=r;if(i[`@type`]!==`Person`)continue;let a=W(typeof i.additionalName==`string`?i.additionalName:void 0)??W(typeof i.url==`string`?i.url.match(/\/([^/?#]+)(?:[?#].*)?$/)?.[1]:void 0);if(e&&a!==e)continue;let o=je(i.identifier);if(o)return o}}catch{}}function Fe(){let e=document.querySelector(`[data-testid="AppTabBar_Profile_Link"]`)?.getAttribute(`href`),t=W(e?.match(/^\/([^/?#]+)/)?.[1]);return t&&!we.has(t)?t:W((document.querySelector(`[data-testid="SideNav_AccountSwitcher_Button"]`)?.innerText??``).match(/@([A-Za-z0-9_]{1,15})/)?.[1])}function Ie(e){let t=Fe(),n=W(e);return t&&n&&t===n?!0:void 0}function Le(e){return e.replace(/[.*+?^${}()|[\]\\]/g,`\\$&`)}function Re(e,t){let n=W(t),r=n?RegExp(`@${Le(n)}\\b`,`i`):void 0;for(let t of e.querySelectorAll(`[data-testid$="-follow"], [data-testid$="-unfollow"], [data-testid$="-subscribe"]`)){let e=(t.getAttribute(`data-testid`)??``).match(/^(\d+)-(follow|unfollow|subscribe)$/);if(!e)continue;let n=`${t.getAttribute(`aria-label`)??``}\n${t.innerText??``}`;if(!(r&&!r.test(n)))return{userId:e[1],...e[2]===`unfollow`?{viewerFollowing:!0}:{}}}if(r)for(let t of e.querySelectorAll(`button, [role="button"]`)){let e=`${t.getAttribute(`aria-label`)??``}\n${t.innerText??``}`;if(r.test(e)&&/(取消关注|正在关注|Following|Unfollow)/i.test(e))return{viewerFollowing:!0}}return{}}var ze=new WeakMap;function Be(e,t){let n=W(t)??``,r=ze.get(e)?.get(n);if(r)return r;let i=Ve(e,n||void 0);if(Object.keys(i).length){let t=ze.get(e)??new Map;t.set(n,i),ze.set(e,t)}return i}function Ve(e,t){try{let n=Object.keys(e).find(e=>e.startsWith(`__reactFiber$`));if(!n)return{};let r=e[n],i=new Set,a={n:4e3};for(let e=0;r&&e<24;e++){for(let e of[r.memoizedProps,r.memoizedState]){let n=Ue(e,i,0,a,t);if(n){let e=n.legacy??n,t=n.core??{},r=n.relationship_perspectives??{},i=e.created_at??t.created_at,a=i?Date.parse(i):NaN,o=He(n,e),s=Number.isNaN(a)?void 0:Math.max(0,Math.round((Date.now()-a)/864e5)),c=Number.isNaN(a)?void 0:new Date(a).toISOString(),l=e=>typeof e==`number`&&Number.isFinite(e)?e:void 0,u=l(e.statuses_count),d=l(e.media_count),f=l(e.favourites_count),p=G(n.is_blue_verified)||G(e.verified)||G(e.is_blue_verified)||G(n.verification?.verified)?!0:void 0,m=typeof e.location==`string`?e.location:n.location?.location,h=typeof m==`string`&&m.trim()?m.trim().slice(0,100):void 0,g=typeof e.profile_image_url_https==`string`?e.profile_image_url_https:typeof n.avatar?.image_url==`string`?n.avatar.image_url:void 0,_=typeof e.default_profile_image==`boolean`?e.default_profile_image:g?/default_profile/.test(g):void 0,v=G(e.following)||G(r.following),y=G(e.blocking)||G(r.blocking),b=G(e.muting)||G(r.muting),x=G(e.follow_request_sent)||G(r.follow_request_sent);return{bio:typeof e.description==`string`?e.description:``,...o?{userId:o}:{},followersCount:e.followers_count,followingCount:e.friends_count,...c?{accountCreatedAt:c}:{},...s===void 0?{}:{accountAgeDays:s},...p?{isVerified:p}:{},...u===void 0?{}:{statusesCount:u},...d===void 0?{}:{mediaCount:d},...f===void 0?{}:{favouritesCount:f},...h?{location:h}:{},..._===void 0?{}:{profileDefaultImage:_},...v?{viewerFollowing:!0}:{},...y?{viewerBlocking:!0}:{},...b?{viewerMuting:!0}:{},...x?{viewerFollowRequestSent:!0}:{}}}}r=r.return}}catch{}return{}}function He(e,t){let n=Ae(t?.id_str),r=Ae(e?.rest_id);if(n&&r&&n!==r){console.warn(`[MXGA] conflicting X user ids in fiber; dropping uid`,{legacyId:n,restId:r,screenName:t?.screen_name??e?.core?.screen_name});return}let i=n??r,a=Ae(String(t?.profile_image_url_https??``).match(/profile_images\/(\d+)\//)?.[1]),o=i?Ne(i):void 0,s=typeof t?.created_at==`string`?Date.parse(t.created_at):NaN;if(i&&a===i&&o!==void 0&&!Number.isNaN(s)&&Math.abs(o-s)>Ee){console.warn(`[MXGA] fiber uid looks like avatar media id; dropping uid`,{candidate:i,screenName:t?.screen_name,createdAt:t.created_at,avatarUrl:t.profile_image_url_https});return}return i}function Ue(e,t,n,r,i){if(!e||typeof e!=`object`||n>5||t.has(e)||--r.n<=0||e instanceof Node||e instanceof Window)return null;t.add(e);try{let a=e.legacy??e,o=e.core??{},s=a?.screen_name??o.screen_name;if(a&&typeof a==`object`&&typeof s==`string`&&(typeof a.followers_count==`number`||typeof a.id_str==`string`||typeof e.rest_id==`string`||e.__typename===`User`)){let t=W(s);if(!i||t===i)return e}for(let a of Object.keys(e)){let o=Ue(e[a],t,n+1,r,i);if(o)return o}}catch{}return null}function We(){let e=location.pathname.split(`/`).filter(Boolean);if(e.length!==1)return;let t=e[0]??``;return we.has(t)||!/^[A-Za-z0-9_]{1,15}$/.test(t)?void 0:t}function Ge(e){let t=e.querySelector(`[data-testid="User-Name"]`);if(t)for(let e of t.querySelectorAll(`a[href^="/"]`)){let t=(e.getAttribute(`href`)??``).split(`/`).filter(Boolean);if(t.length===1&&/^[A-Za-z0-9_]{1,15}$/.test(t[0]??``))return t[0]}}function Ke(){let e=location.pathname.split(`/`).filter(Boolean);if(e.length!==1||we.has(e[0]??``))return null;let t=document.querySelector(`[data-testid="UserName"]`);if(!t)return null;let n=t.innerText.split(`
`).map(e=>e.trim()).filter(Boolean),r=(n.find(e=>e.startsWith(`@`))??`@${e[0]}`).slice(1),i=n[0]&&!n[0].startsWith(`@`)?n[0]:``,a=document.querySelector(`[data-testid="UserDescription"]`),o=document.querySelector(`[data-testid="UserJoinDate"]`),s,c;for(let e of document.querySelectorAll(`a[href*="/follow"], a[href$="/verified_followers"]`)){let t=e.getAttribute(`href`)??``,n=Oe(e.innerText);/\/following$/.test(t)?c=n:/(verified_)?followers$/.test(t)&&(s=n)}let l=document.querySelector(`[data-testid="primaryColumn"]`)??document,{hasDefaultAvatar:u,avatarUrl:d}=ke(l),f=l instanceof Element?l:t,p=Re(f,r),m={...Be(f,r),...Ce(f,r),...p.userId?{userId:p.userId}:{},...p.viewerFollowing?{viewerFollowing:!0}:{},...Ie(r)||f.querySelector(`[data-testid="editProfileButton"]`)?{viewerIsSelf:!0}:{}},h=Pe(r);h&&m.userId&&h!==m.userId&&console.warn(`[MXGA] profile JSON-LD user id differs from observed user id; using JSON-LD`,{handle:r,jsonLdUserId:h,observedUserId:m.userId});let g=h??m.userId??Me(l);return{isProfile:!0,surface:`profile`,handle:r,displayName:i,bio:a?a.innerText.trim():``,...Ye(u,m),recentTweets:Je(f,r),...d?{avatarUrl:d}:{},...g?{userId:g}:{},...Xe(m),...m.viewerFollowing?{viewerFollowing:!0}:{},...m.viewerBlocking?{viewerBlocking:!0}:{},...m.viewerMuting?{viewerMuting:!0}:{},...m.viewerFollowRequestSent?{viewerFollowRequestSent:!0}:{},...m.viewerIsSelf?{viewerIsSelf:!0}:{},...m.accountCreatedAt?{accountCreatedAt:m.accountCreatedAt}:{},...De(o?.innerText)===void 0?{}:{accountAgeDays:De(o?.innerText)},...s===void 0?{}:{followersCount:s},...c===void 0?{}:{followingCount:c}}}var qe=10;function Je(e,t){let n=t.toLowerCase(),r=[],i=new Set;for(let t of e.querySelectorAll(`article[data-testid="tweet"]`)){if(r.length>=qe)break;if(Ge(t)?.toLowerCase()!==n||Qe(t))continue;let e=t.querySelector(`[data-testid="tweetText"]`)?.innerText.trim();if(!e)continue;let a=e.slice(0,500);i.has(a)||(i.add(a),r.push(a))}return r}function Ye(e,t){return t.profileDefaultImage===void 0?{hasDefaultAvatar:e,avatarSource:`dom`}:{hasDefaultAvatar:t.profileDefaultImage,avatarSource:`profile`}}function Xe(e){return{...e.isVerified?{isVerified:!0}:{},...e.statusesCount===void 0?{}:{statusesCount:e.statusesCount},...e.mediaCount===void 0?{}:{mediaCount:e.mediaCount},...e.favouritesCount===void 0?{}:{favouritesCount:e.favouritesCount},...e.location?{location:e.location}:{}}}var Ze=/^(广告|推广|Promoted|Ad|プロモーション|광고)$/;function Qe(e){if(e.querySelector(`[data-testid="placementTracking"]`))return!0;let t=e.querySelector(`[data-testid="tweetText"]`);for(let n of e.querySelectorAll(`span,div`))if(!t?.contains(n)&&Ze.test(n.textContent?.trim()??``))return!0;return!1}var $e=/translated from|show original|翻译自|显示原文|翻譯自|顯示原文|由\s*\S{1,12}\s*(?:翻译|翻譯)|原文を表示|から翻訳|번역함|원본 보기/i;function et(e,t){return t?$e.test(e.textContent??``):!1}function tt(){let e=location.pathname;return e===`/home`||e===`/`||e.startsWith(`/i/lists/`)||e===`/explore`?`home`:/^\/[^/]+\/status\/\d+/.test(e)?`thread`:e.startsWith(`/search`)?`search`:e.startsWith(`/notifications`)?`notifications`:/^\/[A-Za-z0-9_]{1,15}(\/(with_replies|media|likes|highlights|articles))?\/?$/.test(e)?`profile`:`other`}var nt=/^(replying to|回复|回覆|返信先|답글|antwort an|en réponse à|respondiendo a|em resposta a|in risposta a|antwoord aan)\b/i;function rt(e,t){for(let n of e.querySelectorAll(`div, span`)){if(t?.contains(n))continue;let e=(n.textContent??``).trim();if(!(!e||e.length>200||!nt.test(e)))for(let e of n.querySelectorAll(`a[href^="/"]`)){let t=(e.getAttribute(`href`)??``).split(`/`).filter(Boolean);if(t.length===1&&/^[A-Za-z0-9_]{1,15}$/.test(t[0]??``))return t[0]}}}function it(e){if(Qe(e))return null;let{hasDefaultAvatar:t,avatarUrl:n}=ke(e),r=e.querySelector(`[data-testid="User-Name"]`);if(!r)return null;let i,a=``;for(let e of r.querySelectorAll(`a[href^="/"]`)){let t=(e.getAttribute(`href`)??``).split(`/`).filter(Boolean);t.length===1&&/^[A-Za-z0-9_]{1,15}$/.test(t[0]??``)&&(i=t[0])}let o=r.innerText.split(`
`).map(e=>e.trim()).filter(Boolean);if(o.length&&(a=o[0]??``),!i){let e=o.find(e=>e.startsWith(`@`));e&&(i=e.slice(1))}if(!i)return null;let s=e.querySelector(`[data-testid="tweetText"]`),c=s?s.innerText.trim():``,l=et(e,s),u=rt(e,s),d=Ce(e,i),f=Be(e,i),p=Re(e,i),m={...f,...d},h={...f,...d,...!m.userId&&p.userId?{userId:p.userId}:{},...p.viewerFollowing?{viewerFollowing:!0}:{},...Ie(i)?{viewerIsSelf:!0}:{}};return{isProfile:!1,handle:i,displayName:a,bio:h.bio??``,...Ye(t,h),...Xe(h),recentTweets:[],...n?{avatarUrl:n}:{},...h.userId?{userId:h.userId}:{},...c?{triggeringComment:c}:{},...l?{tweetsTranslated:!0}:{},surface:tt(),...u?{isReply:!0,replyToHandle:u}:{},...h.accountCreatedAt?{accountCreatedAt:h.accountCreatedAt}:{},...h.accountAgeDays===void 0?{}:{accountAgeDays:h.accountAgeDays},...h.followersCount===void 0?{}:{followersCount:h.followersCount},...h.followingCount===void 0?{}:{followingCount:h.followingCount},...h.viewerFollowing?{viewerFollowing:!0}:{},...h.viewerBlocking?{viewerBlocking:!0}:{},...h.viewerMuting?{viewerMuting:!0}:{},...h.viewerFollowRequestSent?{viewerFollowRequestSent:!0}:{},...h.viewerIsSelf?{viewerIsSelf:!0}:{}}}function at(){if(!/^\/[^/]+\/status\/\d+/.test(location.pathname))return;let e=document.querySelector(`article[data-testid="tweet"] [data-testid="tweetText"]`)?.innerText.trim();return e?e.slice(0,400):void 0}var ot=[`porn`,`crypto`,`gambling`,`resource`,`marketing`,`other`],st={p:`porn`,c:`crypto`,g:`gambling`,r:`resource`,m:`marketing`,o:`other`};function ct(e){return e&&st[e]||`other`}var lt={porn:`色情招揽`,crypto:`币圈投放`,gambling:`博彩推广`,resource:`网盘资源`,marketing:`营销引流`,other:`其它`},ut=`xss:kol:v1`,dt=3*864e5,ft=600,pt=200,mt=40,ht=40,gt=20,K=null,_t=!1,vt;function yt(e){return e.trim().replace(/^@+/,``).toLowerCase()}async function bt(){if(!_t){_t=!0;try{let e=(await chrome.storage.local.get(ut))[ut];if(!e)return;let t=Date.now();for(let[n,r]of Object.entries(e))n===`__proto__`||n===`constructor`||n===`toString`||!r||typeof r!=`object`||typeof r.handle!=`string`||t-(r.updatedAt??0)>dt||(K??=new Map,K.set(n,r))}catch{}}}function xt(){clearTimeout(vt),vt=setTimeout(()=>void St(),2e3)}async function St(){if(clearTimeout(vt),vt=void 0,!K)return;let e=Date.now();for(let[t,n]of K)e-n.updatedAt>dt&&K.delete(t);if(K.size>ft){let e=[...K.entries()].sort((e,t)=>e[1].updatedAt-t[1].updatedAt);for(let[t]of e.slice(0,K.size-ft))K.delete(t)}let t={};for(let[e,n]of K)t[e]=n;try{await chrome.storage.local.set({[ut]:t})}catch{}}function Ct(e){let t=yt(e.handle);if(!t||!e.statusId)return;K??=new Map;let n=K.get(t)??{handle:t,total:0,original:0,seen:[],tokens:{},tokenTotal:0,updatedAt:0};if(e.userId&&!n.userId&&(n.userId=e.userId),e.displayName&&!n.displayName&&(n.displayName=e.displayName),n.seen.includes(e.statusId)){n.updatedAt=Date.now(),K.set(t,n),xt();return}if(n.seen.push(e.statusId),n.seen.length>mt&&n.seen.splice(0,n.seen.length-mt),n.total<pt&&(n.total+=1,e.original&&(n.original+=1),e.original&&e.text)){let t=0;for(let r of new Set(Tt(e.text)))if(n.tokens[r]=(n.tokens[r]??0)+1,n.tokenTotal+=1,++t>=ht)break}n.updatedAt=Date.now(),K.set(t,n),xt()}function wt(e){let t=K?.get(yt(e));if(!t)return{};let n={};t.total>0&&(n.sampledTweets=t.total),t.total>=5&&(n.originalRatio=t.original/t.total);let r=Et(t);return r!==void 0&&(n.topicFocus=r),n}try{chrome.storage.onChanged.addListener((e,t)=>{if(t!==`local`||!(ut in e))return;let n=e[ut]?.newValue;if(!n||Object.keys(n).length===0){K=new Map;return}let r=new Map;for(let[e,t]of Object.entries(n))e===`__proto__`||e===`constructor`||e===`toString`||!t||typeof t!=`object`||typeof t.handle!=`string`||r.set(e,t);K=r})}catch{}function Tt(e){let t=[];for(let n of e.toLowerCase().matchAll(/[a-z][a-z0-9_']{2,}|[\u4e00-\u9fff]+|\d{2,}/g)){let e=n[0];if(/[\u4e00-\u9fff]/.test(e)){if(e.length<2)continue;for(let n=0;n+2<=e.length;n++)t.push(e.slice(n,n+2))}else t.push(e)}return t}function Et(e){if(e.total<5||e.tokenTotal<gt)return;let t=e.total,n=0;for(let r of Object.values(e.tokens)){let e=r/t;n+=e*e}let r=e.tokenTotal/t;if(!(r<=0))return Math.max(0,Math.min(1,n/r))}function Dt(e){return typeof e!=`number`||!Number.isFinite(e)?50:e<7?5:e<30?25:e<90?50:e<365?70:85}function Ot(e,t){if(typeof e!=`number`||typeof t!=`number`||e<0||t<0||t===0&&e===0)return 50;let n=e/Math.max(1,t);return t>2e3&&e<t*.5?10:n>=1?75:n>=.3?55:n>=.1?35:12}function kt(e,t,n,r){if(typeof r==`number`&&typeof t==`number`&&t>0){let e=r/t;return e>=.02?85:e>=.005?70:e>=.001?45:12}return typeof e!=`number`||typeof t!=`number`||t<=0?50:e/t>20?10:typeof n==`number`&&n>0&&t>1e3&&e/n<.05?35:70}function At(e){return typeof e==`number`?e>=.8?80:e>=.5?60:e>=.2?35:10:50}function jt(e){let t=Dt(e.accountAgeDays),n=Ot(e.followersCount,e.followingCount),r=kt(e.favouritesCount,e.followersCount,e.statusesCount,e.medianLikes),i=At(e.originalRatio),a=Math.round(.3*t+.25*n+.25*r+.2*i);return{score:a,tier:a>=75?`safe`:a>=55?`ok`:a>=35?`warn`:`risk`,parts:{age:t,network:n,engagement:r,original:i}}}var Mt=`
:host { all: initial; }
* { box-sizing: border-box; font-family: system-ui,-apple-system,"Segoe UI",sans-serif; }
/* :host is REQUIRED here: badges/popovers each live in their own shadow
 * root, where :root/.xss match nothing — without :host every var() below
 * fails and the badge degrades to unstyled black text (the v0.5 regression). */
:host, :root, .xss {
  /* dark default (X dark mode) */
  --surface: rgba(13,17,23,.92); --border: rgba(255,255,255,.10);
  --shadow: 0 8px 28px rgba(0,0,0,.45); --text: #E6EDF3; --muted: #8B949E;
  --brand: #0EA5E9; --danger: #EF4444; --warn: #F59E0B; --neutral: #8B949E;
  --safe: #16A34A; --hover: rgba(255,255,255,.06);
}
@media (prefers-color-scheme: light) {
  :host, :root, .xss {
    --surface: rgba(255,255,255,.96); --border: rgba(15,23,42,.12);
    --shadow: 0 8px 28px rgba(15,23,42,.18); --text: #0F172A; --muted: #475569;
    --brand: #0369A1; --danger: #DC2626; --warn: #B45309; --neutral: #475569;
    --safe: #15803D; --hover: rgba(15,23,42,.06);
  }
}
/* X's OWN theme wins over the OS scheme (2026-09-06). X has three themes
 * (Default / Dim / Lights out) chosen in-app, independent of the OS: a user
 * on a light OS with X in Lights out got the light palette above — grey
 * ghost badges and slate popover text on a black page. detectXTheme() reads
 * the page's real background and stamps data-xss-theme on every shadow host
 * and the popover/bubble roots; these blocks come AFTER the media query so
 * they win either way. */
:host([data-xss-theme="dark"]), .xss[data-xss-theme="dark"] {
  --surface: rgba(13,17,23,.92); --border: rgba(255,255,255,.10);
  --shadow: 0 8px 28px rgba(0,0,0,.45); --text: #E6EDF3; --muted: #8B949E;
  --brand: #0EA5E9; --danger: #EF4444; --warn: #F59E0B; --neutral: #8B949E;
  --safe: #16A34A; --hover: rgba(255,255,255,.06);
}
:host([data-xss-theme="light"]), .xss[data-xss-theme="light"] {
  --surface: rgba(255,255,255,.96); --border: rgba(15,23,42,.12);
  --shadow: 0 8px 28px rgba(15,23,42,.18); --text: #0F172A; --muted: #475569;
  --brand: #0369A1; --danger: #DC2626; --warn: #B45309; --neutral: #475569;
  --safe: #15803D; --hover: rgba(15,23,42,.06);
}
.xss-bubble {
  position: fixed;
  right: max(12px, env(safe-area-inset-right));
  top: max(12px, env(safe-area-inset-top));
  z-index: 2147483000;
  color: var(--text); -webkit-font-smoothing: antialiased;
}
/* X pins its search box to the top of the right sidebar; whether a pill at
 * 12px collides with it depends on the viewport width. content.ts measures
 * the real overlap (see avoidSearchBox) and sets --xss-bubble-top only when
 * needed, so the default stays the tidy 12px. */
.xss-bubble:not(.br) { top: var(--xss-bubble-top, max(12px, env(safe-area-inset-top))); }
.xss-bubble.br {
  top: auto;
  bottom: max(12px, env(safe-area-inset-bottom));
}
.pill, .card {
  background: var(--surface); border: 1px solid var(--border);
  box-shadow: var(--shadow); backdrop-filter: blur(12px);
  -webkit-backdrop-filter: blur(12px); border-radius: 14px;
}
.pill {
  display: inline-flex; align-items: center; gap: 8px; padding: 6px 10px;
  border-radius: 999px; cursor: pointer; transition: opacity .14s ease, transform .14s ease;
  min-width: 0; min-height: 36px;
}
.pill:hover { opacity: .94; transform: translateY(-1px); }
.scan-pill {
  display: grid; grid-template-columns: 22px auto auto;
  align-items: center; gap: 7px; width: auto;
}
.scan-radar {
  --accent: var(--brand); --angle: 360deg;
  width: 22px; height: 22px; position: relative; display: grid; place-items: center;
  border-radius: 999px; flex: none;
  background: conic-gradient(var(--accent) var(--angle), color-mix(in srgb, var(--accent) 12%, transparent) 0deg);
  box-shadow: inset 0 0 0 1px color-mix(in srgb, var(--accent) 18%, transparent);
}
.scan-radar.danger { --accent: var(--danger); }
.scan-core {
  position: absolute; inset: 4px; display: grid; place-items: center;
  border-radius: inherit; background: var(--surface);
}
.scan-sweep {
  position: absolute; inset: 2px; border-radius: inherit; opacity: 0;
  background: conic-gradient(from -30deg, transparent 0 64%, color-mix(in srgb, var(--accent) 58%, transparent) 76%, transparent 92%);
}
.scan-radar.busy .scan-sweep {
  opacity: .95; animation: xradar 1.15s linear infinite;
}
.scan-radar.busy {
  animation: xbreath 1.6s ease-in-out infinite;
}
.scan-title {
  overflow: hidden; text-overflow: ellipsis; white-space: nowrap;
  max-width: 46px; font-size: 12.5px; font-weight: 750; color: var(--text);
}
.scan-meta {
  flex: none; font-size: 11px; font-weight: 650; color: var(--muted);
  font-variant-numeric: tabular-nums;
}
.card {
  width: min(312px, calc(100vw - 24px));
  padding: 14px; display: none; margin-top: 10px;
}
/* Expand = the card GROWS out of the pill with a springy overshoot
 * (origin sits up near the pill), instead of teleporting into place. */
.card { transform-origin: calc(100% - 34px) -8px; }
.card.open { display: block; animation: cardin .38s cubic-bezier(.3, 1.28, .44, 1); }
@keyframes cardin {
  0% { opacity: 0; transform: translateY(-7px) scale(.9); }
  55% { opacity: 1; }
  100% { opacity: 1; transform: translateY(0) scale(1); }
}
/* Fold-back mirrors the expand: shrink toward the pill, then display:none
 * (class removed on animationend in collapse()). */
.card.closing { display: block; animation: cardout .2s ease-in forwards; }
@keyframes cardout {
  to { opacity: 0; transform: translateY(-6px) scale(.92); }
}
.hd { display: flex; align-items: center; gap: 8px; font-size: 13px; font-weight: 600; }
.hd .x { margin-left: auto; cursor: pointer; color: var(--muted); display: flex; }
.hd .x:hover { color: var(--text); }
.sub {
  display: grid; grid-template-columns: repeat(4, minmax(0, 1fr));
  gap: 6px; margin: 10px 0 12px;
  font-size: 11px; color: var(--muted);
}
.metric {
  min-width: 0; height: 30px; display: flex; align-items: center; justify-content: center;
  gap: 4px; padding: 0 5px; border-radius: 8px;
  background: color-mix(in srgb, var(--muted) 7%, transparent);
  font-variant-numeric: tabular-nums;
  white-space: nowrap; overflow: hidden;
  position: relative;
}
/* 已处理 counter pop — plays when an absorbed row lands in the chip. */
.metric.tick { animation: mtick .5s cubic-bezier(.3, 1.5, .5, 1); overflow: visible; }
@keyframes mtick {
  0% { transform: scale(1); }
  35% { transform: scale(1.16); }
  100% { transform: scale(1); }
}
.m-plus {
  position: absolute; top: -13px; right: 4px; pointer-events: none;
  font-size: 10px; font-weight: 800; color: var(--danger);
  animation: mplus .8s ease-out forwards;
}
@keyframes mplus {
  0% { opacity: 0; transform: translateY(7px); }
  25% { opacity: 1; }
  100% { opacity: 0; transform: translateY(-9px); }
}
/* Flying ghost of a settled row on its way into the 已处理 chip. */
.q-fly {
  position: fixed; z-index: 2147483002; pointer-events: none;
  display: flex; align-items: flex-start; gap: 8px; padding: 7px 6px;
  border-radius: 10px; color: var(--text);
  background: var(--surface); border: 1px solid var(--border);
  box-shadow: var(--shadow);
}
.metric b { color: var(--text); font-size: 12px; font-weight: 760; line-height: 1; }
.metric em { font-style: normal; overflow: hidden; text-overflow: ellipsis; }
.metric i { width: 6px; height: 6px; border-radius: 50%; display: inline-block; flex: none; }
/* The 已处理 chip doubles as a tab: it lists the whole-session record
 * (done rows from THIS page stay in the live queue too — v0.4 checklist). */
.metric.tab { cursor: pointer; user-select: none; transition: background .14s ease, box-shadow .14s ease; }
.metric.tab:hover { background: color-mix(in srgb, var(--muted) 16%, transparent); }
.metric.tab.on {
  background: color-mix(in srgb, var(--danger) 12%, transparent);
  box-shadow: inset 0 0 0 1px color-mix(in srgb, var(--danger) 38%, transparent);
}
.queue-empty {
  display: flex; align-items: center; justify-content: center; gap: 6px;
  padding: 16px 10px; border-radius: 10px;
  font-size: 11.5px; color: var(--muted);
  background: color-mix(in srgb, var(--safe) 6%, transparent);
}
.btn {
  width: 100%; border: 0; border-radius: 10px; padding: 9px 12px;
  font-size: 13px; font-weight: 600; cursor: pointer; color: #fff;
  background: var(--danger); transition: filter .14s ease;
}
.btn:hover { filter: brightness(1.08); }
.btn:disabled { opacity: .55; cursor: default; }

/* Per-row action button — same color language as bulk btn, smaller scale. */
.xss-act {
  flex: none; border: 0; border-radius: 8px; padding: 5px 10px;
  font-size: 11.5px; font-weight: 600; cursor: pointer; color: #fff;
  background: var(--danger); transition: filter .14s ease, background .14s;
  white-space: nowrap;
}
.xss-act:hover { filter: brightness(1.08); }
.xss-act:disabled { cursor: default; }
/* Done chip stays in the danger family (v0.4 处理垃圾 = 红色语言) — tinted,
 * not solid, so it can't be mistaken for the still-clickable solid button. */
.xss-act.done {
  background: color-mix(in srgb, var(--danger) 14%, transparent);
  color: var(--danger); opacity: .95;
}
.xss-act.queue {
  background: transparent; color: var(--brand);
  border: 1px solid var(--brand);
}
.xss-act.queue.busy { animation: xpulse 1.2s ease-in-out infinite; }
.xss-act.retry {
  background: transparent; color: var(--warn);
  border: 1px solid var(--warn);
}

/* Per-row select checkbox — themed, replaces native browser styling. */
.xss-row-cb {
  width: 15px; height: 15px; flex: none; cursor: pointer;
  appearance: none; -webkit-appearance: none;
  border: 1.5px solid var(--border); border-radius: 4px;
  background: transparent; transition: border-color .12s, background .12s;
  position: relative; margin-top: 6px;
}
.xss-row-cb:hover { border-color: var(--danger); }
.xss-row-cb:checked {
  background: var(--danger); border-color: var(--danger);
}
.xss-row-cb:checked::after {
  content: ""; position: absolute; left: 3px; top: 0;
  width: 5px; height: 9px; border: solid #fff;
  border-width: 0 1.5px 1.5px 0; transform: rotate(45deg);
}
.xss-row-cb:disabled { opacity: .35; cursor: default; }

/* 自动处理 master switch (card header area) — themed mini toggle. */
.auto-row {
  display: flex; align-items: center; gap: 7px; margin-top: 9px;
  font-size: 11.5px; font-weight: 600; color: var(--text);
}
.auto-row .auto-hint {
  margin-left: auto; font-size: 10.5px; font-weight: 500;
  color: var(--muted); white-space: nowrap; overflow: hidden;
  text-overflow: ellipsis;
}
.xss-sw {
  position: relative; width: 30px; height: 18px; flex: none; padding: 0;
  border-radius: 999px; cursor: pointer;
  border: 1px solid var(--border);
  background: color-mix(in srgb, var(--muted) 28%, transparent);
  transition: background .16s ease, border-color .16s ease;
}
.xss-sw::after {
  content: ""; position: absolute; top: 2px; left: 2px;
  width: 12px; height: 12px; border-radius: 50%; background: #fff;
  box-shadow: 0 1px 3px rgba(0,0,0,.35);
  transition: transform .16s ease;
}
.xss-sw[aria-checked="true"] { background: var(--brand); border-color: var(--brand); }
.xss-sw[aria-checked="true"]::after { transform: translateX(12px); }
@media (prefers-reduced-motion: reduce) {
  .xss-sw, .xss-sw::after { transition: none; }
}
.row { display: flex; gap: 14px; margin-top: 10px; font-size: 12px; }
.lnk { color: var(--muted); cursor: pointer; }
.lnk:hover { color: var(--text); }
.block-progress {
  margin: -2px 0 13px;
}
.progress-head {
  display: flex; align-items: center; justify-content: space-between;
  margin-bottom: 6px; font-size: 11px; color: var(--muted);
  font-variant-numeric: tabular-nums;
}
.progress-head b {
  color: var(--text); font-size: 11px; font-weight: 750;
}
.progress-track {
  height: 9px; display: flex; overflow: hidden; border-radius: 999px;
  background: color-mix(in srgb, var(--muted) 12%, transparent);
  box-shadow: inset 0 0 0 1px color-mix(in srgb, var(--text) 8%, transparent);
}
.progress-seg {
  height: 100%; min-width: 0; transition: width .22s ease;
}
.progress-seg + .progress-seg {
  box-shadow: inset 1px 0 0 color-mix(in srgb, var(--surface) 70%, transparent);
}
.progress-seg.done { background: linear-gradient(90deg, color-mix(in srgb, var(--danger) 78%, #fff), var(--danger)); }
.progress-seg.active {
  background:
    repeating-linear-gradient(115deg, rgba(255,255,255,.22) 0 6px, transparent 6px 12px),
    linear-gradient(90deg, color-mix(in srgb, var(--danger) 72%, #fff), var(--danger));
  animation: pbarshift .9s linear infinite;
}
.progress-seg.queued { background: linear-gradient(90deg, color-mix(in srgb, var(--brand) 76%, #fff), var(--brand)); }
.progress-seg.failed { background: linear-gradient(90deg, color-mix(in srgb, var(--warn) 76%, #fff), var(--warn)); }
.progress-seg.idle { background: color-mix(in srgb, var(--muted) 24%, transparent); }
.queue-table {
  max-height: 226px; overflow: auto; margin: 0 -4px 10px; padding: 0 4px;
  scrollbar-width: thin;
  /* Rows carry state tints now — breathing room between them, or adjacent
   * tinted rows fuse into one solid slab. */
  display: flex; flex-direction: column; gap: 5px;
}
.qrow {
  display: flex; align-items: flex-start; gap: 8px; padding: 7px 6px;
  border-radius: 10px; transform-origin: top center; flex: none;
  transition: background .14s ease, opacity .14s ease;
}
/* First render of a row slides in; on card expand every row is "new", and
 * the per-slot delays turn that into a soft cascade down the list. */
.qrow.new { animation: qrowin .26s cubic-bezier(.2,.7,.2,1) backwards; }
.qrow.new:nth-child(2) { animation-delay: .045s; }
.qrow.new:nth-child(3) { animation-delay: .09s; }
.qrow.new:nth-child(4) { animation-delay: .135s; }
.qrow.new:nth-child(n+5) { animation-delay: .18s; }
.qrow.active { background: color-mix(in srgb, var(--danger) 8%, transparent); }
.qrow.queued { background: color-mix(in srgb, var(--brand) 7%, transparent); }
.qrow.failed { background: color-mix(in srgb, var(--warn) 8%, transparent); }
/* Done rows go QUIET (neutral, not red): strikethrough + dimmed avatar
 * already say "handled", and full red tint here drowned the hierarchy —
 * red is reserved for the in-flight row and the small status accents. */
.qrow.done { background: color-mix(in srgb, var(--muted) 7%, transparent); }
.qavatar {
  width: 26px; height: 26px; border-radius: 50%; flex: none; object-fit: cover;
  transition: filter .18s ease, opacity .18s ease;
}
.qavatar.blank { background: var(--border); }
.qbody { min-width: 0; flex: 1; }
.qname {
  font-weight: 650; font-size: 12px; overflow: hidden;
  text-overflow: ellipsis; white-space: nowrap;
}
.qmeta { font-size: 11px; }
/* Per-row 误判 link — quiet until hovered, so it never competes with the
 * account meta but stays reachable for a wrongly-listed account. */
.qappeal {
  margin-left: 6px; color: var(--muted); cursor: pointer;
  text-decoration: none; font-weight: 600; opacity: .7;
  /* Two-character link must never split across lines ("误" / "判"). */
  display: inline-block; white-space: nowrap;
}
.qappeal:hover { color: var(--warn); opacity: 1; text-decoration: underline; }
.qsnip {
  font-size: 11px; color: var(--muted); overflow: hidden;
  text-overflow: ellipsis; white-space: nowrap;
}
/* 命中原因 chips — tiny tags, visually separate from the content snippet. */
.qtags { display: flex; flex-wrap: wrap; gap: 4px; margin: 2px 0 1px; }
.qtag {
  font-size: 9.5px; font-weight: 650; line-height: 1; padding: 2.5px 6px;
  border-radius: 999px; white-space: nowrap; max-width: 160px;
  overflow: hidden; text-overflow: ellipsis;
  color: var(--muted); border: 1px solid color-mix(in srgb, var(--muted) 32%, transparent);
  background: color-mix(in srgb, var(--muted) 8%, transparent);
}
.qtag.warn {
  color: var(--warn); border-color: color-mix(in srgb, var(--warn) 45%, transparent);
  background: color-mix(in srgb, var(--warn) 9%, transparent);
}
.qnote { font-size: 11px; }
.qrow.done .qavatar {
  filter: grayscale(1); opacity: .38;
}
.qrow.done .qname,
.qrow.done .qsnip {
  text-decoration: line-through; opacity: .52;
}
/* One-shot red flash the moment a row flips to done — the checklist
 * "tick" that makes batch progress feel tangible (danger family, v0.4). */
.qrow.done.flip { animation: qdoneflash .45s ease-out; }
@keyframes qdoneflash {
  0% { background: color-mix(in srgb, var(--danger) 26%, transparent); transform: scale(1.015); }
}
svg { display: block; }
.xss-badge {
  --badge-color: var(--muted);
  display: inline-flex; align-items: center; gap: 4px; margin-left: 6px;
  padding: 3px 9px; border-radius: 999px; font-size: 11px; font-weight: 750;
  line-height: 1; white-space: nowrap;
  vertical-align: middle; cursor: default;
  /* Solid pill, white text — the "精致明显" badge users recognize. A subtle
   * inner highlight ring + darker edge give it the polished look; tinted
   * outline variants read as washed-out in the timeline. */
  color: #fff; background: var(--badge-color);
  border: 1px solid color-mix(in srgb, var(--badge-color) 78%, #000);
  box-shadow: inset 0 0 0 1px rgba(255,255,255,.16), 0 1px 4px rgba(15,23,42,.16);
}
.xss-badge svg { flex: none; }
.xss-badge.ghost {
  color: var(--muted); cursor: pointer;
  border-color: var(--border); background: transparent; box-shadow: none;
}
.xss-badge.ghost:hover { color: var(--text); }
/* Local-whitelist member: green = "safe by your own choice" (the only place
 * green is allowed besides legit/empty states). */
.xss-badge.ghost.wl {
  color: var(--safe);
  border-color: color-mix(in srgb, var(--safe) 42%, var(--border));
  background: color-mix(in srgb, var(--safe) 8%, transparent);
}
.xss-badge.ghost.wl:hover { color: var(--safe); filter: brightness(1.1); }
/* AI-checked clean (二开): quieter than the whitelist ghost — a translucent
 * green outline that reads as "已看过，没事" and never as an alarm. */
.xss-badge.ghost.ok {
  color: color-mix(in srgb, var(--safe) 78%, var(--muted));
  border-color: color-mix(in srgb, var(--safe) 30%, var(--border));
  background: color-mix(in srgb, var(--safe) 5%, transparent);
}
.xss-badge.ghost.ok:hover { color: var(--safe); filter: brightness(1.08); }
.acts button[data-wl] {
  color: var(--safe);
  border-color: color-mix(in srgb, var(--safe) 45%, var(--border));
}
/* 举报 category chips — replace the 举报 button in place on first click. */
.rep-cats { display: flex; flex-wrap: wrap; align-items: center; gap: 5px; width: 100%; }
.rep-cats-label { flex: 0 0 100%; font-size: 11px; color: var(--muted); margin: 2px 0 1px; }
.rep-cats button {
  border: 1px solid color-mix(in srgb, var(--warn) 48%, var(--border));
  background: color-mix(in srgb, var(--warn) 9%, transparent); color: var(--warn);
  border-radius: 999px; padding: 4px 9px; font-size: 11px; font-weight: 650; cursor: pointer;
}
.rep-cats button:hover { filter: brightness(1.08); transform: translateY(-1px); }
/* v0.4 popover: soft 12px radius, deep layered shadow, pop-in scale. */
.pop {
  position: fixed; z-index: 2147482001; width: 280px; padding: 12px;
  margin: 0; /* .card's margin-top would shift the measured placement */
  max-width: calc(100vw - 16px);
  font-size: 12px; color: var(--text); border-radius: 12px;
  box-shadow: 0 18px 48px rgba(15,23,42,.22), 0 2px 8px rgba(15,23,42,.10);
  transform-origin: 12px 12px; animation: xpop .14s ease-out;
  pointer-events: auto;
}
.pop h4 { margin: 0 0 6px; font-size: 12.5px; font-weight: 750; }
.pop ul { margin: 6px 0; padding-left: 16px; color: var(--muted); }
.pop li { margin: 3px 0; }
/* v0.4 action buttons: pill shape with a per-action visual hierarchy —
 * data-b solid danger (primary), data-h muted outline, data-r warm outline,
 * data-a plain text link. */
.acts { display: flex; flex-wrap: wrap; align-items: center; gap: 7px; margin-top: 10px; }
.acts button {
  border: 1px solid var(--border); background: transparent; color: var(--text);
  border-radius: 999px; padding: 5px 10px; font-size: 11px; font-weight: 650;
  cursor: pointer; transition: transform .12s ease, background .12s ease, border-color .12s ease, color .12s ease, filter .12s ease;
}
.acts button:hover { transform: translateY(-1px); background: var(--hover); }
.acts button[data-b] {
  color: #fff; border-color: transparent;
  background: linear-gradient(180deg, color-mix(in srgb, var(--danger) 92%, #fff), var(--danger));
}
.acts button[data-b]:hover { filter: brightness(1.05); }
.acts button[data-h] {
  color: var(--muted);
  border-color: color-mix(in srgb, var(--muted) 32%, var(--border));
}
.acts button[data-r] {
  color: var(--warn);
  border-color: color-mix(in srgb, var(--warn) 48%, var(--border));
  background: color-mix(in srgb, var(--warn) 9%, transparent);
}
.acts button[data-a] { color: var(--muted); border-color: transparent; }
.acts button[data-report] {
  color: var(--warn);
  border-color: color-mix(in srgb, var(--warn) 46%, var(--border));
  background: color-mix(in srgb, var(--warn) 9%, transparent);
}
.acts button:disabled { cursor: default; transform: none; filter: none; opacity: .7; }
/* 举报 inline result line — text only, colored by outcome. */
.pop-status { margin-top: 8px; font-size: 11px; line-height: 1.5; }
.pop-status[data-kind="info"] { color: var(--muted); }
.pop-status[data-kind="ok"] { color: var(--danger); }
.pop-status[data-kind="err"] { color: var(--warn); }
@media (pointer: coarse) {
  .pill { min-height: 44px; }
  .acts button { min-height: 40px; padding-inline: 14px; }
  .xss-badge { min-height: 28px; }
}

/* ---- animated badge states (transform/opacity only) ---- */
.xss-badge.fresh { animation: xrise .22s ease-out; }
.xss-badge.known { animation: xpop .18s ease-out; }
.xss-badge .ntag {
  margin-left: 4px; padding: 0 5px; border-radius: 999px; font-size: 9px;
  font-weight: 700; color: var(--warn); border: 1px solid var(--warn);
  letter-spacing: .3px;
}
.xss-badge.analyzing {
  color: var(--brand); position: relative; overflow: hidden;
  background: color-mix(in srgb, var(--brand) 8%, transparent);
  border-color: color-mix(in srgb, var(--brand) 30%, transparent);
  box-shadow: none;
}
.xss-badge.analyzing::after {
  content: ""; position: absolute; inset: 0;
  background: linear-gradient(90deg, transparent, color-mix(in srgb, var(--brand) 14%, transparent), transparent);
  transform: translateX(-100%); animation: xshim 1.1s ease-in-out infinite;
}
.xss-checked { display: none !important; }
.xss-spin { animation: xspin .8s linear infinite; transform-origin: 50% 50%; }
/* Pending-undo badge (⏳ 5秒后处理 + 撤销) — warn-outlined, not a solid pill. */
.xss-badge.pending {
  color: var(--warn); cursor: default;
  background: color-mix(in srgb, var(--warn) 10%, transparent);
  border-color: var(--warn); box-shadow: none;
  animation: xpulse 1.6s ease-in-out infinite;
}
/* v0.4 "拉黑中" in-place badge: solid danger pill breathing on the tweet
 * while the auto queue works it, with a spinner ring around the icon —
 * THIS is the visible "the extension is doing something" moment. */
.xss-badge.acting {
  --badge-color: var(--danger);
  color: #fff; cursor: default; overflow: visible;
  background: linear-gradient(180deg, color-mix(in srgb, var(--danger) 92%, #fff), var(--danger));
  border-color: color-mix(in srgb, var(--danger) 90%, transparent);
  box-shadow: 0 0 0 2px color-mix(in srgb, var(--danger) 18%, transparent), 0 2px 9px color-mix(in srgb, var(--danger) 24%, transparent);
  animation: xactpulse 1.25s ease-in-out infinite;
}
.xss-badge.acting .xss-ico {
  position: relative; display: inline-flex; flex: none;
}
.xss-badge.acting .xss-ico::after {
  content: ""; position: absolute; inset: -4px; border-radius: 999px;
  border: 1.5px solid color-mix(in srgb, #fff 30%, transparent);
  border-top-color: #fff; animation: xspin .72s linear infinite;
}
@keyframes xactpulse {
  0%,100% { transform: translateY(0); filter: brightness(1); }
  50% { transform: translateY(-1px); filter: brightness(1.1); }
}
/* Queued-for-auto badge — quiet outline, the row is waiting its turn. */
.xss-badge.actqueued {
  color: var(--danger); cursor: default;
  background: color-mix(in srgb, var(--danger) 9%, transparent);
  border-color: color-mix(in srgb, var(--danger) 45%, transparent);
  box-shadow: none; animation: xpulse 1.8s ease-in-out infinite;
}
@keyframes xrise { from { opacity: 0; transform: translateY(4px); } }
@keyframes xpop  { from { opacity: 0; transform: scale(.9); } }
@keyframes xspin { to { transform: rotate(360deg); } }
@keyframes xshim { to { transform: translateX(100%); } }
@keyframes xpulse { 0%,100% { opacity: .55; } 50% { opacity: .95; } }
@keyframes xradar { to { transform: rotate(360deg); } }
@keyframes xbreath { 0%,100% { filter: saturate(1); } 50% { filter: saturate(1.35); } }
@keyframes qrowin {
  from { opacity: 0; transform: translateY(-7px) scale(.985); }
}
@keyframes pbarshift {
  to { background-position: 22px 0, 0 0; }
}

/* New-hit motion: one compact radar lap, slow at first then faster. */
.pill.hit-pulse .scan-radar {
  animation: xhitspin .82s cubic-bezier(.62, 0, 1, .62) 1, xhitglow .9s ease-out 1;
}
@keyframes xhitspin {
  0% { transform: rotate(0deg) scale(1); }
  42% { transform: rotate(72deg) scale(1.08); }
  100% { transform: rotate(360deg) scale(1); }
}
@keyframes xhitglow {
  0% { box-shadow: inset 0 0 0 1px color-mix(in srgb, var(--accent) 18%, transparent), 0 0 0 0 color-mix(in srgb, var(--accent) 0%, transparent); }
  32% { box-shadow: inset 0 0 0 1px color-mix(in srgb, var(--accent) 24%, transparent), 0 0 0 5px color-mix(in srgb, var(--accent) 18%, transparent); }
  100% { box-shadow: inset 0 0 0 1px color-mix(in srgb, var(--accent) 18%, transparent), 0 0 0 0 color-mix(in srgb, var(--accent) 0%, transparent); }
}

@media (prefers-reduced-motion: reduce) {
  .card.open { animation: fade .18s ease-out; }
  .card.closing { display: none; animation: none; }
  @keyframes fade { from { opacity: 0; } }
  .xss-badge.fresh, .xss-badge.known { animation: fade .18s ease-out; }
  .xss-badge.analyzing::after, .xss-spin { animation: none; }
  .xss-badge.pending { animation: none; opacity: .7; }
  .xss-badge.acting, .xss-badge.acting .xss-ico::after,
  .xss-badge.actqueued { animation: none; }
  .metric.tick, .m-plus { animation: none; }
  .m-plus { display: none; }
  .scan-radar.busy,
  .scan-radar.busy .scan-sweep,
  .qrow.new,
  .qrow.done.flip,
  .xss-act.queue.busy,
  .progress-seg.active { animation: none; }
  .pill.hit-pulse .scan-radar { animation: none; }
}
`,q=e=>e.replace(/[<>&"]/g,e=>({"<":`&lt;`,">":`&gt;`,"&":`&amp;`,'"':`&quot;`})[e]??e),Nt=e=>e&&/^https:\/\/pbs\.twimg\.com\//.test(e)?e:void 0;function J(){try{for(let e of[document.body,document.documentElement]){if(!e)continue;let t=getComputedStyle(e).backgroundColor.match(/rgba?\((\d+)\s*,\s*(\d+)\s*,\s*(\d+)(?:\s*,\s*([\d.]+))?\)/);if(t&&(t[4]===void 0||Number(t[4])>.5))return .2126*Number(t[1])+.7152*Number(t[2])+.0722*Number(t[3])<128?`dark`:`light`}let e=getComputedStyle(document.documentElement).colorScheme;if(/dark/.test(e))return`dark`;if(/light/.test(e))return`light`}catch{}try{return matchMedia(`(prefers-color-scheme: dark)`).matches?`dark`:`light`}catch{return`dark`}}function Pt(e=J()){for(let t of document.querySelectorAll(`.xss-mount, [data-xss-overlay], .xss-bubble, .xss.pop`))t.setAttribute(`data-xss-theme`,e);return e}function Ft(e,t,n){e&&(e.textContent=t,e.dataset.kind=n,e.hidden=!1)}var It={shield:`M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z`,"shield-alert":`M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10zM12 8v4M12 16h.01`,"shield-x":`M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10zM9.5 9.5l5 5M14.5 9.5l-5 5`,"shield-check":`M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10zM9 12l2 2 4-4`,x:`M18 6 6 18M6 6l12 12`};function Y(e,t=`currentColor`,n=16){return`<svg width="${n}" height="${n}" viewBox="0 0 24 24" fill="none"
    stroke="${t}" stroke-width="1.75" stroke-linecap="round"
    stroke-linejoin="round" aria-hidden="true"><path d="${It[e]??It.shield}"/></svg>`}var Lt={spam:`垃圾`,porn_bot:`色情`,likely_spam:`疑似`,uncertain:`存疑`,legit:`正常`},Rt={spam:{zh:`垃圾`,varName:`--danger`,ic:`shield-x`},porn_bot:{zh:`色情bot`,varName:`--danger`,ic:`shield-x`},likely_spam:{zh:`疑似垃圾`,varName:`--warn`,ic:`shield-alert`},uncertain:{zh:`不确定`,varName:`--neutral`,ic:`shield`},legit:{zh:`正常`,varName:`--safe`,ic:`shield-check`}};function zt(e,t=`tr`,n=`隐藏`,r={}){let i=document.createElement(`div`);i.className=`xss xss-bubble${t===`br`?` br`:``}`,i.setAttribute(`data-xss-theme`,J()),i.setAttribute(`role`,`status`),i.setAttribute(`aria-live`,`polite`);let a=document.createElement(`button`);a.className=`pill`,a.setAttribute(`aria-label`,`${he.acronym} 本页可疑账号`);let o=document.createElement(`div`);o.className=`card`,i.append(a,o);let s=!1,c=[],l=0,u=new Map,d=new Set,f=new Set,p=new Set,m=new Set,h=new Map,g=new Set,_=[],v=!1,y=new Set,b=new Map,x=[],S=new Set,C=r.autoProcess??!0,w=r.autoCategoryCount??0,ee=r.autoScopeAll??!1,T=`queue`,E=new Map,te=0,D=e=>E.set(e,++te),ne=(e,t)=>(E.get(k(t))??0)-(E.get(k(e))??0),O=0,k=e=>e.userId||`h:${e.handle}`,re=e=>u.get(k(e))??`pending`,A=e=>{if(y.has(k(e))||S.has(k(e)))return!1;let t=re(e);return t===`pending`||t===`failed`},ie=e=>e.some(e=>e.verdict.label===`spam`||e.verdict.label===`porn_bot`)?`--danger`:`--warn`;function j(){let e=0,t=0,n=0,r=0,i=0;for(let a of c)switch(re(a)){case`done`:e++;break;case`processing`:t++;break;case`queued`:n++;break;case`failed`:r++;break;default:i++}return{found:c.length,done:e,processing:t,queued:n,failed:r,pending:i,running:t+n}}function ae(e,t){return e<=0||t<=0?`0%`:`${Math.max(0,Math.min(100,e/t*100)).toFixed(2)}%`}function M(e,t,n){return t<=0?``:`<span class="progress-seg ${e}" style="width:${ae(t,n)}"></span>`}function oe(e){let t=Math.max(1,e.found),n=Math.round(e.done/t*100),r=e.processing+e.queued+e.pending;return`<div class="block-progress" aria-label="处理进度 ${n}%">
      <div class="progress-head">
        <span>${r>0?`剩余 ${r}`:`处理完成`}</span>
        <b>${n}%</b>
      </div>
      <div class="progress-track">
        ${M(`done`,e.done,t)}
        ${M(`active`,e.processing,t)}
        ${M(`queued`,e.queued,t)}
        ${M(`failed`,e.failed,t)}
        ${M(`idle`,e.pending,t)}
      </div>
    </div>`}function se(e){let t=Math.max(0,Math.min(100,e.percent)),n=Math.round(t*3.6);return`<span class="scan-pill">
      <span class="scan-radar ${e.busy?`busy`:``} ${e.danger?`danger`:``}" style="--angle:${n}deg">
        <span class="scan-sweep"></span>
        <span class="scan-core">${Y(e.iconName,e.iconColor,11)}</span>
      </span>
      <span class="scan-title">${e.title}</span>
      ${e.count?`<span class="scan-meta">${e.count}</span>`:``}
    </span>`}function N(){if(c.length){let e=j();if(e.running>0){a.innerHTML=se({iconName:`shield-x`,iconColor:`var(--danger)`,title:`${n}中`,count:`${e.done}/${e.found}`,percent:Math.max(8,Math.round(e.done/Math.max(1,e.found)*100)),busy:!0,danger:!0});return}if(e.done>0&&e.done+e.failed>=e.found){a.innerHTML=se({iconName:`shield-check`,iconColor:`var(--danger)`,title:`已${n}`,count:String(e.done),percent:100,danger:!0});return}a.innerHTML=se({iconName:`shield-alert`,iconColor:`var(${ie(c)})`,title:`命中`,count:String(c.length),percent:100,busy:l>0,danger:!0});return}if(l>0){a.innerHTML=se({iconName:`shield`,iconColor:`var(--brand)`,title:`检查中`,count:String(l),percent:0,busy:!0});return}if(x.length>0){a.innerHTML=se({iconName:`shield-check`,iconColor:`var(--danger)`,title:`已处理`,count:String(x.length),percent:100,danger:!0});return}a.innerHTML=se({iconName:`shield-check`,iconColor:`var(--brand)`,title:`守护`,percent:100})}function ce(){let e=C?w>0?`${w} 类自动 · ${ee?`全局`:`仅评论区`}`:`全部仅标记`:`已暂停 · 仅标记`;return`<div class="auto-row">
      <button class="xss-sw" data-auto role="switch" aria-checked="${C}"
        aria-label="自动处理"></button>
      <span>自动处理</span>
      <span class="auto-hint">${e}</span>
    </div>`}function P(){o.querySelector(`[data-auto]`)?.addEventListener(`click`,()=>{C=!C,e.onToggleAuto?.(C),F()})}function F(){if(!c.length&&!x.length){o.innerHTML=`
        <div class="hd">${Y(`shield-check`,`var(--brand)`,16)}
          <span>${he.acronym} 已启用</span>
          <span class="x" data-x>${Y(`x`,`currentColor`,14)}</span></div>
        ${ce()}
        <div class="sub" style="display:block;line-height:1.6">
          正在被动检查本页账号。发现可疑的垃圾/色情机器人时，会在这里提示并提供一键处理。</div>
        <div class="row"><span class="lnk" data-gov>为什么 / 治理</span></div>`,o.querySelector(`[data-x]`)?.addEventListener(`click`,V),o.querySelector(`[data-gov]`)?.addEventListener(`click`,()=>window.open(he.governance,`_blank`,`noopener`)),P();return}let t=j(),r=t.queued+t.pending,a=c.filter(e=>A(e)&&!d.has(k(e))).length,s=c.filter(A).length,l=t.done+t.processing+t.queued+t.failed>0,u=new Set(c.map(k)),h=x.filter(e=>!u.has(k(e))),_=[...c.filter(e=>m.has(k(e))),...h];T===`done`&&!_.length&&(T=`queue`);let v=(T===`done`?_:c.filter(e=>{let t=k(e);return!m.has(t)&&!g.has(t)})).sort(ne);o.innerHTML=`
      <div class="hd">${Y(`shield-alert`,`var(--brand)`,16)}
        <span>${c.length?s||t.running?`本页发现 ${c.length} 个可疑账号`:`本页已处理 ${t.done} 个账号`:`近期已处理 ${_.length} 个账号`}</span>
        <span class="x" data-x>${Y(`x`,`currentColor`,14)}</span></div>
      ${ce()}
      <div class="sub">
        <span class="metric" title="本页命中的可疑账号">
          <i style="background:var(--danger)"></i><b>${t.found}</b><em>命中</em>
        </span>
        <span class="metric" title="正在处理">
          <i style="background:var(--warn)"></i><b>${t.processing}</b><em>正在</em>
        </span>
        <span class="metric" title="等待处理">
          <i style="background:var(--muted)"></i><b>${r}</b><em>待处理</em>
        </span>
        <span class="metric${_.length?` tab`:``}${T===`done`?` on`:``}"
          data-done-chip ${_.length?`data-tab-done role="button" tabindex="0" aria-pressed="${T===`done`}"`:``}
          title="${t.failed?`失败 ${t.failed}，`:``}近期已处理（含之前页面与历史记录）${_.length?` · 点击查看明细`:``}">
          <i style="background:${t.failed?`var(--warn)`:`var(--danger)`}"></i><b>${_.length}</b><em>已处理</em>
        </span>
      </div>
      ${l?oe(t):``}
      <div class="queue-table">
        ${v.length?``:`<div class="queue-empty">${Y(`shield-check`,`var(--safe)`,13)}<span>本页暂无新命中 · 点「已处理」查看记录</span></div>`}
        ${v.map(e=>{let t=Rt[e.verdict.label],r=`var(${t.varName})`,i=Nt(e.avatarUrl),a=i?`<img src="${q(i)}" class="qavatar" alt="">`:`<span class="qavatar blank"></span>`,o=q(e.displayName?.trim()||`@${e.handle}`),s=e.snippet?q(e.snippet.replace(/\s+/g,` `).trim()).slice(0,60):``,c=k(e),l=!f.has(c);f.add(c);let u=re(e),m=u===`done`&&!p.has(c);u===`done`&&p.add(c);let h=[`qrow`,l?`new`:``,u===`processing`?`active`:u===`pending`?``:u,m?`flip`:``].filter(Boolean).join(` `),g=y.has(c),_=A(e),v=_&&!d.has(c),x=u===`done`?`xss-act done`:u===`processing`?`xss-act queue busy`:u===`queued`?`xss-act queue`:u===`failed`?`xss-act retry`:`xss-act`,S=g?u===`done`?`已处理`:u===`failed`?`失败`:u===`queued`?`排队中`:`处理中`:u===`done`?`已${n}`:u===`processing`?`${n}中`:u===`queued`?`待处理`:u===`failed`?`重试`:n,C=g||u===`done`||u===`processing`||u===`queued`;return`<div class="${h}" data-rk="${q(c)}">
              <input type="checkbox" class="xss-row-cb" data-sel="${q(c)}"
                aria-label="选中 @${q(e.handle)}"
                ${v?`checked`:``} ${_?``:`disabled`}>
              ${a}
              <div class="qbody">
                <div class="qname">${o}</div>
                <div class="qmeta" style="color:${r}">@${q(e.handle)} · ${t.zh} ${(e.verdict.confidence*100).toFixed(0)}%<a class="qappeal" data-appeal-h="${q(e.handle)}"${e.userId?` data-appeal-u="${q(e.userId)}"`:``} title="误判？提交申诉（已预填账号信息）">误判</a></div>
                ${(()=>{let t=[];return e.source===`local-index`?(t.push(`<span class="qtag">公榜</span>`),e.tier&&t.push(`<span class="qtag">${e.tier===`confirmed`?`人工确认`:`自动收录`}</span>`)):e.source===`local-rule`?t.push(`<span class="qtag">规则</span>`):e.source===`cache`&&t.push(`<span class="qtag">缓存</span>`),e.categoryZh&&t.push(`<span class="qtag">${q(e.categoryZh)}</span>`),e.source===`local-rule`&&!g&&t.push(`<span class="qtag warn">需手动</span>`),t.length?`<div class="qtags" title="${q(e.verdict.reasons.join(`
`))}">${t.join(``)}</div>`:``})()}
                ${s?`<div class="qsnip">${s}</div>`:``}
                ${u===`processing`?`<div class="qnote" style="color:var(--danger)">${g?`自动${b.get(c)??`处理`}中…`:`正在${n}…`}</div>`:``}
                ${u===`queued`?`<div class="qnote" style="color:var(--brand)">排队等待处理</div>`:``}
                ${u===`failed`?`<div class="qnote" style="color:var(--warn)">${g?`自动${b.get(c)??`处理`}失败`:`处理失败`} · <a href="https://x.com/${q(e.handle)}" target="_blank" rel="noopener" style="color:var(--warn)">手动处理</a></div>`:``}
                ${u===`done`?`<div class="qnote" style="color:var(--danger)">✓ 已${g?`自动${b.get(c)??`处理`}`:n}</div>`:``}
              </div>
              <button class="${x}" data-one="${q(c)}"${C?` disabled`:``}>${S}</button>
            </div>`}).join(``)}
      </div>
      ${c.length?t.running>0?`<button class="btn" disabled style="background:var(--brand)">${n}中 · 正在 ${t.processing} · 待 ${t.queued}</button>`:s===0?`<button class="btn" disabled style="background:color-mix(in srgb, var(--danger) 12%, transparent);color:var(--danger);opacity:1">✓ 已全部处理 (${t.done})</button>`:a===0?`<button class="btn" disabled style="opacity:.55">未选中任何账号 (剩余 ${s})</button>`:`<button class="btn" data-run>一键${n}选中 ${a}${t.done?` · 已完成 ${t.done}`:``}${a<s?` · 跳过 ${s-a}`:``}</button>`:``}
      <div class="row"><span class="lnk" data-each>逐个查看处理</span>
        <span class="lnk" data-ign>忽略本页</span></div>`,P(),o.querySelector(`[data-x]`)?.addEventListener(`click`,V),o.querySelector(`[data-ign]`)?.addEventListener(`click`,()=>{e.onDismiss(),i.remove()}),o.querySelector(`[data-each]`)?.addEventListener(`click`,e.onReviewEach);for(let t of o.querySelectorAll(`[data-appeal-h]`))t.addEventListener(`click`,()=>{let n=t.dataset.appealH;if(!n)return;let r=t.dataset.appealU;e.onAppeal({handle:n,...r?{userId:r}:{}})});let S=o.querySelector(`[data-tab-done]`),C=()=>{T=T===`done`?`queue`:`done`,F()};S?.addEventListener(`click`,C),S?.addEventListener(`keydown`,e=>{(e.key===`Enter`||e.key===` `)&&(e.preventDefault(),C())}),o.querySelectorAll(`[data-sel]`).forEach(e=>{e.addEventListener(`change`,()=>{let t=e.dataset.sel;t&&(e.checked?d.delete(t):d.add(t),F())})}),o.querySelectorAll(`[data-one]`).forEach(e=>{e.addEventListener(`click`,()=>{let t=e.dataset.one,n=c.find(e=>k(e)===t);n&&A(n)&&I([k(n)])})});let w=o.querySelector(`.queue-table`);w&&T===`queue`&&(O>0&&(w.scrollTop=O),w.addEventListener(`scroll`,()=>{O=w.scrollTop},{passive:!0}));let ee=o.querySelector(`[data-run]`);ee?.addEventListener(`click`,()=>{ee.disabled=!0,ee.textContent=`处理中…`,I(c.filter(e=>A(e)&&!d.has(k(e))).map(k))})}function le(e){m.has(e)||h.has(e)||h.set(e,setTimeout(()=>{h.delete(e),ue(e)},400))}function ue(e){m.has(e)||g.has(e)||_.includes(e)||(_.push(e),de())}async function de(){if(!v){v=!0;try{for(;_.length;){let e=_.shift();if(!e)break;await fe([e]),await new Promise(e=>setTimeout(e,160))}}finally{v=!1}}}function fe(e){let t=e.filter(e=>!m.has(e)&&!g.has(e));if(!t.length)return Promise.resolve();for(let e of t)g.add(e);let n=()=>{for(let e of t)g.delete(e),m.add(e);s&&F()},r=o.querySelector(`[data-done-chip]`),a=o.querySelector(`.queue-table`),c=window.matchMedia(`(prefers-reduced-motion: reduce)`).matches;if(!s||T!==`queue`||!r||!a||c)return n(),Promise.resolve();let l=r.getBoundingClientRect(),u=a.getBoundingClientRect();if(!l.width)return n(),Promise.resolve();let d=[],f=0;for(let e of t){let t=o.querySelector(`[data-rk="${CSS.escape(e)}"]`),n=t?.getBoundingClientRect(),r=!!t&&!!n?.width&&n.bottom>u.top+4&&n.top<u.bottom-4;if(!t||!n||!r)continue;let a=t.cloneNode(!0);a.className=`q-fly`,a.style.left=`${n.left}px`,a.style.top=`${n.top}px`,a.style.width=`${n.width}px`,t.style.overflow=`hidden`,t.animate([{height:`${n.height}px`,opacity:1},{height:`0px`,opacity:0,paddingTop:`0px`,paddingBottom:`0px`}],{duration:380,easing:`ease-in`,fill:`forwards`});let s=l.left+l.width/2-(n.left+n.width/2),c=l.top+l.height/2-(n.top+n.height/2),p=f++*70;i.appendChild(a),d.push(new Promise(e=>{a.animate([{transform:`translate(0,0) scale(1)`,opacity:1},{transform:`translate(${s}px,${c}px) scale(.06)`,opacity:.25}],{duration:520,delay:p,easing:`cubic-bezier(.55,-.05,.75,.35)`,fill:`both`}).onfinish=()=>{a.remove(),e()}}))}let p=()=>{n();let e=o.querySelector(`[data-done-chip]`);if(!e)return;e.classList.remove(`tick`),e.offsetWidth,e.classList.add(`tick`);let r=document.createElement(`span`);r.className=`m-plus`,r.textContent=`+${t.length}`,e.appendChild(r),setTimeout(()=>r.remove(),850)};return d.length?Promise.all(d).then(p):(p(),Promise.resolve())}function I(t){if(!t.length)return;z=!1,clearTimeout(B);for(let e of[...t].reverse())D(e);t.forEach((e,t)=>{u.set(e,t===0?`processing`:`queued`),d.delete(e)}),N(),s&&F();let n=[],r=0;e.onProcess(t,(e,i)=>{u.set(e,i?`done`:`failed`),D(e),i&&n.push(e),r++,r>=t.length&&n.length&&setTimeout(()=>void fe([...n]),700);let a=t.find(e=>u.get(e)===`queued`);a&&(u.set(a,`processing`),D(a)),N(),s&&F()})}function L(){s=!0,!c.length&&x.length&&(T=`done`),o.classList.remove(`closing`),o.classList.add(`open`),F()}function R(){let e=s;s=!1,o.classList.remove(`open`),e&&o.classList.add(`closing`)}o.addEventListener(`animationend`,e=>{e.animationName===`cardout`&&o.classList.remove(`closing`)});let z=!1,pe=!1,me=r.autoExpand!==!1,B;function V(){pe=!0,z=!1,clearTimeout(B),R()}function ge(){clearTimeout(B),B=setTimeout(()=>{z&&s&&j().running===0&&(z=!1,R())},6e3)}o.addEventListener(`pointerenter`,()=>clearTimeout(B)),o.addEventListener(`pointerleave`,()=>{z&&s&&j().running===0&&ge()}),a.addEventListener(`click`,()=>{s?V():(pe=!1,z=!1,clearTimeout(B),L())}),i.addEventListener(`keydown`,e=>{e.key===`Escape`&&V()}),N();try{localStorage.getItem(`xss_onboarded`)||(localStorage.setItem(`xss_onboarded`,`1`),L(),setTimeout(()=>{c.length||R()},6e3))}catch{}return{el:i,update(e){let t=new Set(e.map(k)),n=c.filter(e=>{let n=k(e);return!t.has(n)&&y.has(n)&&!S.has(n)&&u.has(n)}),r=[...e,...n],o=r.length>c.length;o&&(T=`queue`);for(let e of r){let t=k(e);E.has(t)||D(t)}c=r;let l=new Set([...r.map(k),...S]);for(let e of[...u.keys()])l.has(e)||u.delete(e);for(let e of[...d])l.has(e)||d.delete(e);for(let e of[...f])l.has(e)||f.delete(e);for(let e of[...p])l.has(e)||p.delete(e);for(let e of[...y])l.has(e)||y.delete(e);for(let e of[...b.keys()])l.has(e)||b.delete(e);for(let e of[...E.keys()])l.has(e)||E.delete(e);for(let e of[...m])l.has(e)||m.delete(e);for(let e of[...g])l.has(e)||g.delete(e);for(let[e,t]of[...h])l.has(e)||(clearTimeout(t),h.delete(e));i.style.display=``,N(),s&&F(),o&&(a.classList.remove(`hit-pulse`),a.offsetWidth,a.classList.add(`hit-pulse`),setTimeout(()=>a.classList.remove(`hit-pulse`),950))},setScanning(e){l=Math.max(0,e),s||N()},pageReset(){let e=new Set,t=[];for(let n of c){let r=k(n),i=u.get(r);(i===`done`||i===`failed`)&&!S.has(r)?(S.add(r),x.push(n)):y.has(r)&&(i===`queued`||i===`processing`)&&(e.add(r),t.push(n))}c=t;let n=t=>S.has(t)||e.has(t);for(let e of[...u.keys()])n(e)||u.delete(e);for(let e of[...y])n(e)||y.delete(e);for(let e of[...b.keys()])n(e)||b.delete(e);for(let e of[...f])n(e)||f.delete(e);for(let e of[...p])n(e)||p.delete(e);for(let e of[...E.keys()])n(e)||E.delete(e);d.clear(),T=`queue`,O=0;for(let e of h.values())clearTimeout(e);h.clear(),m.clear(),g.clear(),_.length=0,pe=!1,s&&t.length?(clearTimeout(B),F()):(z=!1,clearTimeout(B),R()),N()},markAuto(e,t,n){y.add(e),n&&b.set(e,n),u.set(e,t),D(e),clearTimeout(B),(t===`queued`||t===`processing`)&&me&&!s&&!pe&&(z=!0,s=!0,o.classList.add(`open`)),N(),s&&F(),t===`done`&&le(e),z&&s&&j().running===0&&ge()},markManual(e,t){c.some(t=>k(t)===e)&&(b.set(e,t),u.set(e,`done`),y.add(e),D(e),N(),s&&F(),le(e))},setAutoProcess(e,t,n){C=e,t!==void 0&&(w=t),n!==void 0&&(ee=n),s&&F()},setVerb(e){n=e,N(),s&&F()},setAutoExpand(e){me=e}}}function Bt(e,t=!1){let n=document.createElement(`span`);return n.className=`xss-badge ${t?`actqueued`:`acting`}`,n.setAttribute(`aria-label`,t?`等待自动${e}`:`自动${e}中`),n.innerHTML=`<span class="xss-ico">${Y(`shield-x`,`currentColor`,12)}</span><span>${t?`待${q(e)}`:`${q(e)}中`}</span>`,n}function Vt(){let e=document.createElement(`span`);return e.className=`xss-badge analyzing`,e.setAttribute(`aria-label`,`在线 AI 检测中`),e.innerHTML=`<span class="xss-spin">${Y(`shield`,`currentColor`,12)}</span><span>检测中</span>`,e}var Ht=[{mode:`local`,verb:`隐藏`},{mode:`mute`,verb:`静音`},{mode:`block`,verb:`拉黑`}],Ut=null;function Wt(){if(Ut?.host.isConnected)return Ut;let e=document.createElement(`div`);e.setAttribute(`data-xss-overlay`,``),e.setAttribute(`data-xss-theme`,J()),e.style.cssText=`position:fixed;left:0;top:0;width:0;height:0;z-index:2147483001;`,document.documentElement.appendChild(e),Ut=e.attachShadow({mode:`open`});let t=document.createElement(`style`);return t.textContent=Mt,Ut.appendChild(t),Ut}var Gt=null;function Kt(){Gt?.(),Gt=null}function qt(e,t,n,r=`fresh`,i=`local`){let a=document.createElement(`span`);a.tabIndex=0;let o=!!e&&(e.label===`spam`||e.label===`porn_bot`||e.label===`likely_spam`),s=e?o?`var(--danger)`:`var(${Rt[e.label].varName})`:`var(--muted)`;if(t.whitelisted)a.className=`xss-badge ghost wl`,a.setAttribute(`aria-label`,`MXGA：本地白名单 · 不检测、不处理`),a.innerHTML=`${Y(`shield`,`currentColor`,13)}<span>白名单</span>`;else if(!e&&t.clean)a.className=`xss-badge ghost ok`,a.setAttribute(`aria-label`,`MXGA：AI 已检 · 干净（悬停可手动处理）`),a.innerHTML=`${Y(`shield-check`,`currentColor`,13)}<span>已检</span>`;else if(!e)a.className=`xss-badge ghost`,a.setAttribute(`aria-label`,`MXGA：未命中名单 · 悬停可手动处理`),a.innerHTML=`${Y(`shield`,`currentColor`,13)}<span>检查</span>`;else{let t=Rt[e.label],n=r===`list`||r===`cache`||r===`rule`;a.className=`xss-badge ${n?`known`:`fresh`}`,a.style.setProperty(`--badge-color`,s);let i=r===`list`?`命中公共名单`:r===`rule`?`命中官方关键词规则（本机比对）`:r===`cache`?`本地缓存命中`:`在线 AI 检测结果`;a.setAttribute(`aria-label`,`${t.zh} ${(e.confidence*100).toFixed(0)}% · ${i}`);let o=n?``:`<span class="ntag">首发</span>`;a.innerHTML=`${Y(t.ic,`currentColor`,12)}<span>${Lt[e.label]}</span>${o}`}let c=null,l,u=0,d=()=>{clearTimeout(l),cancelAnimationFrame(u),c?.remove(),c=null,Gt===d&&(Gt=null),window.removeEventListener(`scroll`,f,!0),document.removeEventListener(`pointerdown`,p,!0)},f=()=>{d()},p=e=>{if(!c)return;let t=e.composedPath();t.includes(a)||t.includes(c)||m(!0)},m=(e=!1)=>{if(!e&&c?.matches(`:hover`)){h();return}d()},h=()=>{clearTimeout(l),l=setTimeout(m,120)},g=()=>clearTimeout(l),_=()=>{if(g(),c)return;c=document.createElement(`div`),c.className=`xss pop card`,c.setAttribute(`data-xss-theme`,J()),c.style.display=`block`;let m=Ht.map(e=>`<button data-act="${e.mode}"${e.mode===i?` data-b`:``}>${q(e.verb)}</button>`).join(``),_=t.onReport&&r!==`list`&&r!==`rule`?`<button data-report title="举报给公共名单人工审核（需 GitHub 授权）">举报为spam</button>`:``,v=t.onWhitelist?t.whitelisted?`<button data-wl title="移出本地白名单后，该账号重新参与检测">移出白名单</button>`:`<button data-wl title="加入本地白名单：永不标记、永不自动处理（仅本机，不上传）">加入白名单</button>`:``;c.innerHTML=t.whitelisted?`
      <h4 style="color:var(--safe)">本地白名单</h4>
      <div style="color:var(--muted);line-height:1.55">
        该账号在你的本地白名单中：不检测、不标记、不自动处理，即使公共名单或规则命中。</div>
      <div class="acts">${v}</div>`:e?`
      <h4 style="color:${s}">${Rt[e.label].zh} · ${(e.confidence*100).toFixed(0)}%</h4>
      <ul>${e.reasons.map(e=>`<li>${q(e)}</li>`).join(``)}</ul>
      ${n?`<div style="color:var(--muted)">${q(n)}</div>`:``}
      <div class="acts">
        ${o?m:``}
        ${_}
        ${v}
        <button data-a title="打开 GitHub 提交误判申诉 issue（已预填账号信息）">误判申诉</button>
      </div>
      <div class="pop-status" data-report-status hidden></div>`:`
      <h4>手动处理</h4>
      <div style="color:var(--muted);line-height:1.55">
        未命中公共名单与官方规则。确认是垃圾/骚扰账号时，可手动处理（5 秒内可撤销），或举报给公共名单。</div>
      <div class="acts">${m}${_}${v}</div>
      <div class="pop-status" data-report-status hidden></div>`;for(let e of c.querySelectorAll(`[data-act]`))e.addEventListener(`click`,()=>t.onAct(e.dataset.act));c.querySelector(`[data-a]`)?.addEventListener(`click`,t.onAppeal);let y=c.querySelector(`[data-wl]`);if(y&&t.onWhitelist){let e=t.onWhitelist;y.addEventListener(`click`,()=>void e())}let b=c.querySelector(`[data-report]`);if(b&&t.onReport){let e=t.onReport,n=async t=>{let n=c?.querySelector(`[data-report-status]`);c?.querySelector(`[data-report-cats]`)?.remove(),b.hidden=!1,b.disabled=!0,b.textContent=`举报中…`,Ft(n,`正在提交举报（${lt[t]}）…`,`info`);let r;try{r=await e(t)}catch{r={ok:!1,message:`举报失败，请稍后重试`}}c&&(Ft(n,r.message,r.ok?`ok`:`err`),b.textContent=r.ok?`已举报`:`举报为spam`,b.disabled=r.ok,clearTimeout(l),l=setTimeout(d,r.ok?2600:3600))};b.addEventListener(`click`,e=>{if(e.stopPropagation(),g(),c?.querySelector(`[data-report-cats]`))return;let t=document.createElement(`div`);t.className=`rep-cats`,t.setAttribute(`data-report-cats`,``),t.innerHTML=`<span class="rep-cats-label">这是哪类垃圾？</span>${ot.map(e=>`<button type="button" data-cat="${e}">${q(lt[e])}</button>`).join(``)}`;for(let e of t.querySelectorAll(`[data-cat]`))e.addEventListener(`click`,t=>{t.stopPropagation(),n(e.dataset.cat)});b.hidden=!0,b.insertAdjacentElement(`afterend`,t),Ft(c?.querySelector(`[data-report-status]`),`选择类型后提交；不属于这些类型的争吵/观点不在治理范围`,`info`)})}for(let e of c.querySelectorAll(`button:not([data-report])`))e.addEventListener(`click`,d);c.addEventListener(`mouseenter`,g),c.addEventListener(`mouseleave`,h),Gt?.(),Gt=d,Wt().appendChild(c);let x=e=>{if(!c)return;let t=c.offsetWidth||260,n=c.offsetHeight||120,r=Math.min(Math.max(8,e.left),window.innerWidth-t-8),i=e.bottom+6,a=i+n>window.innerHeight-8?Math.max(8,e.top-n-6):i;c.style.left=`${r}px`,c.style.top=`${a}px`};x(a.getBoundingClientRect());let S=()=>{if(!c)return;let e=a.getBoundingClientRect();if(!a.isConnected||!e.width&&!e.height){d();return}x(e),u=requestAnimationFrame(S)};u=requestAnimationFrame(S),window.addEventListener(`scroll`,f,{capture:!0,passive:!0}),document.addEventListener(`pointerdown`,p,!0)},v=!1;return a.addEventListener(`pointerdown`,e=>{v=e.pointerType!==`mouse`}),a.addEventListener(`click`,e=>{v&&=(e.preventDefault(),e.stopPropagation(),c?m(!0):_(),!1)}),a.addEventListener(`pointerenter`,e=>{e.pointerType===`mouse`&&_()}),a.addEventListener(`focus`,()=>{v||_()}),a.addEventListener(`mouseleave`,h),a.addEventListener(`blur`,h),a}var Jt=`
:host { all: initial; }
* { box-sizing: border-box; font-family: system-ui,-apple-system,"Segoe UI",sans-serif; }
:host {
  --surface: rgba(13,17,23,.94); --border: rgba(255,255,255,.10);
  --shadow: 0 8px 28px rgba(0,0,0,.45); --text: #E6EDF3; --muted: #8B949E;
  --brand: #0EA5E9; --danger: #EF4444; --warn: #F59E0B; --safe: #16A34A;
}
@media (prefers-color-scheme: light) {
  :host {
    --surface: rgba(255,255,255,.97); --border: rgba(15,23,42,.12);
    --shadow: 0 8px 28px rgba(15,23,42,.18); --text: #0F172A; --muted: #475569;
    --brand: #0369A1; --danger: #DC2626; --warn: #B45309; --safe: #15803D;
  }
}
:host([data-xss-theme="dark"]) {
  --surface: rgba(13,17,23,.94); --border: rgba(255,255,255,.10);
  --shadow: 0 8px 28px rgba(0,0,0,.45); --text: #E6EDF3; --muted: #8B949E;
  --brand: #0EA5E9; --danger: #EF4444; --warn: #F59E0B; --safe: #16A34A;
}
:host([data-xss-theme="light"]) {
  --surface: rgba(255,255,255,.97); --border: rgba(15,23,42,.12);
  --shadow: 0 8px 28px rgba(15,23,42,.18); --text: #0F172A; --muted: #475569;
  --brand: #0369A1; --danger: #DC2626; --warn: #B45309; --safe: #15803D;
}
.kolpop {
  position: fixed; z-index: 2147483001; width: 300px;
  background: var(--surface); border: 1px solid var(--border);
  border-left: 3px solid var(--accent, var(--muted));
  border-radius: 12px; box-shadow: var(--shadow);
  color: var(--text); -webkit-font-smoothing: antialiased;
  padding: 10px 12px; font-size: 12.5px; line-height: 1.45;
}
.kol-head { display: flex; align-items: center; gap: 6px; margin-bottom: 8px; }
.kol-name { font-weight: 600; font-size: 13.5px; min-width: 0;
  overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.kol-name .h { color: var(--muted); font-weight: 400; }
.kol-flag { flex: none; font-size: 10.5px; padding: 1px 6px; border-radius: 999px;
  border: 1px solid currentColor; }
.kol-flag.wl { color: var(--safe); }
.kol-grid { display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 6px 10px; }
.kv { min-width: 0; }
.kv .k { display: block; color: var(--muted); font-size: 11px; }
.kv b { font-size: 13px; font-variant-numeric: tabular-nums; }
.kv .s { display: block; color: var(--muted); font-size: 10.5px; }
.kv .na { color: var(--muted); font-weight: 400; }
.kol-rows { margin-top: 8px; }
.kol-row { display: flex; justify-content: space-between; gap: 8px; padding: 2px 0; }
.kol-row .k { color: var(--muted); }
.kol-foot { margin-top: 8px; padding-top: 6px; border-top: 1px solid var(--border);
  color: var(--muted); font-size: 10.5px; display: flex; justify-content: space-between; }
.kol-foot a { color: var(--brand); text-decoration: none; }
`;function Yt(e){return e.replace(/&/g,`&amp;`).replace(/</g,`&lt;`).replace(/>/g,`&gt;`).replace(/"/g,`&quot;`)}function Xt(){let e=(document.documentElement.lang||``).toLowerCase();return e.startsWith(`zh`)?`zh`:e.startsWith(`ja`)?`ja`:`en`}var Zt={zh:{age:`账号年龄`,followers:`粉丝`,following:`关注`,posts:`推文`,likeRatio:`赞粉比`,perPost:`均赞/推`,trust:`综合可信`,original:`原创比`,focus:`主题集中度`,whitelist:`白名单`,registered:`注册`,viewProfile:`查看主页 ↗`,median:`互动中位数`,likes:`赞`,rts:`转`,replies:`评`,preciseN:e=>`（精确 ${e} 条）`,tiers:{safe:`靠谱`,ok:`一般`,warn:`存疑`,risk:`高风险`},parts:{age:`年龄`,network:`关注网`,engagement:`互动`,original:`原创`},footer:`档案实时`,sampledN:e=>` + 采样${e}条`,offline:`不联网`,coldStart:(e,t)=>`采样不足 ${e}/${t} 条 · 浏览中累积`,sampled:e=>`（采样 ${e} 条）`},en:{age:`Age`,followers:`Followers`,following:`Following`,posts:`Posts`,likeRatio:`Likes/Fol.`,perPost:`Likes/Post`,trust:`Trust`,original:`Original`,focus:`Topic focus`,whitelist:`Whitelist`,registered:`joined`,viewProfile:`View profile ↗`,median:`Median engagement`,likes:`L`,rts:`RT`,replies:`R`,preciseN:e=>` (${e} precise)`,tiers:{safe:`solid`,ok:`mixed`,warn:`shaky`,risk:`risky`},parts:{age:`age`,network:`graph`,engagement:`engage`,original:`orig.`},footer:`live profile`,sampledN:e=>` + ${e} sampled`,offline:`offline`,coldStart:(e,t)=>`only ${e}/${t} sampled · builds as you browse`,sampled:e=>` (${e} sampled)`},ja:{age:`アカウント年齢`,followers:`フォロワー`,following:`フォロー中`,posts:`投稿`,likeRatio:`いいね/フォロ`,perPost:`いいね/投稿`,trust:`総合信頼`,original:`オリジナル率`,focus:`話題集中度`,whitelist:`ホワイトリスト`,registered:`登録`,viewProfile:`プロフィール ↗`,median:`反応中央値`,likes:`いいね`,rts:`RT`,replies:`返信`,preciseN:e=>`（${e}件精確）`,tiers:{safe:`信頼`,ok:`普通`,warn:`要注意`,risk:`リスク`},parts:{age:`年齢`,network:`関係`,engagement:`反応`,original:`オリ`},footer:`プロフ即時`,sampledN:e=>` + ${e}サンプル`,offline:`通信なし`,coldStart:(e,t)=>`サンプル不足 ${e}/${t} · 閲覧中に蓄積`,sampled:e=>`（${e}件サンプル）`}};function Qt(e,t){if(typeof e!=`number`||!Number.isFinite(e)||e<0)return null;let n=e=>e.replace(/\.0$/,``);return t===`en`?e>=1e6?`${n((e/1e6).toFixed(1))}M`:e>=1e3?`${n((e/1e3).toFixed(1))}K`:e.toLocaleString(`en-US`):e>=1e8?`${n((e/1e8).toFixed(1))}亿`:e>=1e4?`${n((e/1e4).toFixed(1))}万`:e.toLocaleString(`zh-CN`)}function $t(e,t){if(typeof e!=`number`||!Number.isFinite(e)||e<0)return null;let n;return n=t===`en`?e<60?`${e}d`:e<365?`${Math.round(e/30)}mo`:`${(e/365).toFixed(1).replace(/\.0$/,``)}y`:t===`ja`?e<60?`${e} 日`:e<365?`${Math.round(e/30)} ヶ月`:`${(e/365).toFixed(1).replace(/\.0$/,``)} 年`:e<60?`${e} 天`:e<365?`${Math.round(e/30)} 个月`:`${(e/365).toFixed(1).replace(/\.0$/,``)} 年`,{main:n,since:null}}function en(e,t=2){return typeof e!=`number`||!Number.isFinite(e)||e<0?null:e.toFixed(t)}var tn=null,nn=null,X=null,rn,an=0,on=null;function sn(){if(nn?.host.isConnected)return nn;tn=document.createElement(`div`),tn.setAttribute(`data-xss-kol`,``),tn.setAttribute(`data-xss-theme`,J()),tn.style.cssText=`position:fixed;left:0;top:0;width:0;height:0;z-index:2147483001;`,document.documentElement.appendChild(tn),nn=tn.attachShadow({mode:`open`});let e=document.createElement(`style`);return e.textContent=Jt,nn.appendChild(e),nn}function cn(){clearTimeout(rn),cancelAnimationFrame(an),X?.remove(),X=null,on=null,window.removeEventListener(`scroll`,ln,!0),document.removeEventListener(`pointerdown`,un,!0)}function ln(){cn()}function un(e){if(!X)return;let t=e.composedPath();on&&t.includes(on)||t.includes(X)||dn(!0)}function dn(e=!1){if(!e&&X?.matches(`:hover`)){fn();return}cn()}function fn(){clearTimeout(rn),rn=setTimeout(()=>dn(),120)}function pn(e){let t=Xt(),n=Zt[t],r=e.displayName?.trim(),i=$t(e.accountAgeDays,t),a=e.accountCreatedAt&&!Number.isNaN(Date.parse(e.accountCreatedAt))?(()=>{let t=new Date(e.accountCreatedAt);return`${t.getFullYear()}.${String(t.getMonth()+1).padStart(2,`0`)} ${n.registered}`})():null,o=Qt(e.followersCount,t),s=Qt(e.followingCount,t),c=Qt(e.statusesCount,t),l=typeof e.favouritesCount==`number`&&typeof e.followersCount==`number`&&e.followersCount>0?en(e.favouritesCount/e.followersCount):null,u=typeof e.favouritesCount==`number`&&typeof e.statusesCount==`number`&&e.statusesCount>0?en(e.favouritesCount/e.statusesCount,1):null,d=(e,t,n)=>`<div class="kv"><span class="k">${e}</span>${t?`<b>${t}</b>`:`<b class="na">—</b>`}${n?`<span class="s">${n}</span>`:``}</div>`,f={safe:`var(--safe)`,ok:`var(--brand)`,warn:`var(--warn)`,risk:`var(--danger)`},p=e.trust?[[n.parts.age,e.trust.parts.age],[n.parts.network,e.trust.parts.network],[n.parts.engagement,e.trust.parts.engagement],[n.parts.original,e.trust.parts.original]].map(([e,t])=>`${e} ${t}`).join(` · `):``,m=[e.trust?`<div class="kol-row"><span class="k">${n.trust}</span><span style="color:${f[e.trust.tier]}"><b>${e.trust.score}</b>/100 · ${n.tiers[e.trust.tier]}</span></div>${p?`<div class="kol-row"><span class="k"></span><span class="k" style="font-size:10.5px">${p}</span></div>`:``}`:``,e.precise?`<div class="kol-row"><span class="k">${n.median}</span><span>${n.likes} ${e.precise.medianLikes} · ${n.rts} ${e.precise.medianRts} · ${n.replies} ${e.precise.medianReplies}<span class="k">${n.preciseN(e.precise.tweets)}</span></span></div>`:``,typeof e.originalRatio==`number`?`<div class="kol-row"><span class="k">${n.original}</span><span>${(e.originalRatio*100).toFixed(0)}%<span class="k">${e.precise?n.preciseN(e.precise.tweets):n.sampled(e.sampledTweets??0)}</span></span></div>`:``,typeof e.topicFocus==`number`?`<div class="kol-row"><span class="k">${n.focus}</span><span>${(e.topicFocus*100).toFixed(0)}%</span></div>`:``,typeof e.originalRatio!=`number`&&typeof e.sampledTweets==`number`?`<div class="kol-row"><span class="k">${n.original} · ${n.focus}</span><span class="k">${n.coldStart(e.sampledTweets,5)}</span></div>`:``].filter(Boolean).join(``);return`
  <div class="kol-head">
    <span class="kol-name">${Yt(r||`@${e.handle}`)} <span class="h">@${Yt(e.handle)}</span>${e.verified?` ✓`:``}</span>
    ${e.whitelisted?`<span class="kol-flag wl">${n.whitelist}</span>`:``}
  </div>
  <div class="kol-grid">
    ${d(n.age,i?i.main:null,i?a:null)}
    ${d(n.followers,o)}
    ${d(n.following,s)}
    ${d(n.posts,c)}
    ${d(n.likeRatio,l)}
    ${d(n.perPost,u)}
  </div>
  ${m?`<div class="kol-rows">${m}</div>`:``}
  <div class="kol-foot"><span>filtrationX · ${n.footer}${typeof e.sampledTweets==`number`?n.sampledN(e.sampledTweets):``} · ${n.offline}</span><a href="https://x.com/${encodeURIComponent(e.handle)}" target="_blank" rel="noopener">${n.viewProfile}</a></div>`}function mn(e,t){Kt();let n=sn();X||(X=document.createElement(`div`),X.className=`kolpop`,X.setAttribute(`data-xss-theme`,J()),X.addEventListener(`mouseenter`,()=>clearTimeout(rn)),X.addEventListener(`mouseleave`,fn),n.appendChild(X)),X.style.setProperty(`--accent`,t.whitelisted?`var(--safe)`:t.trust?{safe:`var(--safe)`,ok:`var(--brand)`,warn:`var(--warn)`,risk:`var(--danger)`}[t.trust.tier]:(t.accountAgeDays??1/0)<30?`var(--warn)`:`var(--brand)`),X.innerHTML=pn(t),on=e;let r=e=>{if(!X)return;let t=X.offsetWidth||300,n=X.offsetHeight||140,r=e.right+8;r+t>window.innerWidth-8&&(r=e.left-t-8),r<8&&(r=Math.min(Math.max(8,e.left),window.innerWidth-t-8));let i=e.top;i+n>window.innerHeight-8&&(i=Math.max(8,e.top+e.height-n)),X.style.left=`${Math.max(8,r)}px`,X.style.top=`${Math.max(8,i)}px`};r(e.getBoundingClientRect()),cancelAnimationFrame(an);let i=()=>{if(!X||!on)return;let e=on.getBoundingClientRect();if(!on.isConnected||!e.width&&!e.height){cn();return}r(e),an=requestAnimationFrame(i)};an=requestAnimationFrame(i),window.addEventListener(`scroll`,ln,{capture:!0,passive:!0}),document.addEventListener(`pointerdown`,un,!0)}function hn(e=!1){dn(e)}function gn(){return!!X}function _n(){fn()}var vn=class{minIntervalMs;cooldownMs;lastStart=0;coolingUntil=0;chain=Promise.resolve();constructor(e=400,t=6e5){this.minIntervalMs=e,this.cooldownMs=t}get cooling(){return Date.now()<this.coolingUntil}get waitMs(){return this.cooling?this.coolingUntil-Date.now():Math.max(0,this.lastStart+this.minIntervalMs-Date.now())}run(e){let t=this.chain.then(()=>this.gate()).then(e).catch(e=>{throw(e instanceof yn?e.status:e?.status)===429&&(this.coolingUntil=Date.now()+this.cooldownMs),e});return this.chain=t.catch(()=>void 0),t}cooldownNow(){this.coolingUntil=Date.now()+this.cooldownMs}async gate(){if(this.cooling){let e=Error(`rate_limited`);throw e.status=429,e}let e=this.waitMs;e>0&&await new Promise(t=>setTimeout(t,e)),this.lastStart=Date.now()}},yn=class extends Error{status;constructor(e,t){super(t),this.status=e,this.name=`HttpError`}},bn=c({X_PUBLIC_BEARER:()=>Vn,performXAction:()=>Rn,retryDelayForAttempt:()=>zn});function xn(e){try{let t=e?.message;return typeof t==`string`&&t?t:String(e)}catch{return`unknown error`}}function Sn(){try{return document.cookie.match(/ct0=([^;]+)/)?.[1]??``}catch{return``}}function Cn(){return location.hostname.endsWith(`twitter.com`)?`https://twitter.com`:`https://x.com`}function wn(e){return String(e??``).trim().replace(/^@+/,``)}function Tn(e){try{return Number(localStorage.getItem(e)||0)||0}catch{return 0}}function En(e,t){try{localStorage.setItem(e,String(Math.max(0,Math.floor(t))))}catch{}}function Dn(){try{let e=JSON.parse(localStorage.getItem(Qn)||`{}`);return{count:Math.max(0,Number(e.count||0)||0),cooldownUntil:Math.max(0,Number(e.cooldownUntil||0)||0)}}catch{return{count:0,cooldownUntil:0}}}function On(e){try{localStorage.setItem(Qn,JSON.stringify({count:Math.max(0,Number(e.count||0)||0),cooldownUntil:Math.max(0,Number(e.cooldownUntil||0)||0)}))}catch{}}function kn(e){return e>0&&e%qn===0?Jn:e>0&&e%Gn===0?Kn:0}function An(e){if(!e)return;let t=Number(e);if(Number.isFinite(t))return Math.max(0,t*1e3);let n=Date.parse(e);return Number.isFinite(n)?Math.max(0,n-Date.now()):void 0}function jn(e){if(e<=0)return;let t=Dn();On({...t,cooldownUntil:Math.max(t.cooldownUntil,Date.now()+e)})}function Mn(e){e.status===429?jn(e.retryAfterMs??Yn):e.retryable&&jn(Xn)}function Nn(){let e=Dn().count+1,t=kn(e);On({count:e,cooldownUntil:t?Date.now()+t:0})}async function Pn(){for(;;){let e=Dn().cooldownUntil-Date.now();if(e>0){await $n(Math.min(1e3,e));continue}let t=Tn(Zn),n=Math.floor(Math.random()*Wn),r=t+Un+n-Date.now();if(r<=0)break;await $n(Math.min(1e3,r))}En(Zn,Date.now())}async function Fn(e){let t=er.then(e,e);return er=t.catch(()=>{}),t}function In(e,t,n,r){return new Promise((i,a)=>{let o;try{o=new XMLHttpRequest}catch(e){a(e);return}try{o.open(`POST`,e,!0),o.withCredentials=!0,o.timeout=r;for(let[e,n]of Object.entries(t))o.setRequestHeader(e,n);o.onload=()=>i({status:o.status,header:e=>{try{return o.getResponseHeader(e)}catch{return null}}}),o.onerror=()=>a(Error(`网络错误`)),o.ontimeout=()=>a(Error(`请求超时（${r}ms）`)),o.onabort=()=>a(Error(`请求被中止`)),o.send(n)}catch(e){a(e)}})}async function Ln(e,t,n){try{let r=Sn();if(!r)return{ok:!1,retryable:!1,reason:`未取到 ct0（未登录 X，或浏览器阻止了 content script 读取 cookie）`};let i=wn(n),a=new URLSearchParams;if(t&&/^\d+$/.test(t))a.set(`user_id`,t);else if(i)a.set(`screen_name`,i);else return{ok:!1,retryable:!1,reason:`既无合法 user_id 也无 screen_name，无法定位账号`};let o;try{o=await In(`${Cn()}${Hn[e]}`,{authorization:Bn,"x-csrf-token":r,"x-twitter-auth-type":`OAuth2Session`,"x-twitter-active-user":`yes`,"content-type":`application/x-www-form-urlencoded`},a.toString(),15e3)}catch(e){return{ok:!1,retryable:!0,reason:`请求异常：${xn(e)}`}}let s=o.status,c=s>=200&&s<300,l=s===408||s===425||s===429||s>=500;return{ok:c,status:s,retryAfterMs:An(o.header(`retry-after`)),retryable:l,reason:c?void 0:`X 返回 HTTP ${s}`}}catch(e){return{ok:!1,retryable:!0,reason:`请求异常：${xn(e)}`}}}async function Rn(e,t,n,r=()=>!0){return Fn(async()=>{if(!r()||(await Pn(),!r()))return{ok:!1,retryable:!1};let i=await Ln(e,t,n);return i.ok?Nn():Mn(i),i})}function zn(e,t){return e.retryable?e.status===429?Math.min(6e4,e.retryAfterMs??Yn):Math.min(12e3,900*2**Math.max(0,t-1)):0}var Bn,Vn,Hn,Un,Wn,Gn,Kn,qn,Jn,Yn,Xn,Zn,Qn,$n,er,tr=o((()=>{Bn=`Bearer AAAAAAAAAAAAAAAAAAAAANRILgAAAAAAnNwIzUejRCOuH5E6I8xnZz4puTs%3D1Zv7ttfk8LF81IUq16cHjhLTvJu4FA33AGWWjCpTnA`,Vn=Bn,Hn={block:`/i/api/1.1/blocks/create.json`,mute:`/i/api/1.1/mutes/users/create.json`,unblock:`/i/api/1.1/blocks/destroy.json`},Un=1200,Wn=700,Gn=45,Kn=8e3,qn=120,Jn=6e4,Yn=45e3,Xn=8e3,Zn=`mxga:last-x-action`,Qn=`mxga:x-action-round`,$n=e=>new Promise(t=>setTimeout(t,e)),er=Promise.resolve()}));tr();var nr=`xss:kol:gql:v1`,rr=3*864e5,ir=`V7H0Ap8H4_kVPHuPHslKQg`,ar={rweb_tipjar_consumption_enabled:!0,responsive_web_graphql_exclude_directive_enabled:!0,verified_phone_label_enabled:!1,creator_subscriptions_tweet_preview_api_enabled:!0,responsive_web_graphql_timeline_navigation_enabled:!0,responsive_web_graphql_skip_user_profile_image_extensions_enabled:!1,communities_web_enable_tweet_community_results_fetch:!0,c9s_tweet_anatomy_moderator_badge_enabled:!0,articles_preview_enabled:!0,tweetypie_unmention_optimization_enabled:!0,responsive_web_edit_tweet_api_enabled:!0,graphql_is_translatable_rweb_tweet_is_translatable_enabled:!0,view_counts_everywhere_api_enabled:!0,longform_notetweets_consumption_enabled:!0,responsive_web_twitter_article_tweet_consumption_enabled:!0,longform_notetweets_rich_text_read_enabled:!0,longform_notetweets_inline_media_enabled:!0,profile_label_improvements_pcf_label_in_post_enabled:!1,rweb_video_timestamps_enabled:!0,freedom_of_speech_not_reach_fetch_enabled:!0,standardized_nudges_misinfo:!0,tweet_with_visibility_results_prefer_gql_limited_actions_policy_enabled:!0,rweb_video_screen_enabled:!1},or=new vn(400,6e5);function sr(e){let t=[],n=e=>{let n=(e&&e.__typename===`TweetWithVisibilityResults`?e.tweet:e)?.legacy;n&&t.push({likes:typeof n.favorite_count==`number`?n.favorite_count:0,replies:typeof n.reply_count==`number`?n.reply_count:0,rts:typeof n.retweet_count==`number`?n.retweet_count:0,isRetweet:!!n.retweeted_status_result})};try{let r=e?.data?.user?.result,i=r?.timeline_v2?.timeline?.instructions??r?.timeline?.timeline?.instructions;if(!Array.isArray(i))return t;for(let e of i)if(e?.type===`TimelineAddEntries`)for(let t of e.entries??[]){let e=typeof t?.entryId==`string`?t.entryId:``;if(e.startsWith(`tweet-`))n(t?.content?.itemContent?.tweet_results?.result);else if(e.startsWith(`profile-conversation-`))for(let e of t?.content?.items??[])n(e?.item?.itemContent?.tweet_results?.result)}}catch{}return t}function cr(e){if(!e.length)return 0;let t=Math.floor(e.length/2);return e.length%2?e[t]??0:Math.round(((e[t-1]??0)+(e[t]??0))/2)}function lr(e){if(!e.length)return null;let t=e=>cr([...e].sort((e,t)=>e-t)),n=e.filter(e=>!e.isRetweet).length;return{tweets:e.length,medianLikes:t(e.map(e=>e.likes)),medianReplies:t(e.map(e=>e.replies)),medianRts:t(e.map(e=>e.rts)),originalRatio:n/e.length,ts:Date.now()}}var ur=e=>`${nr}:${e}`;async function dr(e){if(!e)return null;try{let t=ur(e),n=(await chrome.storage.local.get(t))[t];if(!n)return null;if(Date.now()-n.ts>rr)return chrome.storage.local.remove(t),null;let{userId:r,handle:i,...a}=n;return a}catch{return null}}async function fr(e,t,n){try{await chrome.storage.local.set({[ur(e)]:{...n,userId:e,handle:t}})}catch{}}var pr=!1;async function mr(e,t){if(pr)return{ok:!1,error:`unsupported`};let n=document.cookie.match(/(?:^|;\s*)ct0=([^;]+)/)?.[1]??``;if(!n)return{ok:!1,error:`no_ct0`};if(or.cooling)return{ok:!1,error:`rate_limited`};let r=`https://x.com/i/api/graphql/${ir}/UserTweets?variables=${encodeURIComponent(JSON.stringify({userId:e,count:20,includePromotedContent:!1,withQuickPromoteEligibilityTweetFields:!1}))}&features=${encodeURIComponent(JSON.stringify(ar))}`;try{return await or.run(async()=>{let i=await fetch(r,{headers:{authorization:Vn,"x-csrf-token":n,"x-twitter-auth-type":`OAuth2Session`,"x-twitter-active-user":`yes`,accept:`application/json`},credentials:`include`});if(i.status===429)throw new yn(429,`rate limited`);if(i.status===400||i.status===404)throw pr=!0,new yn(i.status,`unsupported query`);if(!i.ok)throw new yn(i.status,`http ${i.status}`);let a=lr(sr(await i.json()));return a?(await fr(e,t,a),{ok:!0,metrics:a}):{ok:!1,error:`no_data`}})}catch(e){return e instanceof yn?{ok:!1,error:`http_${e.status}`}:{ok:!1,error:`network`}}}var hr={porn:`badge`,crypto:`badge`,gambling:`badge`,resource:`badge`,marketing:`badge`,other:`badge`},gr={enabled:!0,bubble:!0,bubblePos:`tr`,actionMode:`local`,categoryActions:{...hr},autoProcess:!0,autoScope:`replies`,autoTierMode:`full`,autoExpand:!0,edgeBase:``,officialRulesEnabled:!0,ruleTelemetry:!0,ruleHitsAutoAct:!1,kolCardEnabled:!0,kolGraphqlEnabled:!1,followingWhitelist:!0},_r=`xss:settings`,vr=_r;function yr(e){return{...gr,...e??{},categoryActions:{...hr,...e?.categoryActions??{}}}}async function br(){try{return yr((await chrome.storage.local.get(_r))[_r])}catch{return yr(void 0)}}async function xr(e,t){try{let n=await br();await chrome.storage.local.set({[_r]:{...n,[e]:t}})}catch{}}function Sr(e){let t=(t,n)=>{n===`local`&&t[_r]&&e(yr(t[_r].newValue))};return chrome.storage.onChanged.addListener(t),()=>chrome.storage.onChanged.removeListener(t)}var Cr=`xss:list:v2`,wr=`xss:whitelist:v1`;async function Tr(){try{let e=(await chrome.storage.local.get(Cr))[Cr];return e&&Array.isArray(e.entries)?e:null}catch{return null}}async function Er(){try{let e=(await chrome.storage.local.get(wr))[wr];return e&&Array.isArray(e.entries)?e:null}catch{return null}}var Dr=RegExp(`[­͏؜᠎​‌‍‎‏‪‫‬‭‮⁠⁡⁢⁣⁤⁦⁧⁨⁩﻿]`,`g`);function Or(e){return e.replace(Dr,``)}var kr=new Map;function Ar(e,t){if(!e)return-1;if(!/^[\x20-\x7f]+$/.test(e))return t.indexOf(e);let n=kr.get(e);if(!n){let t=e.replace(/[.*+?^${}()|[\]\\]/g,`\\$&`);n=RegExp(`(?<![a-z0-9_])${t}(?![a-z0-9_])`),kr.size>=512&&kr.clear(),kr.set(e,n)}return n.exec(t)?.index??-1}function jr(e,t,n){let r=0,i=0,a=-1;for(let o of e){let e=Or(o).toLowerCase().length;if(e&&a<0&&r+e>t&&(a=i),r+=e,i+=o.length,a>=0&&r>=t+n)return[a,i-a]}return[Math.max(0,a),n]}var Mr=200;function Nr(e,t,n){if(e.length<=Mr)return e;let r=Math.floor((Mr-n)/2),i=Math.max(0,t-r),a=Math.min(e.length,i+Mr);return`${i>0?`…`:``}${e.slice(i,a)}${a<e.length?`…`:``}`}var Pr={h:`handle`,d:`display_name`,b:`bio`,t:`tweet`,a:`any`},Fr=`xss:rules:custom`,Ir=`xss:rules:disabled`,Lr=200,Rr=/[㐀-鿿豈-﫿]/,zr=e=>!!e&&Rr.test(e),Br=[`handle`,`display_name`,`bio`,`tweet`,`any`],Vr=[],Hr=[],Ur=new Set,Wr=!0,Gr=!1;function Kr(e,t,n,r,i){return{pattern:e,patternLower:Or(e).toLowerCase(),patternCJK:zr(e),field:t,label:n,category:r,origin:i}}function qr(e){let t=[];if(Array.isArray(e))for(let n of e){if(!Array.isArray(n)||n.length<3)continue;let[e,r,i]=n;if(typeof e!=`string`||!e)continue;let a=Pr[String(r)];a&&t.push(Kr(e,a,String(i)[0]===`p`?`porn_bot`:`spam`,ct(String(i)[1]),`official`))}Vr=t}function Jr(e){if(!Array.isArray(e))return[];let t=[],n=new Set;for(let r of e){if(!r||typeof r!=`object`)continue;let{pattern:e,field:i,category:a}=r;if(typeof e!=`string`)continue;let o=e.trim();if(!o||o.length>Lr||!i||!Br.includes(i)||!a||!ot.includes(a))continue;let s=`${o.toLowerCase()}${i}`;if(!n.has(s)&&(n.add(s),t.push({pattern:o,field:i,category:a}),t.length>=200))break}return t}function Yr(e){Hr=Jr(e).map(e=>Kr(e.pattern,e.field,e.category===`porn`?`porn_bot`:`spam`,e.category,`custom`))}function Xr(e){Ur=new Set(Array.isArray(e)?e.filter(e=>typeof e==`string`):[])}async function Zr(){if(!Gr){Gr=!0;try{Wr=(await br()).officialRulesEnabled;let e=await chrome.storage.local.get([Fr,Ir]);Yr(e[Fr]),Xr(e[Ir])}catch{}}}try{chrome.storage.onChanged.addListener((e,t)=>{t===`local`&&(e[`xss:rules:custom`]&&Yr(e[Fr].newValue),e[`xss:rules:disabled`]&&Xr(e[Ir].newValue),e[`xss:settings`]&&(Wr=e[vr].newValue?.officialRulesEnabled!==!1))})}catch{}function Qr(e,t){if(!e.length)return null;let n=Or(t.handle).toLowerCase(),r=Or(t.displayName).toLowerCase(),i=Or(t.bio).toLowerCase(),a=[...t.recentTweets,t.triggeringComment??``],o=a.map(e=>Or(e).toLowerCase());for(let s of e){if(s.origin===`official`&&Ur.has(s.pattern))continue;let e=s.patternLower;if(!e)continue;let c=t=>s.origin===`official`?Ar(e,t):t.indexOf(e),l=!s.patternCJK||!t.tweetsTranslated,u=s.field===`any`,d,f=``,p=-1;if((u||s.field===`handle`)&&(p=c(n))>=0)d=`handle`,f=t.handle;else if((u||s.field===`display_name`)&&(p=c(r))>=0)d=`display_name`,f=t.displayName;else if((u||s.field===`bio`)&&(p=c(i))>=0)d=`bio`,f=t.bio;else if((u||s.field===`tweet`)&&l){let e=o.findIndex(e=>c(e)>=0);e>=0&&(d=`tweet`,f=a[e]??``,p=c(o[e]??``))}if(d){let[t,n]=jr(f,Math.max(0,p),e.length);return{pattern:s.pattern,label:s.label,category:s.category,origin:s.origin,field:d,matchedText:Nr(f,t,n)}}}return null}function $r(e){if(Wr){let t=Qr(Vr,e);if(t)return t}return Qr(Hr,e)}var ei={p:`porn_bot`,s:`spam`},ti=null,ni=null,ri=new Date(0).toISOString(),ii=new Set,ai=new Set,oi=!1;function si(e){let t=new Set,n=new Set;for(let[r,i]of e.entries)r&&t.add(r),i&&n.add(i.toLowerCase());ii=t,ai=n}function ci(e,t){let[n,r,i]=e,a=ei[String(i)[0]??``];if(!a)return null;let o=ct(String(i)[1]),s=String(i)[2]===`h`?`confirmed`:`auto`;return{userId:n,handle:r,verdict:{label:a,confidence:1,reasons:[`公共黑名单收录 · ${lt[o]}${s===`confirmed`?` · 人工确认`:` · 自动收录`}`]},category:o,tier:s,source:`curated`,updatedAt:t}}function li(e){let t=new Map,n=new Map;for(let r of e.entries){if(!Array.isArray(r)||r.length<3)continue;let[e,i,a]=r;ei[String(a)[0]??``]&&(e&&t.set(e,r),i&&n.set(i.toLowerCase(),r))}ti=t,ni=n,ri=new Date(e.fetchedAt).toISOString(),qr(e.rules)}try{chrome.storage.onChanged.addListener((e,t)=>{t===`local`&&(e[`xss:list:v2`]?.newValue&&li(e[Cr].newValue),e[`xss:whitelist:v1`]?.newValue&&si(e[wr].newValue))})}catch{}async function ui(){return null}async function di(){try{await chrome.runtime.sendMessage({type:`list-sync`})}catch{}}async function fi(){if(oi)return;let e=await Er();e&&si(e);let t=await Tr();if(t){li(t),oi=!0;return}let n=await ui();if(n){li(n),oi=!0,di();return}ti??=new Map,ni??=new Map,di()}function pi(e){let t=ti?.get(e);return t?ci(t,ri):null}function mi(e){let t=ni?.get(e.toLowerCase());return t?ci(t,ri):null}function hi(e,t){return!!(e&&ii.has(e)||t&&ai.has(t.toLowerCase()))}function gi(e,t){if(e&&ii.has(e)||t&&ai.has(t.toLowerCase()))return null;if(e){let t=pi(e);if(t)return t}return t?mi(t):null}async function _i(e){let t=await chrome.runtime.sendMessage({type:`local-data`,mutation:e});if(!t?.ok)throw Error(t?.error??`本地数据写入失败`);return t.data}var vi=`xss:whitelist:local`;async function yi(e){let t=await _i({kind:`whitelist`,mutation:e});return ji(Pi(t.store)),t.changed}var bi=e=>yi({action:`add`,input:e}),xi=e=>yi({action:`remove`,handle:e}),Si=5e3,Ci=/^[A-Za-z0-9_]{1,15}$/,wi=/^\d{1,32}$/,Ti=/^https:\/\/pbs\.twimg\.com\/[^\s"'<>]{1,300}$/;function Ei(e){if(typeof e!=`string`)return null;let t=e.trim().replace(/^@+/,``);return Ci.test(t)?t:null}var Di=new Map,Oi=new Set,ki=new Set,Ai=null;function ji(e){let t=new Map,n=new Set;for(let r of e.entries)r?.handle&&t.set(r.handle.toLowerCase(),r.userId),r?.userId&&n.add(r.userId);Di=t,Oi=n,ki=new Set(e.excluded)}function Mi(e){if(!Array.isArray(e))return[];let t=[],n=new Set;for(let r of e){let e=Ei(r?.handle);if(!e)continue;let i=e.toLowerCase();if(!n.has(i)&&(n.add(i),t.push({handle:e,...typeof r.userId==`string`&&wi.test(r.userId)?{userId:r.userId}:{},...typeof r.displayName==`string`&&r.displayName?{displayName:r.displayName.slice(0,80)}:{},...typeof r.avatarUrl==`string`&&Ti.test(r.avatarUrl)?{avatarUrl:r.avatarUrl}:{},source:r.source===`following`?`following`:`manual`,addedAt:typeof r.addedAt==`number`&&Number.isFinite(r.addedAt)&&r.addedAt>=0?r.addedAt:0}),t.length>=2e4))break}return t}function Ni(e){if(!Array.isArray(e))return[];let t=[],n=new Set;for(let r of e){let e=Ei(typeof r==`string`?r:void 0);if(!e)continue;let i=e.toLowerCase();if(!n.has(i)&&(n.add(i),t.push(i),t.length>=Si))break}return t}function Pi(e){let t=e&&typeof e==`object`?e:{};return{entries:Mi(t.entries),excluded:Ni(t.excluded)}}async function Fi(){return Pi((await chrome.storage.local.get(vi))[vi])}Promise.resolve();async function Ii(){ji(await Fi());try{let e=chrome.storage.onChanged;if(Ai===e)return;Ai=e,e.addListener((e,t)=>{t!==`local`||!e[`xss:whitelist:local`]||ji(Pi(e[vi].newValue))})}catch{}}function Li(e,t){if(e&&Oi.has(e))return!0;if(t&&Di.has(t.toLowerCase())){let n=Di.get(t.toLowerCase());return!e||!n||n===e}return!1}function Ri(e){return!!e&&ki.has(e.toLowerCase())}async function zi(e,t){!t||!e.viewerFollowing||e.viewerIsSelf||Li(e.userId,e.handle)||Ri(e.handle)||await bi({handle:e.handle,...e.userId?{userId:e.userId}:{},...e.displayName?{displayName:e.displayName}:{},...e.avatarUrl?{avatarUrl:e.avatarUrl}:{},source:`following`}).catch(()=>{})}var Bi=class{limit;active=0;waiting=[];constructor(e=3){if(this.limit=e,!Number.isInteger(e)||e<1)throw Error(`limit must be a positive integer`)}async acquire(){if(this.active<this.limit){this.active+=1;return}await new Promise(e=>this.waiting.push(e))}release(){let e=this.waiting.shift();e?e():--this.active}async run(e){await this.acquire();try{return await e()}finally{this.release()}}};function Vi(e){return e.authenticated&&e.localResult===`unknown`&&e.requestsStarted<40}function Hi(e){return e.label===`legit`||e.label===`uncertain`||e.label===`likely_spam`&&e.confidence<.8?`silent`:`badge`}var Ui=new Set([`removed`,`rejected`,`whitelisted`,`viewer_ignored`]);function Wi(e,t){return!t||!Ui.has(t)||e.label===`legit`?e:{label:`legit`,confidence:1,reasons:[t===`whitelisted`?`官方白名单保护`:t===`viewer_ignored`?`你与该账号有关注/屏蔽关系，不检测`:`判定已被人工撤回`]}}var Gi=new Set([`spam`,`porn_bot`,`likely_spam`,`uncertain`,`legit`]);function Ki(e){if(!e||typeof e!=`object`)return null;let t=e;return!t.label||!Gi.has(t.label)||typeof t.confidence!=`number`||!Number.isFinite(t.confidence)||!Array.isArray(t.reasons)||!t.reasons.every(e=>typeof e==`string`)?null:{label:t.label,confidence:t.confidence,reasons:t.reasons}}async function qi(e,t,n={}){let r=n.send??(e=>chrome.runtime.sendMessage(e)),i=n.writeCache??U,a=n.now??Date.now,o;try{o=await r({type:`classify`,sig:t})}catch{return{status:`failed`}}if(!o.ok)return o.error===`no_token`?{status:`unauthenticated`}:{status:`failed`};let s=o.data,c=typeof s?.status==`number`?s.status:0;if(c===401)return{status:`unauthenticated`};if(c<200||c>=300)return{status:`failed`,httpStatus:c};let l=Ki(s?.body?.record?.verdict);if(!l)return{status:`failed`,httpStatus:c};let u=typeof s?.body?.record?.status==`string`?s.body.record.status:void 0,d=Wi(l,u),f=typeof s?.body?.record?.model==`string`?s.body.record.model:`edge`;return await i(e,{verdict:d,signalsHash:ve(t),model:f,ts:a(),handle:t.handle,displayName:t.displayName,...t.avatarUrl?{avatarUrl:t.avatarUrl}:{}}),{status:`classified`,verdict:d,cached:s?.body?.cached===!0,...u?{reviewStatus:u}:{}}}var Ji=`mxga_stats_v1`;async function Yi(){return new Promise(e=>{chrome.storage.local.get(Ji,t=>{let n=t?.[Ji]??{};e({scanned:n.scanned??0,hitPublic:n.hitPublic??0,blocked:n.blocked??0,firstUsedAt:n.firstUsedAt??Date.now()})})})}async function Xi(e,t=1){let n=await Yi();n[e]=(n[e]??0)+Math.max(0,Math.floor(t)),n.firstUsedAt||=Date.now(),await new Promise(e=>chrome.storage.local.set({[Ji]:n},()=>e()))}async function Zi(e){await Xi(e,1)}var Qi=`xss:tpl:v1`,$i=3e3,ea=14*864e5;function ta(e){let t=e.trim().toLowerCase().replace(/\s+/g,` `),n=5381;for(let e=0;e<t.length;e++)n=(n*33^t.charCodeAt(e))>>>0;return n.toString(36)}async function na(){try{let e=(await chrome.storage.local.get(Qi))[Qi];return Object.assign(Object.create(null),e&&typeof e==`object`&&!Array.isArray(e)?e:{})}catch{return Object.create(null)}}async function ra(e){try{await chrome.storage.local.set({[Qi]:e})}catch{}}var ia=Promise.resolve();function aa(e){let t=ia.then(e,e);return ia=t.catch(()=>{}),t}function oa(e,t=Date.now(),n=null){let r=(e.triggeringComment??``).trim();return r.length<6?Promise.resolve(0):aa(async()=>{let i=await na(),a=e.handle.toLowerCase(),o=ta(r),s=(i[a]??[]).filter(e=>t-e.ts<ea);if(n&&s.some(e=>e.id===n)){let e=s.filter(e=>e.h===o&&e.id!==n).length;return i[a]=s,await ra(i),e}let c=s.filter(e=>e.h===o).length;s.push({h:o,ts:t,...n?{id:n}:{}}),i[a]=s.slice(-6);let l=Object.keys(i);return l.length>$i&&l.map(e=>[e,Math.max(...(i[e]??[]).map(e=>e.ts),0)]).sort((e,t)=>e[1]-t[1]).slice(0,l.length-$i).forEach(([e])=>delete i[e]),await ra(i),c})}var sa=`xss:blocklist:v2`,ca=`xss:blocked`,la=`xss:stats`,ua=`xss:pending-actions`;async function da(e,t){try{return(await chrome.storage.local.get(e))[e]??t}catch{return t}}async function fa(e,t){try{await chrome.storage.local.set({[e]:t})}catch{}}async function pa(){let e=await da(sa,null);if(e)return e;let t=(await da(ca,[])).map(e=>({id:e,handle:e.startsWith(`h:`)?e.slice(2):e,source:`manual`,ts:Date.now()}));return t.length&&await fa(sa,t),t}function ma(e){return!e.displayName&&!e.verdict&&!e.tweetId&&(e.handle===e.id||`h:${e.handle}`===e.id)&&/^\d+$/.test(e.handle)}async function ha(e){let t=await pa(),n=t.findIndex(t=>t.id===e.id);if(n>=0){let r=t[n];if(!r||!ma(r))return;t[n]={...r,...e}}else t.push(e);await fa(sa,t)}async function ga(e,t){let n=await pa(),r=n.findIndex(t=>t.id===e),i=n[r];if(!i)return;let a={...i,...t};for(let e of Object.keys(t))t[e]===void 0&&delete a[e];n[r]=a,await fa(sa,n)}var _a=Promise.resolve();function va(e){let t=_a.then(e,e);return _a=t.catch(()=>{}),t}async function ya(){return da(ua,[])}async function ba(e){return va(async()=>{let t=await ya();t.some(t=>t.id===e.id)||(t.push(e),await fa(ua,t))})}async function Z(e){return va(async()=>{let t=await ya(),n=t.filter(t=>t.id!==e);n.length!==t.length&&await fa(ua,n)})}async function xa(e){await fa(sa,(await pa()).filter(t=>t.id!==e)),await B(e)}async function Sa(){return da(la,{detections:0,cacheHits:0,blocks:0,byLabel:{}})}async function Ca(e){let t=await Sa();t.detections+=e.detections??0,t.cacheHits+=e.cacheHits??0,t.blocks+=e.blocks??0,e.label&&(t.byLabel[e.label]=(t.byLabel[e.label]??0)+1),await fa(la,t)}function wa(e){let t=he.appealNewIssue;if(e?.handle){let n=new URLSearchParams;n.set(`handle`,`@${e.handle}`),e.userId&&n.set(`userid`,e.userId),n.set(`title`,`[Appeal] @${e.handle} wrongly listed`),t+=`&${n.toString()}`}window.open(t,`_blank`,`noopener`)}var Ta=50;async function Ea(e,t){let n;try{n=await chrome.runtime.sendMessage({type:`report`,sig:e,category:t})}catch{return{ok:!1,message:`网络错误，举报未提交`}}if(!n||!n.ok){if(n?.error===`no_token`){try{chrome.runtime.sendMessage({type:`open_options`})}catch{}return{ok:!1,message:`举报需先在设置页用 GitHub 授权（已为你打开设置）`}}return{ok:!1,message:`网络错误，举报未提交`}}let{status:r,body:i}=n.data??{status:0,body:{}};if(r>=200&&r<300&&i.ok)return i.duplicate?{ok:!0,message:`你已举报过该账号，感谢`}:i.status===`whitelisted`?{ok:!0,message:`该账号已被官方列入白名单，举报已忽略`}:i.status===`viewer_ignored`?{ok:!0,message:`这是你自己的账号，举报已忽略`}:{ok:!0,message:`已举报，进入人工审核队列，感谢贡献`};switch(r){case 401:try{chrome.runtime.sendMessage({type:`open_options`})}catch{}return{ok:!1,message:`GitHub 授权已失效，请在设置页重新授权`};case 403:return{ok:!1,message:`你的举报权限已被限制`};case 429:return{ok:!1,message:`举报过于频繁，请稍后再试`};case 503:return{ok:!1,message:`服务暂未就绪，请稍后再试`};default:return{ok:!1,message:`举报失败，请稍后重试`}}}function Q(e){return e?.closest(`article`)??null}function Da(e){return e===`block`?`拉黑`:e===`mute`?`静音`:`隐藏`}function Oa(e){return Object.values(e.categoryActions).filter(e=>e!==`badge`).length}async function ka(e,t,n=()=>!0){if(!n())return{ok:!1};if(e===`local`)return{ok:!0};let{performXAction:r,retryDelayForAttempt:i}=await Promise.resolve().then(()=>(tr(),bn)),a=await r(e,t.userId,t.handle,n);if(a.ok)return{ok:!0,status:a.status};let o=i(a,1);if(o>0){await new Promise(e=>setTimeout(e,o));let i=await r(e,t.userId,t.handle,n);return i.ok?{ok:!0,status:i.status}:{ok:!1,status:i.status,cause:i.reason}}return{ok:!1,status:a.status,cause:a.reason}}function Aa(e){return[e.status?`HTTP ${e.status}`:``,e.cause].filter(Boolean).join(` · `)||`原因未知`}var ja=/^(following|正在关注|關注中|フォロー中|팔로잉|abonnements|siguiendo|seguindo|folge ich|volgend)$/i;function Ma(){if(location.pathname!==`/home`)return!1;let e=document.querySelector(`[role="tablist"] [role="tab"][aria-selected="true"]`);return!!e&&ja.test((e.textContent??``).trim())}function Na(e){if(e.querySelector(`[data-testid="socialContext"]`))return!1;let t=e.closest(`[data-testid="cellInnerDiv"]`);return t?t.querySelectorAll(`article[data-testid="tweet"]`).length===1:!1}function Pa(){return location.pathname.match(/^\/[^/]+\/status\/(\d+)/)?.[1]??null}function Fa(e){for(let t of e.querySelectorAll(`a[href*="/status/"]`)){if(!t.querySelector(`time`))continue;let e=(t.getAttribute(`href`)??``).match(/\/status\/(\d+)/);if(e?.[1])return e[1]}return null}function Ia(e,t){let n=document.createElement(`span`);n.className=`xss-mount`,n.style.cssText=`display:inline-flex;align-items:center;align-self:center;vertical-align:middle;flex:none;`,n.setAttribute(`data-xss-theme`,J());let r=n.attachShadow({mode:`open`}),i=document.createElement(`style`);i.textContent=Mt,r.append(i,t()),La(e).appendChild(n)}function La(e){try{if(getComputedStyle(e).flexDirection!==`column`)return e;let t=e.querySelector(`a[href^="/"]`);for(;t&&t.parentElement!==e;)t=t.parentElement;let n=t??e.firstElementChild;return n instanceof HTMLElement?n:e}catch{return e}}function Ra(e){return e.querySelectorAll(`.xss-mount, .xss-pending`)}function $(e){Ra(e).forEach(e=>e.remove())}var za=5e3,Ba=d({matches:[`https://x.com/*`,`https://twitter.com/*`],cssInjectionMode:`manual`,async main(e){let t=null,n=!1,r=new Map,i=new WeakMap,a=[],o=new Map,s=new Set,c=new Set;async function l(e,t){if(/^\d+$/.test(t.handle))return;let n=(await pa()).find(t=>t.id===e);!n||!ma(n)||await ga(e,{handle:t.handle,...t.displayName?{displayName:t.displayName}:{},...t.avatarUrl?{avatarUrl:t.avatarUrl}:{}})}let u=new Set,d=new Bi,f=0,p=0,m=!1,h=await br();if(!h.enabled)return;console.info(`[MXGA] content script ready · build 2026-10-25 (kol-m2 + checked-clean ghost)`),Sr(e=>{let n=e.actionMode!==h.actionMode;if(h=e,t?.setAutoProcess(e.autoProcess,Oa(e),e.autoScope===`all`),t?.setAutoExpand(e.autoExpand),n){t?.setVerb(Da(e.actionMode));for(let e of document.querySelectorAll(`.xss-mount`))e.shadowRoot?.querySelector(`.xss-badge.pending`)||e.remove();U()}}),await pe(),await fi(),await Zr(),await Ii(),await bt();async function g(){let e=m;try{let e=await chrome.runtime.sendMessage({type:`auth_status`});m=e?.ok===!0&&e.data?.authenticated===!0}catch{m=!1}return e!==m}await g();let _=e=>e.userId||`h:${e.handle}`,v=e=>Li(e.userId,e.handle)||hi(e.userId,e.handle);chrome.runtime.onMessage.addListener((e,t,n)=>{if(e?.type===`block_queue_exec`)return(async()=>{try{let t=e.item;if(!t||!t.u&&!t.h){n({ok:!1,retryable:!1});return}let r=Fe()??V,i=()=>h.enabled&&(!t.h||t.h.toLowerCase()!==(r??``).toLowerCase())&&!v({...t.u?{userId:t.u}:{},handle:t.h});if(!i()){n({ok:!1,retryable:!1,skipped:!0});return}let{performXAction:a}=await Promise.resolve().then(()=>(tr(),bn)),o=await a(`block`,t.u||void 0,t.h,i);if(o.ok){let e=t.u||`h:${t.h}`;me(e),ha({id:e,handle:t.h,source:`block_all`,reason:`黑名单一键拉黑`,ts:Date.now()})}n(o)}catch{n({ok:!1,retryable:!1})}})(),!0}),chrome.runtime.onMessage.addListener((e,t,n)=>{if(e?.type===`blocks_sync_fetch`)return(async()=>{try{let{X_PUBLIC_BEARER:t}=await Promise.resolve().then(()=>(tr(),bn)),r=document.cookie.match(/(?:^|;\s*)ct0=([^;]+)/)?.[1]??``;if(!r){n({error:`not_logged_in`});return}let i=typeof e.cursor==`string`?e.cursor:`-1`,a=`https://x.com/i/api/1.1/blocks/list.json?count=200&skip_status=true&include_entities=false&cursor=${encodeURIComponent(i)}`,o=await fetch(a,{headers:{authorization:t,"x-csrf-token":r,"x-twitter-auth-type":`OAuth2Session`,accept:`application/json`},credentials:`include`});if(o.status===401||o.status===403){n({error:`not_logged_in`});return}if(o.status===429){n({error:`rate_limited`});return}if(!o.ok){n({error:`http_${o.status}`});return}let s=await o.json();n({users:(s.users??[]).map(e=>({u:typeof e.id_str==`string`?e.id_str:``,h:typeof e.screen_name==`string`?e.screen_name.toLowerCase():``,...typeof e.name==`string`&&e.name?{n:e.name}:{},...typeof e.profile_image_url_https==`string`&&e.profile_image_url_https?{a:e.profile_image_url_https}:{}})).filter(e=>e.u||e.h),next_cursor:String(s.next_cursor??`0`)})}catch{n({error:`network`})}})(),!0}),chrome.runtime.onMessage.addListener((e,t,n)=>{if(e?.type===`x_unblock_exec`)return(async()=>{try{let{performXAction:t}=await Promise.resolve().then(()=>(tr(),bn));n(await t(`unblock`,e.u||void 0,e.h,()=>h.enabled))}catch{n({ok:!1,retryable:!1})}})(),!0});try{chrome.runtime.sendMessage({type:`block_queue_hello`}).catch(()=>{})}catch{}let y,b=null,x=``,S=new Set,C=()=>{clearTimeout(y),y=void 0};document.addEventListener(`mouseover`,e=>{if(!h.kolCardEnabled)return;let t=e.target instanceof Element?e.target:null;if(!t)return;let n=t.closest(`[data-testid="User-Name"]`);if(!n||t.closest(`.xss-mount, .xss-pending`)){(y||b)&&(C(),_n());return}let r=n.querySelector(`a[href^="/"]`),i=/^\/([A-Za-z0-9_]{1,15})(?:$|\/)/.exec(r?.getAttribute(`href`)??``);if(!i){C(),_n();return}let a=i[1]??``;if(!a){C(),_n();return}b&&a.toLowerCase()===x.toLowerCase()&&(y!==void 0||gn())||(C(),_n(),hn(),x=a,b=n,y=setTimeout(async()=>{y=void 0;let e=b;if(!e)return;let t=Ce(e.closest(`article[data-testid="tweet"]`)??null,a);if(!Object.keys(t).length){let e=We();e&&e.toLowerCase()===a.toLowerCase()&&(t=Ce(document.querySelector(`[data-testid="primaryColumn"]`),e))}let n=Li(t.userId,a)||hi(t.userId,a);if(!Object.keys(t).length&&!n)return;let r=e.querySelector(`a[href^="/"]`)?.textContent?.trim()??``,i=r&&!/^@/.test(r)&&r.toLowerCase()!==a.toLowerCase()?r:void 0,o=wt(a),s=t.userId?await dr(t.userId):null,c=()=>mn(e,{handle:a,displayName:i,verified:t.isVerified,accountAgeDays:t.accountAgeDays,accountCreatedAt:t.accountCreatedAt,followersCount:t.followersCount,followingCount:t.followingCount,statusesCount:t.statusesCount,favouritesCount:t.favouritesCount,whitelisted:n,viewerFollowing:t.viewerFollowing,...o,...s?{precise:s}:{},trust:jt({accountAgeDays:t.accountAgeDays,followersCount:t.followersCount,followingCount:t.followingCount,statusesCount:t.statusesCount,favouritesCount:t.favouritesCount,...o,...s?{medianLikes:s.medianLikes,originalRatio:s.originalRatio}:{}})});if(c(),h.kolGraphqlEnabled&&t.userId&&!s&&gn()&&x.toLowerCase()===a.toLowerCase()&&!S.has(t.userId)){let e=t.userId;S.add(e);try{let t=await mr(e,a);t.ok&&(s=t.metrics,gn()&&x.toLowerCase()===a.toLowerCase()&&c())}finally{S.delete(e)}}},450))},!0);function w(){let e=new Set;for(let t of document.querySelectorAll(`[data-xss-hidden-key]`)){let n=t.getAttribute(`data-xss-hidden-key`);if(!n)continue;let r=t.matches(`article`)?t:t.querySelector(`article`),i=n.startsWith(`h:`)?n.slice(2):r?Ge(r):void 0;v({userId:n.startsWith(`h:`)?void 0:n,handle:i??``})||e.add(n)}ue(e)}function ee(e,t,n,r){if(o.has(e))return;let i=Q(n);i?.setAttribute(`data-xss-key`,e);let a=i?Fa(i):null,s=t.triggeringComment||t.recentTweets[0],c=setTimeout(()=>{try{E(e,t).catch(()=>{})}finally{o.delete(e),$(n)}},za);o.set(e,{key:e,sig:t,anchor:n,timer:c,ts:Date.now(),...r?{mode:r}:{},...a?{tweetId:a}:{},...s?{tweetText:s}:{}}),te(n,t,r)}function T(e){let t=o.get(e);t&&(clearTimeout(t.timer),o.delete(e),Q(t.anchor)?.removeAttribute(`data-xss-key`),$(t.anchor))}function E(e,n){let i=o.get(e),s=i?.mode??h.actionMode,c=a.find(t=>(t.userId||`h:${t.handle}`)===e),l=i?.tweetId??c?.tweetId,u=i?.tweetText??c?.snippet;me(e),n.userId&&me(n.userId),ha({id:e,handle:n.handle,...n.displayName?{displayName:n.displayName}:{},...n.avatarUrl?{avatarUrl:n.avatarUrl}:{},...l?{tweetId:l}:{},...u?{tweetText:u}:{},source:`manual`,ts:Date.now()}),Ca({blocks:1}),Zi(`blocked`);let d=o.get(e)?.anchor??r.get(e)??null,f=Q(d),p=f&&Ge(f)?.toLowerCase()===n.handle.toLowerCase()||d&&!f?d:document.querySelector(`[data-xss-key="${CSS.escape(e)}"]`);return p&&le(p,e),t?.markManual(e,Da(s)),(s===`mute`||s===`block`)&&ba({id:e,handle:n.handle,action:s,ts:Date.now()}),ka(s,n).then(t=>((s===`mute`||s===`block`)&&Z(e),t.ok||ga(e,{reason:`手动${Da(s)}（X 动作失败 ${Aa(t)}，仅本地隐藏）`}),t.ok))}function te(e,t,n){$(e);let r=Da(n??h.actionMode);Ia(e,()=>{let e=document.createElement(`span`);return e.className=`xss-badge pending`,e.innerHTML=`<span style="color:var(--warn)">⏳ 5秒后${r}</span>
          <button data-undo style="margin-left:6px;padding:1px 6px;border:1px solid var(--warn);background:transparent;color:var(--warn);border-radius:4px;font-size:10px;cursor:pointer">撤销</button>`,e.querySelector(`[data-undo]`)?.addEventListener(`click`,e=>{e.stopPropagation(),T(_(t))}),e})}let D=e=>new Promise(t=>setTimeout(t,e)),ne=[],O=new Set,k=!1;function re(e,t,n){$(e),Ia(e,()=>Bt(t,n))}function A(e){let t=Q(e.anchor);return t&&Ge(t)?.toLowerCase()===e.sig.handle.toLowerCase()?e.anchor:document.querySelector(`[data-xss-key="${CSS.escape(e.key)}"]`)}function ie(e){if(O.has(e.key)||v(e.sig))return;O.add(e.key),me(e.key),e.sig.userId&&me(e.sig.userId);let n=e.sig.triggeringComment||e.sig.recentTweets[0];ha({id:e.key,handle:e.sig.handle,...e.sig.displayName?{displayName:e.sig.displayName}:{},...e.sig.avatarUrl?{avatarUrl:e.sig.avatarUrl}:{},...e.tweetId?{tweetId:e.tweetId}:{},...n?{tweetText:n}:{},verdict:e.verdict,reason:`${e.categoryZh} · 自动${e.verb}`,source:`auto`,ts:Date.now()}),(e.action===`mute`||e.action===`block`)&&ba({id:e.key,handle:e.sig.handle,action:e.action,ts:Date.now()}),Ca({blocks:1}),Zi(`blocked`),r.set(e.key,e.anchor),Q(e.anchor)?.setAttribute(`data-xss-key`,e.key),re(e.anchor,e.verb,!0),t?.markAuto(e.key,`queued`,e.verb),ne.push(e),M()}let j,ae=0;function M(){if(k)return;let e=Date.now();ae||=e;let t=Math.min(1600,Math.max(0,ae+4e3-e));clearTimeout(j),j=setTimeout(()=>void oe(),t)}async function oe(){if(!k){k=!0,ae=0;try{await N()}finally{k=!1}ne.length&&M()}}async function N(){for(;ne.length;){let e=ne.shift();if(!e)break;try{let n=()=>h.enabled&&h.autoProcess&&!v(e.sig),r=async()=>{await xa(e.key),e.sig.userId&&e.sig.userId!==e.key&&await xa(e.sig.userId),Ca({blocks:-1}),Z(e.key),t?.markAuto(e.key,`failed`,e.verb);let n=A(e);n&&F(n,e.key,e.sig,null)};if(!n()){await r();continue}let i=Date.now(),a=A(e);a&&re(a,e.verb,!1),t?.markAuto(e.key,`processing`,e.verb);let o=e.action===`mute`||e.action===`block`?await ka(e.action,e.sig,n):{ok:!0};if(!n()){await r();continue}o.ok||console.warn(`[MXGA] 自动${e.verb}：X 原生动作失败 ${Aa(o)}`,e.sig.handle,e.sig.userId);let s=900-(Date.now()-i);if(s>0&&await D(s),!n()){await r();continue}le(A(e),e.key),(e.action===`mute`||e.action===`block`)&&(Z(e.key),o.ok||ga(e.key,{reason:`${e.categoryZh} · 自动${e.verb}（X 动作失败 ${Aa(o)}，仅本地隐藏）`})),t?.markAuto(e.key,o.ok?`done`:`failed`,e.verb)}catch(n){console.warn(`[MXGA] 自动${e.verb}处理异常`,e.sig.handle,n);try{t?.markAuto(e.key,`failed`,e.verb)}catch{}}finally{O.delete(e.key)}await D(240)}}async function ce(e){if(h.actionMode===`local`){for(let t of e)Z(t.id);return}for(let t of e.slice(0,Ta)){if(t.action!==`mute`&&t.action!==`block`){Z(t.id);continue}let e={handle:t.handle,.../^\d+$/.test(t.id)?{userId:t.id}:{}},n=()=>h.enabled&&h.actionMode!==`local`&&!v(e);if(!n()){await Z(t.id);continue}let r=await ka(t.action,e,n).catch(()=>({ok:!1}));r.ok||ga(t.id,{reason:`自动${t.action===`block`?`拉黑`:`静音`}（X 动作失败 ${Aa(r)}，仅本地隐藏）`}),Z(t.id)}}function P(e,r,i,o){if(v(e)||![`spam`,`porn_bot`,`likely_spam`].includes(r.label))return;let s=_(e),c=e.handle.toLowerCase();if(a.some(e=>(e.userId||`h:${e.handle}`)===s||e.handle.toLowerCase()===c))return;let l=e.triggeringComment||e.recentTweets[0]||e.bio;a.push({handle:e.handle,verdict:r,source:i,...o?.categoryZh?{categoryZh:o.categoryZh}:{},...o?.tweetId?{tweetId:o.tweetId}:{},...o?.tier?{tier:o.tier}:{},...e.userId?{userId:e.userId}:{},...e.avatarUrl?{avatarUrl:e.avatarUrl}:{},...e.displayName?{displayName:e.displayName}:{},...l?{snippet:l}:{}}),n||t?.update(a)}function F(e,t,n,i,a,s=`fresh`,c=!1){i&&r.set(t,e),$(e);let l=Li(n.userId,n.handle);Ia(e,()=>qt(l?null:i,{onAct:r=>ee(t,n,e,r),onAppeal:()=>wa({handle:n.handle,...n.userId?{userId:n.userId}:{}}),onReport:e=>Ea(n,e),whitelisted:l,clean:c&&!l,onWhitelist:async()=>{if(l)await xi(n.handle);else{let e=o.get(t);e&&(clearTimeout(e.timer),o.delete(t)),await bi({handle:n.handle,...n.userId?{userId:n.userId}:{},...n.displayName?{displayName:n.displayName}:{},...n.avatarUrl?{avatarUrl:n.avatarUrl}:{},source:`manual`});for(let e of[t,n.userId,`h:${n.handle}`])e&&xa(e)}$(e),he(n,e)}},a,s,h.actionMode))}function I(e,t,n,r=`cache`){F(e,t,n,null,void 0,r,!0)}async function L(e,t,n,r){if(Hi(r.verdict)===`silent`){I(e,t,n,`cache`);return}if(m&&Date.now()-r.ts>864e5&&p<10){p+=1;let r=await d.run(()=>v(n)?Promise.resolve({status:`failed`}):qi(t,n));if(v(n)){F(e,t,n,null);return}if(r.status===`classified`){if(Hi(r.verdict)===`silent`){I(e,t,n,`cache`);return}F(e,t,n,r.verdict,void 0,`cache`),P(n,r.verdict,`cache`);return}}F(e,t,n,r.verdict,void 0,`cache`),P(n,r.verdict,`cache`)}async function R(e,t,n){$(e),Ia(e,Vt);let r=await d.run(async()=>v(n)?{status:`failed`}:m?qi(t,n):{status:`unauthenticated`});if(v(n)){F(e,t,n,null);return}if(r.status===`unauthenticated`&&(m=!1),r.status!==`classified`){F(e,t,n,null);return}if(r.cached||(Ca({detections:1,label:r.verdict.label}),Zi(`scanned`)),Hi(r.verdict)===`silent`){I(e,t,n,`fresh`);return}F(e,t,n,r.verdict,r.cached?`在线记录命中`:`在线 AI 检测完成`,`fresh`),P(n,r.verdict,`online-ai`)}function B(e,t,n,r,i=`list`,a=`feed`){u.has(t)||(u.add(t),Zi(`hitPublic`));let o=Q(e),s=o?Fa(o):null,c=de({source:i,tier:r.tier,inReply:a===`reply`,autoScope:h.autoScope,autoTierMode:h.autoTierMode})?fe(h.categoryActions[r.category]??`badge`,{source:i,tier:r.tier,autoTierMode:h.autoTierMode,ruleHitsAutoAct:h.ruleHitsAutoAct}):`badge`;if(c===`badge`||!h.autoProcess){F(e,t,n,r.verdict,void 0,i),P(n,r.verdict,i===`rule`?`local-rule`:`local-index`,{categoryZh:lt[r.category],...s?{tweetId:s}:{},...i===`list`?{tier:r.tier}:{}});return}P(n,r.verdict,i===`rule`?`local-rule`:`local-index`,{categoryZh:lt[r.category],...s?{tweetId:s}:{},...i===`list`?{tier:r.tier}:{}}),ie({key:t,sig:n,action:c,verb:c===`mute`?`静音`:c===`block`?`拉黑`:`隐藏`,anchor:e,verdict:r.verdict,categoryZh:lt[r.category],...s?{tweetId:s}:{}})}async function he(e,t,n=`feed`){let r=_(e);if(!s.has(r)){s.add(r);try{if(await zi(e,h.followingWhitelist),v(e)){T(r),F(t,r,e,null);return}let i=z(r)?r:e.userId&&z(e.userId)?e.userId:z(`h:${e.handle}`)?`h:${e.handle}`:null;if(i){if(O.has(r)&&Q(t)?.getAttribute(`data-xss-key`)===r)return;c.has(i)||(c.add(i),l(i,e)),le(t,i);return}if(o.has(r))return;if(hi(e.userId,e.handle)){F(t,r,e,null);return}let a=gi(e.userId,e.handle);if(a){B(t,r,e,a,`list`,n);return}let s=await be(r);if(v(e)){F(t,r,e,null);return}if(s){let n=[`spam`,`porn_bot`,`likely_spam`].includes(s.verdict.label);if(s.signalsHash===ve(e)||n&&(!m||Date.now()-s.ts<864e5)){await L(t,r,e,s),Ca({cacheHits:1});return}}let u=$r(e);if(u){if(u.origin===`official`&&h.ruleTelemetry)try{chrome.runtime.sendMessage({type:`rule-hit`,hit:{pattern:u.pattern,handle:e.handle,...e.userId?{xUserId:e.userId}:{},category:u.category,field:u.field,matchedText:u.matchedText}})}catch{}B(t,r,e,{userId:e.userId??``,handle:e.handle,verdict:{label:u.label,confidence:.95,reasons:[`命中${u.origin===`custom`?`自定义`:`官方`}规则 · ${lt[u.category]}`]},category:u.category,tier:`auto`,source:`community`,updatedAt:new Date().toISOString()},`rule`,n);return}if(Vi({authenticated:m,localResult:`unknown`,requestsStarted:f})){f+=1;let n=Q(t);e.templateRepeats=await oa(e,Date.now(),n?Fa(n):null),await R(t,r,e);return}F(t,r,e,null)}finally{s.delete(r)}}}let V;try{chrome.storage.local.get(`xss:viewer`).then(e=>{let t=e[`xss:viewer`]?.handle;t&&!V&&(V=t)})}catch{}function ge(){let e=Fe();if(e&&e!==V){V=e;try{chrome.storage.local.set({"xss:viewer":{handle:e,ts:Date.now()}})}catch{}}}let _e=``;function H(){if(!h.followingWhitelist)return;let e=location.pathname.match(/^\/([A-Za-z0-9_]{1,15})\/following\/?$/);if(!e)return;let t=Fe()??V,n=e[1]??``;if(!t||n.toLowerCase()!==t.toLowerCase()){let e=t?`page owner @${n} is not the viewer @${t}`:`viewer handle unknown`;_e!==e&&(_e=e,console.info(`[MXGA] following harvest skipped: ${e}`));return}let r=120,i=0,a=0;for(let e of document.querySelectorAll(`[data-testid="UserCell"]`)){if(r--<=0)break;i+=1;let t=e.querySelector(`[data-testid$="-unfollow"]`);if(!t)continue;let n=t.getAttribute(`data-testid`)?.match(/^(\d+)-unfollow$/)?.[1],o;for(let t of e.querySelectorAll(`a[href^="/"]`)){let e=(t.getAttribute(`href`)??``).split(`/`).filter(Boolean);if(e.length===1&&/^[A-Za-z0-9_]{1,15}$/.test(e[0]??``)){o=e[0];break}}if(!o||Li(n,o)||Ri(o))continue;let s=e.querySelector(`img[src*="profile_images/"]`)?.src,c=e.querySelector(`a[href="/${o}"] span`)?.textContent?.trim();a+=1,bi({handle:o,...n?{userId:n}:{},...c?{displayName:c}:{},...s?{avatarUrl:s}:{},source:`following`}).catch(()=>{})}let o=`[MXGA] following harvest: ${i} cells, +${a} to local whitelist`;(a>0||_e!==o)&&(_e=o,console.info(o))}function ye(){for(let e of document.querySelectorAll(`article[data-testid="tweet"]`)){let t=Fa(e),n=Ge(e);if(!t||!n)continue;let r=e.querySelector(`[data-testid="socialContext"]`);if(!r){let r=e.querySelector(`[data-testid="tweetText"]`)?.textContent?.trim().slice(0,400)??``;Ct({handle:n,statusId:t,original:!0,...r?{text:r}:{}});continue}if(!/转推|转发|retweet|リツイート|리트윗/i.test(r.textContent??``))continue;let i;for(let e of r.querySelectorAll(`a[href^="/"]`)){let t=(e.getAttribute(`href`)??``).split(`/`).filter(Boolean);if(t.length===1&&/^[A-Za-z0-9_]{1,15}$/.test(t[0]??``)){i=t[0];break}}i&&Ct({handle:i,statusId:`rt:${t}`,original:!1})}}function U(){ge(),H(),h.kolCardEnabled&&ye();let e=Ke();if(e){let t=document.querySelector(`[data-testid="UserName"]`);if(t){let n=!!t.querySelector(`.xss-mount`);(i.get(t)!==e.handle||!n)&&(i.get(t)!==e.handle&&$(t),i.set(t,e.handle),he(e,t,`profile`))}}let t=at(),n=Pa(),r=document.querySelectorAll(`article[data-testid="tweet"]`),a;if(n){for(let e of r)if(Fa(e)===n){a=Ge(e);break}}let o=h.followingWhitelist&&Ma();for(let e of r){let r=Ge(e),s=e.querySelector(`[data-testid="User-Name"]`);if(!r||!s)continue;let c=!!s.querySelector(`.xss-mount`);if(i.get(e)===r&&c)continue;let l=it(e);if(!l)continue;t&&!l.threadTopic&&(l.threadTopic=t),o&&!l.viewerFollowing&&!l.isReply&&Na(e)&&(l.viewerFollowing=!0),i.get(e)!==r&&$(s),i.set(e,r);let u=n?Fa(e):null,d=!!(n&&u&&u!==n),f=d?`reply`:`feed`;d?(l.isReply=!0,a&&(l.rootAuthorHandle=a)):a&&l.isReply&&!l.rootAuthorHandle&&(l.rootAuthorHandle=a),he(l,s,f)}}(await se(e,{name:`xss-bubble`,position:`overlay`,anchor:`body`,onMount(i){let s=document.createElement(`style`);s.textContent=Mt,i.appendChild(s);let c=zt({onProcess(e,t){(async()=>{for(let n of e){let e=a.find(e=>(e.userId||`h:${e.handle}`)===n);if(!e){t(n,!1);continue}let r={isProfile:!1,handle:e.handle,displayName:e.displayName??``,bio:``,hasDefaultAvatar:!1,recentTweets:[],...e.userId?{userId:e.userId}:{},...e.avatarUrl?{avatarUrl:e.avatarUrl}:{}},i=o.get(n);i&&(clearTimeout(i.timer),o.delete(n)),t(n,await E(n,r).catch(()=>!1))}})()},onReviewEach(){let e=a[0];e&&r.get(e.userId||`h:${e.handle}`)?.scrollIntoView({behavior:`smooth`,block:`center`})},onDismiss(){n=!0},onAppeal(e){wa(e)},onToggleAuto(e){xr(`autoProcess`,e)}},h.bubblePos,Da(h.actionMode),{autoProcess:h.autoProcess,autoCategoryCount:Oa(h),autoScopeAll:h.autoScope===`all`,autoExpand:h.autoExpand});i.appendChild(c.el),h.bubble||(c.el.style.display=`none`),t=c;let l=()=>{if(h.bubblePos!==`tr`)return;let e=document.querySelector(`[data-testid="SearchBox_Search_Input"], form[role="search"], input[placeholder][data-testid*="Search"]`),t=e?.closest(`[data-testid="sidebarColumn"]`)?e:null,n=``;if(t){let e=t.getBoundingClientRect(),r=(c.el.querySelector(`.pill`)??c.el).getBoundingClientRect();e.width>0&&e.bottom>0&&e.top<70&&r.left<e.right+8&&r.right>e.left-8&&(n=`${Math.round(e.bottom+10)}px`)}c.el.style.setProperty(`--xss-bubble-top`,n)};return l(),e.addEventListener(window,`resize`,l),e.setInterval(l,4e3),ya().then(e=>{e.length&&ce(e)}),c}})).mount(),e.addEventListener(window,`wxt:locationchange`,()=>{for(let[e,t]of o)clearTimeout(t.timer),E(e,t.sig);o.clear(),r.clear(),a=[],f=0,p=0,t?.pageReset()});let xe,Se=new MutationObserver(()=>{clearTimeout(xe),xe=setTimeout(U,600)});Se.observe(document.documentElement,{childList:!0,subtree:!0}),e.onInvalidated(()=>{Se.disconnect(),clearTimeout(xe),St()}),e.setInterval(U,4e3);let we=J(),Te=new MutationObserver(()=>{let e=J();e!==we&&(we=e,Pt(e))});document.body&&Te.observe(document.body,{attributes:!0,attributeFilter:[`style`,`class`]}),e.onInvalidated(()=>Te.disconnect());try{chrome.storage.onChanged.addListener((e,n)=>{if(n!==`local`)return;let r=!1;if(e[`xss:ghToken`]&&g().then(e=>{if(!(!e||!m)){for(let e of document.querySelectorAll(`.xss-mount`))e.shadowRoot?.querySelector(`.xss-badge.ghost`)&&e.remove();U()}}),e[`xss:blocked`]&&(r=ue(new Set(e[`xss:blocked`]?.newValue??[]))>0),e[`xss:list:v2`]||e[`xss:whitelist:v1`]||e[`xss:whitelist:local`]){w();for(let[e,t]of o)v(t.sig)&&T(e);a=a.filter(e=>!v(e)),t?.update(a);for(let e of document.querySelectorAll(`.xss-mount`))e.shadowRoot?.querySelector(`.xss-badge.pending`)||e.remove();r=!0}r&&U()})}catch{}U()}}),Va=class e extends Event{static EVENT_NAME=Ha(`wxt:locationchange`);constructor(t,n){super(e.EVENT_NAME,{}),this.newUrl=t,this.oldUrl=n}};function Ha(e){return`${ie?.runtime?.id}:content:${e}`}var Ua=typeof globalThis.navigation?.addEventListener==`function`;function Wa(e){let t,n=!1;return{run(){n||(n=!0,t=new URL(location.href),Ua?globalThis.navigation.addEventListener(`navigate`,e=>{let n=new URL(e.destination.url);n.href!==t.href&&(window.dispatchEvent(new Va(n,t)),t=n)},{signal:e.signal}):e.setInterval(()=>{let e=new URL(location.href);e.href!==t.href&&(window.dispatchEvent(new Va(e,t)),t=e)},1e3))}}}var Ga=class e{static SCRIPT_STARTED_MESSAGE_TYPE=Ha(`wxt:content-script-started`);id;abortController;locationWatcher=Wa(this);constructor(e,t){this.contentScriptName=e,this.options=t,this.id=Math.random().toString(36).slice(2),this.abortController=new AbortController,this.stopOldScripts(),this.listenForNewerScripts()}get signal(){return this.abortController.signal}abort(e){return this.abortController.abort(e)}get isInvalid(){return ie.runtime?.id??this.notifyInvalidated(),this.signal.aborted}get isValid(){return!this.isInvalid}onInvalidated(e){return this.signal.addEventListener(`abort`,e),()=>this.signal.removeEventListener(`abort`,e)}block(){return new Promise(()=>{})}setInterval(e,t){let n=setInterval(()=>{this.isValid&&e()},t);return this.onInvalidated(()=>clearInterval(n)),n}setTimeout(e,t){let n=setTimeout(()=>{this.isValid&&e()},t);return this.onInvalidated(()=>clearTimeout(n)),n}requestAnimationFrame(e){let t=requestAnimationFrame((...t)=>{this.isValid&&e(...t)});return this.onInvalidated(()=>cancelAnimationFrame(t)),t}requestIdleCallback(e,t){let n=requestIdleCallback((...t)=>{this.signal.aborted||e(...t)},t);return this.onInvalidated(()=>cancelIdleCallback(n)),n}addEventListener(e,t,n,r){t===`wxt:locationchange`&&this.isValid&&this.locationWatcher.run(),e.addEventListener?.(t.startsWith(`wxt:`)?Ha(t):t,n,{...r,signal:this.signal})}notifyInvalidated(){this.abort(`Content script context invalidated`),f.debug(`Content script "${this.contentScriptName}" context invalidated`)}stopOldScripts(){document.dispatchEvent(new CustomEvent(e.SCRIPT_STARTED_MESSAGE_TYPE,{detail:{contentScriptName:this.contentScriptName,messageId:this.id}})),this.options?.noScriptStartedPostMessage||window.postMessage({type:e.SCRIPT_STARTED_MESSAGE_TYPE,contentScriptName:this.contentScriptName,messageId:this.id},`*`)}verifyScriptStartedEvent(e){let t=e.detail?.contentScriptName===this.contentScriptName,n=e.detail?.messageId===this.id;return t&&!n}listenForNewerScripts(){let t=e=>{!(e instanceof CustomEvent)||!this.verifyScriptStartedEvent(e)||this.notifyInvalidated()};document.addEventListener(e.SCRIPT_STARTED_MESSAGE_TYPE,t),this.onInvalidated(()=>document.removeEventListener(e.SCRIPT_STARTED_MESSAGE_TYPE,t))}},Ka={debug:(...e)=>([...e],void 0),log:(...e)=>([...e],void 0),warn:(...e)=>([...e],void 0),error:(...e)=>([...e],void 0)};return(async()=>{try{let{main:e,...t}=Ba;return await e(new Ga(`content`,t))}catch(e){throw Ka.error(`The content script "content" crashed on startup!`,e),e}})()})();
content;